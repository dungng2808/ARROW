package com.solace.spring.boot.autoconfigure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

import com.solace.services.core.model.SolaceServiceCredentials;
import com.solace.spring.cloud.core.SolaceMessagingInfo;
import java.util.Collections;
import java.util.List;
import org.junit.Test;

public class SolaceJmsAutoCloudConfiguration_ArrowTest {

    @Test
    public void constructsConfigurationWithProperties() {
        SolaceJmsAutoCloudConfiguration configuration =
                new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());

        assertEquals(Collections.emptyList(), configuration.getSolaceMessagingInfos());
        assertEquals(Collections.emptyList(), configuration.getSolaceServiceCredentials());
    }

    @Test
    public void returnsEmptyCredentialListsWhenNoCloudServicesAreAvailable() {
        SolaceJmsAutoCloudConfiguration configuration =
                new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());

        List<SolaceMessagingInfo> messagingInfos = configuration.getSolaceMessagingInfos();
        List<SolaceServiceCredentials> credentials = configuration.getSolaceServiceCredentials();

        assertEquals(Collections.emptyList(), messagingInfos);
        assertEquals(Collections.emptyList(), credentials);
    }

    @Test
    public void throwsWhenNoSolaceMessagingInfoIsAvailable() {
        SolaceJmsAutoCloudConfiguration configuration =
                new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());

        try {
            configuration.findFirstSolaceMessagingInfo();
            fail("Expected an IllegalStateException when no Solace service is available");
        } catch (IllegalStateException exception) {
            assertEquals(
                    "Unable to create SolConnectionFactory did not find SolaceMessagingInfo in the current cloud environment",
                    exception.getMessage());
        }
    }
}
