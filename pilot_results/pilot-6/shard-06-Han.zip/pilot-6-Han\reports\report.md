# Báo cáo ARROW: pilot-v1

## Thông tin run

- Run `pilot-6-Han`: experiment sha256 `45189e747717`, máy `Han` (win-x64), tool 0.1.0 commit `3976205273471ed39766d5bba4ebd917a3c7a457`, tạo lúc 2026-10-15 15:00
- Model id trả về: gpt-6-luna → gpt-6-luna

## Khối 1: task dùng được và bị loại

- classes2test: 8 dùng được, 2 bị loại, 0 INFRA

## RQ1: tính hợp lệ của candidate ban đầu (6.1)

Classes2Test (content-matched) và GitBug-Java (upstream-pinned) báo cáo tách riêng. Mẫu số gồm cả output không hợp lệ, không gồm INFRA.

| dataset | model | strategy | candidates | compile | discovery | execution | target_pass | valid | invalid_output | infra |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | few_shot | 8 | 1 | 1 | 1 | 1 | 1 | 0 | 0 |
| classes2test | gpt-6-luna | zero_shot | 8 | 3 | 3 | 1 | 1 | 1 | 0 | 0 |
| classes2test | gpt-6-luna | zero_shot_project_aware | 8 | 5 | 5 | 3 | 3 | 3 | 0 | 0 |

## RQ2: hiệu quả sửa (6.2)

Chỉ tính candidate mà mọi cơ chế đều chạy xong. Chain không thành công tính bằng N.

| dataset | model | mechanism | chains | success | success_rate | attempts_mean | attempts_median | time_mean_s | time_median_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | adaptive | 19 | 10 | 0.5263 | 6.21 | 7 | 229.1 | 214.8 |
| classes2test | gpt-6-luna | fixed | 19 | 14 | 0.7368 | 4.58 | 3 | 219.1 | 150.7 |

## RQ2: số lần kích hoạt các cơ chế (mô tả, không chứng minh nhân quả)

| dataset | model | mechanism | rollback | duplicate_code | invalid_output | repeated_signature | level_up | state_change | level3_rounds | dropped_methods |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | adaptive | 10 | 33 | 5 | 30 | 73 | 18 | 24 | 15 |
| classes2test | gpt-6-luna | fixed | 0 | 0 | 0 | 0 | 0 | 30 | 0 | 12 |

## Chọn N (pilot, 6.3): N = 9

S(k) gộp chain của cả hai cơ chế trên Classes2Test; pilot không xem kết quả so sánh hai cơ chế.

| round | successes_cumulative | share_of_round_n |
| --- | --- | --- |
| 1 | 8 | 0.3333 |
| 2 | 13 | 0.5417 |
| 3 | 16 | 0.6667 |
| 4 | 21 | 0.875 |
| 5 | 22 | 0.9167 |
| 6 | 23 | 0.9583 |
| 7 | 24 | 1 |
| 8 | 24 | 1 |
| 9 | 24 | 1 |
| 10 | 24 | 1 |

## Độ nhạy P của dừng sớm (6.4)

Tính lại từ decision.json, không gọi thêm model.

| dataset | model | p | chains | success | success_rate | rounds_mean | time_mean_s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | 1 | 19 | 6 | 0.3158 | 1.26 | 59.1 |
| classes2test | gpt-6-luna | 2 | 19 | 6 | 0.3158 | 2.26 | 83.9 |
| classes2test | gpt-6-luna | 3 | 19 | 7 | 0.3684 | 3.16 | 128.7 |
| classes2test | gpt-6-luna | none | 19 | 10 | 0.5263 | 6.21 | 229.1 |

## RQ3: chất lượng bộ test VALID (6.5)

Ghép cặp theo từng chỉ số; n_pairs riêng cho mỗi chỉ số.

| dataset | model | metric | n_pairs | arrow_mean | evosuite_mean | arrow_median | evosuite_median | mean_diff | arrow_sd | evosuite_sd |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | line | 3 | 0.8554 | 0 | 0.8163 | 0 | 0.8554 | 0.1295 | 0 |
| classes2test | gpt-6-luna | branch | 3 | 0.7778 | 0 | 0.8333 | 0 | 0.7778 | 0.2546 | 0 |
| classes2test | gpt-6-luna | method | 3 | 0.8222 | 0 | 0.8 | 0 | 0.8222 | 0.1678 | 0 |
| classes2test | gpt-6-luna | mutation_score | 2 | 0.7916 | 0.7084 | 0.7916 | 0.7084 | 0.0833 | 0.2947 | 0.4125 |
| classes2test | gpt-6-luna | smell_density | 3 | 3.5167 | 3.0714 | 3.75 | 3 | 0.4452 | 1.4145 | 0.1237 |

## RQ3: tập so sánh

| dataset | model | both | only_arrow | only_evosuite | dropped_line | dropped_branch | dropped_method | dropped_mutation_score | dropped_smell_density |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | 3 | 3 | 1 | 0 | 0 | 0 | 1 | 0 |

## Chi phí (6.6)

| dataset | block | llm_calls | tokens_in | tokens_out | cost_usd | finish_length |
| --- | --- | --- | --- | --- | --- | --- |
| classes2test | 2 | 24 | 53715 | 16369 | 0.0068 | 0 |
| classes2test | 3 | 205 | 687957 | 146274 | 0.071 | 0 |

## Thời gian từng bước (6.6)

| step | count | median_s | p90_s | max_s |
| --- | --- | --- | --- | --- |
| llm | 229 | 9.5 | 53.2 | 297.6 |
| verify_build | 191 | 15.7 | 41.7 | 68.6 |
| evosuite | 8 | 133.6 | 154.8 | 161.2 |
| jacoco | 33 | 17.9 | 27.5 | 73.5 |
| pit | 33 | 12.4 | 20.9 | 35.6 |
| tsdetect | 33 | 0.6 | 1 | 1.1 |

## Task bị loại

| dataset | task_id | code | message |
| --- | --- | --- | --- |
| classes2test | 105876502_933fea3e73cb5849 | B1_PAIRED_TEST_NOT_PASSING | Test người viết org.ec4j.core.model.PropertyTypeTest: NO_TEST_RUN |
| classes2test | 43258821_153c5db63941b4b0 | B1_PAIRED_TEST_NOT_PASSING | Test người viết io.blobkeeper.common.util.MerkleTreeTest: FLAKY |

## Cần chạy lại riêng

Danh sách rỗng: run hoàn chỉnh.

(không có dữ liệu)
## Ngoại lệ đã khai báo

- Cờ build chung tắt checkstyle, spotless, enforcer, JaCoCo của dự án…; JVM chạy với `-Dfile.encoding=UTF-8 -Duser.language=en -Duser.country=US -Duser.timezone=UTC`.
- Bộ EvoSuite cần `evosuite-standalone-runtime` trong classpath test (Maven: dependency scope `system` chỉ trong bản sao; Gradle: init script).
- JaCoCo gắn qua `JAVA_TOOL_OPTIONS` với `includes=<FQN>:<FQN>$*`; PIT dùng `--targetClasses <FQN>,<FQN>$*`.

## Hạn chế

- Thực nghiệm chạy một lần cho mỗi cấu hình; các con số cơ chế là thống kê mô tả.
- Commit của Classes2Test là content-matched: tái lập được nhưng không bảo đảm là commit tác giả dataset đã dùng.
