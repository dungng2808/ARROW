package io.nuvalence.kiqt.core.outputs;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.Test;

public class OutputCache_ArrowTest {

    @Test
    public void constructorFetchesRecordsSynchronouslyAndReturnsDefensiveCopies() throws IOException {
        Reader<String> reader = mock(Reader.class);
        when(reader.getRecords()).thenReturn(new ArrayList<>(Arrays.asList("one", "two")));

        OutputCache<String> cache = new OutputCache<>(reader, 60_000L);
        try {
            List<String> records = cache.getRecords();

            assertEquals(Arrays.asList("one", "two"), records);
            assertNotSame(records, cache.getRecords());

            records.add("external");
            assertEquals(Arrays.asList("one", "two"), cache.getRecords());
            verify(reader).getRecords();
        } finally {
            cache.cancel();
        }
    }

    @Test
    public void refreshAppendsRecordsAndSetConfigurationDelegates() throws IOException {
        Reader<String> reader = mock(Reader.class);
        when(reader.getRecords())
                .thenReturn(Collections.singletonList("first"))
                .thenReturn(Collections.singletonList("second"));
        ReaderConfiguration configuration = mock(ReaderConfiguration.class);

        OutputCache<String> cache = new OutputCache<>(reader, 60_000L);
        try {
            cache.refresh();

            assertEquals(Arrays.asList("first", "second"), cache.getRecords());
            cache.setConfiguration(configuration);
            verify(reader).setConfiguration(configuration);
        } finally {
            cache.cancel();
        }
    }

    @Test
    public void constructorPassesInitialIOExceptionToExceptionHandler() throws IOException {
        Reader<String> reader = mock(Reader.class);
        IOException failure = new IOException("unavailable");
        doThrow(failure).when(reader).getRecords();
        AtomicReference<IOException> handled = new AtomicReference<>();

        OutputCache<String> cache =
                new OutputCache<>(reader, 60_000L, handled::set);
        try {
            assertEquals(failure, handled.get());
            assertTrue(cache.getRecords().isEmpty());
        } finally {
            cache.cancel();
        }
    }

    @Test
    public void defaultExceptionHandlerWrapsInitialIOException() throws IOException {
        Reader<String> reader = mock(Reader.class);
        IOException failure = new IOException("unavailable");
        doThrow(failure).when(reader).getRecords();

        RuntimeException thrown;
        try {
            new OutputCache<>(reader, 60_000L);
            fail("Expected RuntimeException");
            return;
        } catch (RuntimeException exception) {
            thrown = exception;
        }

        assertEquals("failed to fetch records", thrown.getMessage());
        assertEquals(failure, thrown.getCause());
        verify(reader, never()).setConfiguration(org.mockito.Matchers.any());
    }
}
