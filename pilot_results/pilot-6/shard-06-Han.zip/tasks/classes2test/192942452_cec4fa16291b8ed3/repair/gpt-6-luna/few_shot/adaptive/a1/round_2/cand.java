package io.nuvalence.kiqt.core.outputs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.Test;

public class OutputCache_ArrowTest {

    @Test
    public void cachesRecordsOnConstructionAndReturnsIndependentCopies() throws Exception {
        Reader<String> reader = mock(Reader.class);
        when(reader.getRecords()).thenReturn(Arrays.asList("one", "two"));

        OutputCache<String> cache = new OutputCache<>(reader, 60_000L);
        try {
            List<String> records = cache.getRecords();
            assertEquals(Arrays.asList("one", "two"), records);
            assertNotSame(records, cache.getRecords());

            records.clear();
            assertEquals(Arrays.asList("one", "two"), cache.getRecords());
        } finally {
            cache.cancel();
        }
    }

    @Test
    public void refreshAppendsRecordsAndDelegatesConfiguration() throws Exception {
        Reader<String> reader = mock(Reader.class);
        when(reader.getRecords())
                .thenReturn(Collections.singletonList("first"))
                .thenReturn(Collections.singletonList("second"));

        OutputCache<String> cache = new OutputCache<>(reader, 60_000L);
        try {
            cache.refresh();
            assertEquals(Arrays.asList("first", "second"), cache.getRecords());

            ReaderConfiguration configuration = mock(ReaderConfiguration.class);
            cache.setConfiguration(configuration);
            verify(reader).setConfiguration(configuration);
        } finally {
            cache.cancel();
        }
    }

    @Test
    public void refreshPropagatesReaderIOException() throws Exception {
        Reader<String> reader = mock(Reader.class);
        when(reader.getRecords()).thenReturn(Collections.emptyList());

        OutputCache<String> cache = new OutputCache<>(reader, 60_000L);
        try {
            IOException expected = new IOException("read failed");
            when(reader.getRecords()).thenThrow(expected);

            IOException actual = null;
            try {
                cache.refresh();
                fail("Expected refresh() to throw IOException");
            } catch (IOException exception) {
                actual = exception;
            }
            assertEquals(expected, actual);
        } finally {
            cache.cancel();
        }
    }

    @Test
    public void constructorPassesInitialIOExceptionToHandler() throws Exception {
        Reader<String> reader = mock(Reader.class);
        IOException expected = new IOException("initial read failed");
        when(reader.getRecords()).thenThrow(expected);
        AtomicReference<IOException> handled = new AtomicReference<>();

        OutputCache<String> cache =
                new OutputCache<>(reader, 60_000L, handled::set);
        try {
            assertEquals(expected, handled.get());
            assertTrue(cache.getRecords().isEmpty());
        } finally {
            cache.cancel();
        }
    }
}
