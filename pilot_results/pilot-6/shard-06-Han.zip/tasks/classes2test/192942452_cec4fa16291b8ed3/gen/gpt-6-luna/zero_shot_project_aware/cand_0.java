package io.nuvalence.kiqt.core.outputs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Test;

public class OutputCache_ArrowTest {

    @Test
    public void constructorFetchesRecordsImmediatelyAndGetRecordsReturnsCopy() throws Exception {
        Reader<String> reader = mock(Reader.class);
        when(reader.getRecords()).thenReturn(Arrays.asList("one", "two"));

        OutputCache<String> cache = new OutputCache<>(reader, 60_000L);
        try {
            List<String> records = cache.getRecords();

            assertEquals(Arrays.asList("one", "two"), records);
            assertNotSame(records, cache.getRecords());
            records.add("local change");
            assertEquals(Arrays.asList("one", "two"), cache.getRecords());
            verify(reader).getRecords();
        } finally {
            cache.cancel();
        }
    }

    @Test
    public void refreshAppendsRecordsAndSetConfigurationDelegates() throws Exception {
        Reader<String> reader = mock(Reader.class);
        when(reader.getRecords())
                .thenReturn(Collections.singletonList("first"))
                .thenReturn(Arrays.asList("second", "third"));

        OutputCache<String> cache = new OutputCache<>(reader, 60_000L);
        try {
            cache.refresh();
            assertEquals(Arrays.asList("first", "second", "third"), cache.getRecords());

            ReaderConfiguration configuration = mock(ReaderConfiguration.class);
            cache.setConfiguration(configuration);
            verify(reader).setConfiguration(configuration);
        } finally {
            cache.cancel();
        }
    }

    @Test
    public void constructorPassesInitialIOExceptionToHandler() {
        Reader<String> reader = mock(Reader.class);
        IOException failure = new IOException("unavailable");
        try {
            when(reader.getRecords()).thenThrow(failure);
        } catch (IOException e) {
            throw new AssertionError(e);
        }

        AtomicInteger handled = new AtomicInteger();
        OutputCache<String> cache = new OutputCache<>(reader, 60_000L, exception -> {
            assertEquals(failure, exception);
            handled.incrementAndGet();
        });
        try {
            assertEquals(1, handled.get());
            assertTrue(cache.getRecords().isEmpty());
        } finally {
            cache.cancel();
        }
    }
}
