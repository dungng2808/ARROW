package net.md_5.bungee.api.chat;

import java.util.Arrays;
import java.util.Collections;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class TranslatableComponent_ArrowTest
{
    @Test
    public void constructorStoresTranslationAndStringArguments()
    {
        TranslatableComponent component = new TranslatableComponent( "test.key", "first", "second" );

        assertEquals( "test.key", component.getTranslate() );
        assertEquals( 2, component.getWith().size() );
        assertEquals( "first", ( (TextComponent) component.getWith().get( 0 ) ).getText() );
        assertEquals( "second", ( (TextComponent) component.getWith().get( 1 ) ).getText() );
    }

    @Test
    public void addWithInitializesListAndSetsParent()
    {
        TranslatableComponent component = new TranslatableComponent();
        component.setTranslate( "test.key" );
        TextComponent substitution = new TextComponent( "value" );

        component.addWith( substitution );

        assertEquals( 1, component.getWith().size() );
        assertSame( component, substitution.parent );
        assertEquals( "value", ( (TextComponent) component.getWith().get( 0 ) ).getText() );
    }

    @Test
    public void setWithReplacesSubstitutionsAndSetsParents()
    {
        TranslatableComponent component = new TranslatableComponent();
        TextComponent substitution = new TextComponent( "replacement" );

        component.setWith( Arrays.<BaseComponent>asList( substitution ) );

        assertEquals( 1, component.getWith().size() );
        assertSame( component, substitution.parent );
    }

    @Test
    public void duplicateCopiesTranslationAndSubstitutions()
    {
        TranslatableComponent original = new TranslatableComponent( "test.key", "value" );
        TranslatableComponent copy = (TranslatableComponent) original.duplicate();

        assertNotSame( original, copy );
        assertEquals( original.getTranslate(), copy.getTranslate() );
        assertNotSame( original.getWith(), copy.getWith() );
        assertNotSame( original.getWith().get( 0 ), copy.getWith().get( 0 ) );
        assertEquals( "value", ( (TextComponent) copy.getWith().get( 0 ) ).getText() );
    }

    @Test
    public void duplicatePreservesNullSubstitutions()
    {
        TranslatableComponent original = new TranslatableComponent();
        original.setTranslate( "test.key" );

        TranslatableComponent copy = (TranslatableComponent) original.duplicate();

        assertEquals( "test.key", copy.getTranslate() );
        assertNull( copy.getWith() );
    }

    @Test
    public void unknownTranslationKeyIsRenderedLiterally()
    {
        TranslatableComponent component = new TranslatableComponent( "missing.translation.key" );

        assertEquals( "missing.translation.key", component.toPlainText() );
        assertEquals( "§fmissing.translation.key", component.toLegacyText() );
    }

    @Test
    public void translationFormatsSubstitutionsAndEscapedPercent()
    {
        TranslatableComponent component = new TranslatableComponent( "prefix %s %% %2$s", "one", "two" );

        assertEquals( "prefix one % two", component.toPlainText() );
        assertEquals( "§fprefix §fone§f % §ftwo", component.toLegacyText() );
    }

    @Test
    public void translationWithNoSubstitutionsRendersLiteralText()
    {
        TranslatableComponent component = new TranslatableComponent( "plain translation" );
        component.setWith( Collections.<BaseComponent>emptyList() );

        assertEquals( "plain translation", component.toPlainText() );
        assertEquals( "§fplain translation", component.toLegacyText() );
    }
}
