package net.md_5.bungee.api.chat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;

import static org.junit.Assert.*;

public class TranslatableComponent_ArrowTest
{
    @Test
    public void unknownTranslationUsesKeyAndSubstitutions()
    {
        TranslatableComponent component = new TranslatableComponent( "test.unknown.%s", "world" );

        assertEquals( "test.unknown.world", component.toPlainText());
        assertEquals( "test.unknown.world", component.toLegacyText());
    }

    @Test
    public void percentAndIndexedSubstitutionsAreExpanded()
    {
        TranslatableComponent component = new TranslatableComponent( "test.%2$s then %1$s %%", "first", "second" );

        assertEquals( "test.second then first %", component.toPlainText());
        assertEquals( "test.second then first %", component.toLegacyText());
    }

    @Test
    public void substitutionsCanBeAddedAndParented()
    {
        TranslatableComponent component = new TranslatableComponent( "test.%s" );
        TextComponent substitution = new TextComponent( "value" );

        component.addWith( substitution );

        assertSame( component, substitution.getParent());
        assertEquals( "test.value", component.toPlainText());
    }

    @Test
    public void duplicateCopiesSubstitutionsIndependently()
    {
        TranslatableComponent original = new TranslatableComponent( "test.%s", "value" );
        TranslatableComponent duplicate = (TranslatableComponent) original.duplicate();

        assertNotSame( original, duplicate );
        assertNotSame( original.getWith().get( 0 ), duplicate.getWith().get( 0 ));
        assertEquals( original.toPlainText(), duplicate.toPlainText());
    }

    @Test
    public void setWithAssignsParentToEverySubstitution()
    {
        TranslatableComponent component = new TranslatableComponent( "test.%s%s" );
        TextComponent first = new TextComponent( "a" );
        TextComponent second = new TextComponent( "b" );
        List<BaseComponent> substitutions = new ArrayList<BaseComponent>( Arrays.<BaseComponent>asList( first, second ) );

        component.setWith( substitutions );

        assertSame( component, first.getParent());
        assertSame( component, second.getParent());
        assertEquals( "test.ab", component.toPlainText());
    }
}
