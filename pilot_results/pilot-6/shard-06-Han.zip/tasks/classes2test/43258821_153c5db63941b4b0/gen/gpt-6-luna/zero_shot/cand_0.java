package io.blobkeeper.common.util;

import com.google.common.collect.Range;
import org.junit.Test;

import java.util.List;
import java.util.TreeMap;

import static org.junit.Assert.*;

public class MerkleTree_ArrowTest {

    @Test
    public void constructorCreatesLeavesCoveringTheFullRange() {
        MerkleTree tree = new MerkleTree(Range.closed(0L, 16L), 4);

        List<LeafNode> leaves = tree.getLeafNodes();

        assertEquals(4, leaves.size());
        assertEquals(Range.openClosed(0L, 4L), leaves.get(0).getRange());
        assertEquals(Range.openClosed(4L, 8L), leaves.get(1).getRange());
        assertEquals(Range.openClosed(8L, 12L), leaves.get(2).getRange());
        assertEquals(Range.openClosed(12L, 16L), leaves.get(3).getRange());
        assertNotNull(tree.getRoot());
    }

    @Test
    public void shallowTreeHasSingleLeaf() {
        MerkleTree tree = new MerkleTree(Range.closed(0L, 10L), 1);

        assertEquals(1, tree.getLeafNodes().size());
        assertTrue(tree.getRoot() instanceof LeafNode);
    }

    @Test
    public void emptyRangeIsRejected() {
        try {
            new MerkleTree(Range.open(5L, 5L), 4);
            fail("Expected an empty range to be rejected");
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }

    @Test
    public void differenceWithNullReturnsAllLeaves() {
        MerkleTree tree = new MerkleTree(Range.closed(0L, 8L), 2);

        assertEquals(tree.getLeafNodes(), MerkleTree.difference(tree, null));
    }

    @Test
    public void fillTreeAndCalculateProduceAStringRepresentation() {
        MerkleTree tree = new MerkleTree(Range.closed(0L, 8L), 2);
        TreeMap<Long, Block> blocks = new TreeMap<>();

        MerkleTree.fillTree(tree, blocks);
        tree.calculate();

        assertNotNull(tree.toString());
        assertFalse(tree.toString().isEmpty());
    }

    @Test
    public void identicalTreesHaveNoDifferenceAfterCalculation() {
        MerkleTree first = new MerkleTree(Range.closed(0L, 8L), 2);
        MerkleTree second = new MerkleTree(Range.closed(0L, 8L), 2);

        MerkleTree.fillTree(first, new TreeMap<Long, Block>());
        MerkleTree.fillTree(second, new TreeMap<Long, Block>());
        first.calculate();
        second.calculate();

        assertTrue(MerkleTree.difference(first, second).isEmpty());
    }
}
