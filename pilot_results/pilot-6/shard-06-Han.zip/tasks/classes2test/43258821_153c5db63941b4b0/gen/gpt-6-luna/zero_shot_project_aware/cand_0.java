package io.blobkeeper.common.util;

import com.google.common.collect.Range;
import org.testng.annotations.Test;

import java.util.List;
import java.util.TreeMap;

import static org.testng.Assert.*;

public class MerkleTree_ArrowTest {

    @Test
    public void createsLeavesAcrossTheConfiguredRange() {
        MerkleTree tree = new MerkleTree(Range.closed(0L, 16L), 8);

        List<LeafNode> leaves = tree.getLeafNodes();

        assertEquals(leaves.size(), 4);
        assertEquals(leaves.get(0).getRange(), Range.openClosed(0L, 4L));
        assertEquals(leaves.get(1).getRange(), Range.openClosed(4L, 8L));
        assertEquals(leaves.get(2).getRange(), Range.openClosed(8L, 12L));
        assertEquals(leaves.get(3).getRange(), Range.openClosed(12L, 16L));
    }

    @Test
    public void emptyRangeIsRejected() {
        try {
            new MerkleTree(Range.closedOpen(1L, 1L), 4);
            fail("Expected an empty range to be rejected");
        } catch (IllegalArgumentException expected) {
            assertEquals(expected.getMessage(), "Range is empty!");
        }
    }

    @Test
    public void nullRangeIsRejected() {
        try {
            new MerkleTree(null, 4);
            fail("Expected a null range to be rejected");
        } catch (NullPointerException expected) {
            // Preconditions reject null input.
        }
    }

    @Test
    public void differenceWithNullReturnsAllLeaves() {
        MerkleTree tree = new MerkleTree(Range.closed(0L, 8L), 4);

        assertEquals(MerkleTree.difference(tree, null), tree.getLeafNodes());
    }

    @Test
    public void equalUnfilledTreesHaveNoDifference() {
        MerkleTree first = new MerkleTree(Range.closed(0L, 8L), 4);
        MerkleTree second = new MerkleTree(Range.closed(0L, 8L), 4);

        assertTrue(MerkleTree.difference(first, second).isEmpty());
    }

    @Test
    public void fillTreeInitializesLeavesForEmptyInput() {
        MerkleTree tree = new MerkleTree(Range.closed(0L, 8L), 4);

        MerkleTree.fillTree(tree, new TreeMap<Long, Block>());

        for (LeafNode leaf : tree.getLeafNodes()) {
            assertNotNull(leaf.getHash());
        }
    }

    @Test
    public void calculateCanBeCalledOnAnInitializedTree() {
        MerkleTree tree = new MerkleTree(Range.closed(0L, 8L), 4);

        tree.calculate();

        assertNotNull(tree.getRoot());
        assertNotNull(tree.toString());
    }
}
