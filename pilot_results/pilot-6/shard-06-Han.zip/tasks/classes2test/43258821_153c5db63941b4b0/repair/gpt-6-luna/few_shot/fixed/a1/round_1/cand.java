package io.blobkeeper.common.util;

import com.google.common.collect.Range;
import org.junit.Test;

import java.util.List;
import java.util.TreeMap;

import static org.junit.Assert.*;

public class MerkleTree_ArrowTest {

    @Test
    public void createsLeafForDepthOneAndExposesItsRange() {
        MerkleTree tree = new MerkleTree(Range.closedOpen(0L, 10L), 1);

        List<LeafNode> leaves = tree.getLeafNodes();

        assertEquals(1, leaves.size());
        assertEquals(Range.openClosed(0L, 10L), leaves.get(0).getRange());
        assertNotNull(tree.getRoot());
    }

    @Test
    public void splitsRangeIntoLeavesAccordingToDepth() {
        MerkleTree tree = new MerkleTree(Range.closedOpen(0L, 16L), 8);

        List<LeafNode> leaves = tree.getLeafNodes();

        assertEquals(8, leaves.size());
        assertEquals(Range.openClosed(0L, 2L), leaves.get(0).getRange());
        assertEquals(Range.openClosed(2L, 4L), leaves.get(1).getRange());
        assertEquals(Range.openClosed(4L, 6L), leaves.get(2).getRange());
        assertEquals(Range.openClosed(6L, 8L), leaves.get(3).getRange());
        assertEquals(Range.openClosed(8L, 10L), leaves.get(4).getRange());
        assertEquals(Range.openClosed(10L, 12L), leaves.get(5).getRange());
        assertEquals(Range.openClosed(12L, 14L), leaves.get(6).getRange());
        assertEquals(Range.openClosed(14L, 16L), leaves.get(7).getRange());
    }

    @Test
    public void rejectsEmptyRange() {
        try {
            new MerkleTree(Range.closedOpen(5L, 5L), 4);
            fail("Expected an empty range to be rejected");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void differenceWithNullReturnsAllLeaves() {
        MerkleTree tree = new MerkleTree(Range.closedOpen(0L, 8L), 4);

        assertEquals(tree.getLeafNodes(), MerkleTree.difference(tree, null));
    }

    @Test
    public void fillTreeAndCalculateProducesStableTree() {
        MerkleTree tree = new MerkleTree(Range.closedOpen(0L, 8L), 4);
        TreeMap<Long, Block> blocks = new TreeMap<>();

        MerkleTree.fillTree(tree, blocks);
        tree.calculate();

        assertEquals(4, tree.getLeafNodes().size());
        assertNotNull(tree.toString());
    }
}
