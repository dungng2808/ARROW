package coverage_metrics;

import org.junit.Test;
import static org.junit.Assert.*;

class CoverageMetrics_ArrowTest {

  private final CoverageMetrics coverageMetrics = new CoverageMetrics();

  @Test
  void returnsInputWhenInputIsZero() {
    assertEquals(0.0f, coverageMetrics.f(0));
  }

  @Test
  void dividesNonzeroInputByTwo() {
    assertEquals(2.0f, coverageMetrics.f(4));
  }
}
