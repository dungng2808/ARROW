package coverage_metrics;

import org.junit.Test;
import static org.junit.Assert.*;

class CoverageMetrics_ArrowTest {

  @Test
  void returnsInputWhenInputIsZero() {
    CoverageMetrics metrics = new CoverageMetrics();

    assertEquals(0.0f, metrics.f(0), 0.0f);
  }

  @Test
  void dividesNonzeroInputByTwo() {
    CoverageMetrics metrics = new CoverageMetrics();

    assertEquals(2.0f, metrics.f(4), 0.0f);
    assertEquals(-1.5f, metrics.f(-3), 0.0f);
  }
}
