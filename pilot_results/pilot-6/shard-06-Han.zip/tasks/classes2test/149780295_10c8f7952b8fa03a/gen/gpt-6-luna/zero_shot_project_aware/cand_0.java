package coverage_metrics;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoverageMetrics_ArrowTest {

    @Test
    public void returnsZeroForZeroInput() {
        CoverageMetrics metrics = new CoverageMetrics();

        assertEquals(0.0f, metrics.f(0), 0.0f);
    }

    @Test
    public void dividesNonzeroInputByTwo() {
        CoverageMetrics metrics = new CoverageMetrics();

        assertEquals(2.0f, metrics.f(4), 0.0f);
        assertEquals(-2.0f, metrics.f(-4), 0.0f);
    }
}
