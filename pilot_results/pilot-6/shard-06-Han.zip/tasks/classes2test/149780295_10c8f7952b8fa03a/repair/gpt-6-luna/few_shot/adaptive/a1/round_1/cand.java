package coverage_metrics;

import org.junit.Test;
import static org.junit.Assert.*;

public class CoverageMetrics_ArrowTest {

  private final CoverageMetrics coverageMetrics = new CoverageMetrics();

  public CoverageMetrics_ArrowTest() {
  }

  @Test
  public void returnsInputWhenInputIsZero() {
    assertEquals(0.0f, coverageMetrics.f(0), 0.0f);
  }

  @Test
  public void dividesNonzeroInputByTwo() {
    assertEquals(2.0f, coverageMetrics.f(4), 0.0f);
  }
}
