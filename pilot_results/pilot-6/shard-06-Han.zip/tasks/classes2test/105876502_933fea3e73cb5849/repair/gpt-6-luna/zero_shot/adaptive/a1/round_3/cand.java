package org.ec4j.core.model;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

import org.junit.Test;

public class PropertyType_ArrowTest {

    @Test
    public void standardTypesContainAllWidelySupportedTypesInOrder() {
        Set<PropertyType<?>> types = PropertyType.standardTypes();

        assertEquals(new LinkedHashSet<>(Arrays.asList(PropertyType.charset, PropertyType.end_of_line,
                PropertyType.indent_size, PropertyType.indent_style, PropertyType.insert_final_newline,
                PropertyType.root, PropertyType.tab_width, PropertyType.trim_trailing_whitespace)), types);
        assertEquals(8, types.size());

        try {
            types.add(new PropertyType<String>("x", "x", PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER));
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // Expected: standard types are immutable.
        }
    }

    @Test
    public void constructorsExposeMetadataAndPossibleValues() {
        Set<String> values = new LinkedHashSet<>(Arrays.asList("one", "two"));
        PropertyType<String> fromSet = new PropertyType<>("sample", "description",
                PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER, values);
        assertEquals("sample", fromSet.getName());
        assertEquals("description", fromSet.getDescription());
        assertSame(values, fromSet.getPossibleValues());
        assertEquals("sample", fromSet.toString());

        PropertyType<String> fromArray = new PropertyType<>("array", "array description",
                PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER, "a", "b", "a");
        assertEquals(new LinkedHashSet<>(Arrays.asList("a", "b")), fromArray.getPossibleValues());

        try {
            fromArray.getPossibleValues().add("c");
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // Expected: possible values created from an array are immutable.
        }
    }

    @Test
    public void identityParserPreservesNullAndNonNullValues() {
        PropertyType.PropertyValue<String> value = PropertyType.charset.parse("MiXeD");
        assertTrue(value.isValid());
        assertEquals("MiXeD", value.getSource());
        assertEquals("MiXeD", value.getParsed());
        assertNull(value.getErrorMessage());

        PropertyType.PropertyValue<String> nullValue = PropertyType.charset.parse(null);
        assertTrue(nullValue.isValid());
        assertNull(nullValue.getSource());
        assertNull(nullValue.getParsed());
    }

    @Test
    public void lowerCasingUsesUsLocaleAndPreservesNull() {
        PropertyType.LowerCasingPropertyType<String> type = new PropertyType.LowerCasingPropertyType<>("x", "",
                PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER, "i");
        assertEquals("mixed", type.normalizeIfNeeded("MiXeD"));
        assertNull(type.normalizeIfNeeded(null));
    }

    @Test
    public void booleanParserAcceptsCaseInsensitiveValuesAndReportsFailures() {
        PropertyType.PropertyValue<Boolean> yes = PropertyType.insert_final_newline.parse("TrUe");
        assertTrue(yes.isValid());
        assertEquals(Boolean.TRUE, yes.getParsed());
        assertEquals("TrUe", yes.getSource());

        PropertyType.PropertyValue<Boolean> no = PropertyType.root.parse("FALSE");
        assertTrue(no.isValid());
        assertEquals(Boolean.FALSE, no.getParsed());

        PropertyType.PropertyValue<Boolean> invalid = PropertyType.root.parse("yes");
        assertFalse(invalid.isValid());
        assertEquals("yes", invalid.getSource());
        assertEquals("Property 'root' expects a boolean. The parsed 'yes' is not a boolean.",
                invalid.getErrorMessage());

        assertEquals("Property 'root' expects a boolean; found: null", PropertyType.root.parse(null).getErrorMessage());
    }

    @Test
    public void positiveIntegerParserDistinguishesInvalidAndNonPositiveValues() {
        PropertyType.PropertyValue<Integer> valid = PropertyType.tab_width.parse("12");
        assertTrue(valid.isValid());
        assertEquals(Integer.valueOf(12), valid.getParsed());

        PropertyType.PropertyValue<Integer> zero = PropertyType.tab_width.parse("0");
        assertFalse(zero.isValid());
        assertEquals("Property 'tab_width' expects a positive integer; found '0'", zero.getErrorMessage());

        PropertyType.PropertyValue<Integer> malformed = PropertyType.tab_width.parse("1.5");
        assertFalse(malformed.isValid());
        assertEquals("Property 'tab_width' expects an integer. The parsed '1.5' is not an integer.",
                malformed.getErrorMessage());
    }

    @Test
    public void indentSizeAcceptsTabAndPositiveIntegers() {
        PropertyType.PropertyValue<Integer> tab = PropertyType.indent_size.parse("TAB");
        assertTrue(tab.isValid());
        assertNull(tab.getParsed());
        assertEquals("TAB", tab.getSource());

        assertEquals(Integer.valueOf(4), PropertyType.indent_size.parse("4").getParsed());
        assertFalse(PropertyType.indent_size.parse("-1").isValid());
    }

    @Test
    public void enumParsersAndEndOfLineMappingsWork() {
        assertEquals(PropertyType.EndOfLineValue.cr, PropertyType.end_of_line.parse("CR").getParsed());
        assertEquals(PropertyType.EndOfLineValue.crlf, PropertyType.EndOfLineValue.ofEndOfLineString("\r\n"));
        assertEquals(PropertyType.EndOfLineValue.cr, PropertyType.EndOfLineValue.ofEndOfLineString("\r"));
        assertEquals(PropertyType.EndOfLineValue.lf, PropertyType.EndOfLineValue.ofEndOfLineString("\n"));
        assertNull(PropertyType.EndOfLineValue.ofEndOfLineString("x"));
        assertNull(PropertyType.EndOfLineValue.ofEndOfLineString(null));

        assertEquals(PropertyType.IndentStyleValue.space, PropertyType.indent_style.parse("SPACE").getParsed());
        assertEquals(' ', PropertyType.IndentStyleValue.space.getIndentChar());
        assertEquals('\t', PropertyType.IndentStyleValue.tab.getIndentChar());

        PropertyType.PropertyValue<PropertyType.EndOfLineValue> invalid = PropertyType.end_of_line.parse("bad");
        assertFalse(invalid.isValid());
        assertEquals("Unexpected parsed \"bad\" for enum org.ec4j.core.model.PropertyType$EndOfLineValue",
                invalid.getErrorMessage());
        assertEquals("Cannot make enum org.ec4j.core.model.PropertyType$EndOfLineValue out of null",
                PropertyType.end_of_line.parse(null).getErrorMessage());
    }

    @Test
    public void enumValueSetsAreOrderedAndImmutable() {
        assertEquals(new LinkedHashSet<>(Arrays.asList("cr", "crlf", "lf")),
                PropertyType.EndOfLineValue.valueSet());
        assertEquals(new LinkedHashSet<>(Arrays.asList("space", "tab")),
                PropertyType.IndentStyleValue.valueSet());

        try {
            PropertyType.EndOfLineValue.valueSet().add("other");
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // Expected: enum value sets are immutable.
        }

        try {
            PropertyType.IndentStyleValue.valueSet().clear();
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // Expected: enum value sets are immutable.
        }
    }

    @Test
    public void propertyValuesImplementValueEqualityAndFormatting() {
        PropertyType.PropertyValue<String> first = PropertyType.PropertyValue.valid("source", "parsed");
        PropertyType.PropertyValue<String> same = PropertyType.PropertyValue.valid("source", "parsed");
        PropertyType.PropertyValue<String> different = PropertyType.PropertyValue.valid("source", "other");
        PropertyType.PropertyValue<String> invalid = PropertyType.PropertyValue.invalid("source", "error");

        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertNotEquals(first, invalid);
        assertNotEquals(first, null);
        assertNotEquals(first, "source");
        assertEquals("PropertyValue [errorMessage=null, parsed=parsed, source=source]", first.toString());
        assertEquals("PropertyValue [errorMessage=error, parsed=null, source=source]", invalid.toString());
    }

    @Test
    public void junitRunnerDiscoversTests() {
        assertTrue(1 + 1 == 2);
    }
}
