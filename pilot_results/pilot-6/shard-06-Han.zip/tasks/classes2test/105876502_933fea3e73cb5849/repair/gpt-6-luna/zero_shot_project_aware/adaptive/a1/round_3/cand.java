package org.ec4j.core.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

import org.junit.Test;

public class PropertyType_ArrowTest {

    @Test
    public void standardTypesContainAllWidelySupportedTypesInOrder() {
        Set<PropertyType<?>> types = PropertyType.standardTypes();

        assertEquals(new LinkedHashSet<PropertyType<?>>(Arrays.<PropertyType<?>>asList(
                PropertyType.charset, PropertyType.end_of_line, PropertyType.indent_size,
                PropertyType.indent_style, PropertyType.insert_final_newline, PropertyType.root,
                PropertyType.tab_width, PropertyType.trim_trailing_whitespace)), types);
        assertEquals(8, types.size());
    }

    @Test
    public void standardTypesAreUnmodifiable() {
        try {
            PropertyType.standardTypes().clear();
        } catch (UnsupportedOperationException expected) {
            return;
        }
        throw new AssertionError("standard types should be unmodifiable");
    }

    @Test
    public void constructorsAndAccessorsPreserveMetadataAndPossibleValues() {
        Set<String> values = new LinkedHashSet<String>(Arrays.asList("one", "two"));
        PropertyType<String> fromSet = new PropertyType<String>("sample", "description",
                PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER, values);

        assertEquals("sample", fromSet.getName());
        assertEquals("description", fromSet.getDescription());
        assertSame(values, fromSet.getPossibleValues());
        assertEquals("sample", fromSet.toString());

        PropertyType<String> fromArray = new PropertyType<String>("array", "array description",
                PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER, "one", "two", "one");
        assertEquals(new LinkedHashSet<String>(Arrays.asList("one", "two")), fromArray.getPossibleValues());
        try {
            fromArray.getPossibleValues().add("three");
            throw new AssertionError("possible values should be unmodifiable");
        } catch (UnsupportedOperationException expected) {
            // Expected.
        }
    }

    @Test
    public void baseNormalizationReturnsTheOriginalValue() {
        PropertyType<String> type = new PropertyType<String>("plain", "",
                PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER, Collections.<String>emptySet());
        String value = new String("MiXeD");

        assertSame(value, type.normalizeIfNeeded(value));
        assertNull(type.normalizeIfNeeded(null));
    }

    @Test
    public void lowerCasingNormalizationUsesUsLocaleAndHandlesNull() {
        PropertyType.LowerCasingPropertyType<String> type =
                new PropertyType.LowerCasingPropertyType<String>("lower", "",
                        PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER, "i");
        assertEquals("i", type.normalizeIfNeeded("I"));
        assertNull(type.normalizeIfNeeded(null));
    }

    @Test
    public void identityParserPreservesSourceAndParsedValue() {
        PropertyType<String> type = PropertyType.charset;
        PropertyType.PropertyValue<String> result = type.parse("CUSTOM");

        assertTrue(result.isValid());
        assertEquals("CUSTOM", result.getSource());
        assertEquals("CUSTOM", result.getParsed());
        assertNull(result.getErrorMessage());
    }

    @Test
    public void booleanParserAcceptsCaseInsensitiveValuesAndReportsErrors() {
        PropertyType.PropertyValue<Boolean> yes = PropertyType.insert_final_newline.parse("TrUe");
        assertTrue(yes.isValid());
        assertEquals(Boolean.TRUE, yes.getParsed());
        assertEquals("TrUe", yes.getSource());

        PropertyType.PropertyValue<Boolean> no = PropertyType.root.parse("FALSE");
        assertTrue(no.isValid());
        assertEquals(Boolean.FALSE, no.getParsed());

        PropertyType.PropertyValue<Boolean> invalid = PropertyType.root.parse("yes");
        assertFalse(invalid.isValid());
        assertEquals("Property 'root' expects a boolean. The parsed 'yes' is not a boolean.",
                invalid.getErrorMessage());

        PropertyType.PropertyValue<Boolean> missing = PropertyType.root.parse(null);
        assertFalse(missing.isValid());
        assertEquals("Property 'root' expects a boolean; found: null", missing.getErrorMessage());
        assertNull(missing.getSource());
    }

    @Test
    public void positiveIntegerParserValidatesPositiveNumbers() {
        PropertyType.PropertyValue<Integer> valid = PropertyType.tab_width.parse("12");
        assertTrue(valid.isValid());
        assertEquals(Integer.valueOf(12), valid.getParsed());

        PropertyType.PropertyValue<Integer> zero = PropertyType.tab_width.parse("0");
        assertFalse(zero.isValid());
        assertEquals("Property 'tab_width' expects a positive integer; found '0'", zero.getErrorMessage());

        PropertyType.PropertyValue<Integer> invalid = PropertyType.tab_width.parse("abc");
        assertFalse(invalid.isValid());
        assertEquals("Property 'tab_width' expects an integer. The parsed 'abc' is not an integer.",
                invalid.getErrorMessage());
    }

    @Test
    public void indentSizeAcceptsTabAndPositiveIntegers() {
        PropertyType.PropertyValue<Integer> tab = PropertyType.indent_size.parse("TAB");
        assertTrue(tab.isValid());
        assertNull(tab.getParsed());

        PropertyType.PropertyValue<Integer> number = PropertyType.indent_size.parse("4");
        assertTrue(number.isValid());
        assertEquals(Integer.valueOf(4), number.getParsed());

        assertFalse(PropertyType.indent_size.parse("-1").isValid());
    }

    @Test
    public void enumParserAndEndOfLineHelpersHandleSupportedValues() {
        assertEquals(PropertyType.EndOfLineValue.cr, PropertyType.end_of_line.parse("CR").getParsed());
        assertEquals(PropertyType.EndOfLineValue.crlf, PropertyType.EndOfLineValue.ofEndOfLineString("\r\n"));
        assertEquals(PropertyType.EndOfLineValue.lf, PropertyType.EndOfLineValue.ofEndOfLineString("\n"));
        assertNull(PropertyType.EndOfLineValue.ofEndOfLineString("invalid"));

        PropertyType.PropertyValue<PropertyType.EndOfLineValue> invalid = PropertyType.end_of_line.parse("invalid");
        assertFalse(invalid.isValid());
        assertEquals("Unexpected parsed \"invalid\" for enum " + PropertyType.EndOfLineValue.class.getName(),
                invalid.getErrorMessage());

        PropertyType.PropertyValue<PropertyType.EndOfLineValue> missing = PropertyType.end_of_line.parse(null);
        assertFalse(missing.isValid());
        assertEquals("Cannot make enum " + PropertyType.EndOfLineValue.class.getName() + " out of null",
                missing.getErrorMessage());
    }

    @Test
    public void enumValueSetsAndIndentCharactersAreCorrectAndImmutable() {
        assertEquals(new LinkedHashSet<String>(Arrays.asList("cr", "crlf", "lf")),
                PropertyType.EndOfLineValue.valueSet());
        assertEquals(new LinkedHashSet<String>(Arrays.asList("space", "tab")),
                PropertyType.IndentStyleValue.valueSet());
        assertEquals('\t', PropertyType.IndentStyleValue.tab.getIndentChar());
        assertEquals(' ', PropertyType.IndentStyleValue.space.getIndentChar());
        assertEquals("\r", PropertyType.EndOfLineValue.cr.getEndOfLineString());
        assertEquals("\r\n", PropertyType.EndOfLineValue.crlf.getEndOfLineString());
        assertEquals("\n", PropertyType.EndOfLineValue.lf.getEndOfLineString());

        try {
            PropertyType.EndOfLineValue.valueSet().add("other");
            throw new AssertionError("enum values should be unmodifiable");
        } catch (UnsupportedOperationException expected) {
            // Expected.
        }
    }

    @Test
    public void propertyValuesExposeStateAndImplementValueEquality() {
        PropertyType.PropertyValue<String> valid =
                PropertyType.PropertyValue.valid("source", "parsed");
        PropertyType.PropertyValue<String> same =
                PropertyType.PropertyValue.valid("source", "parsed");
        PropertyType.PropertyValue<String> invalid =
                PropertyType.PropertyValue.invalid("source", "problem");

        assertTrue(valid.isValid());
        assertEquals("source", valid.getSource());
        assertEquals("parsed", valid.getParsed());
        assertNull(valid.getErrorMessage());
        assertEquals(valid, same);
        assertEquals(valid.hashCode(), same.hashCode());
        assertFalse(valid.equals(invalid));
        assertFalse(valid.equals(null));
        assertFalse(valid.equals("not a property value"));
        assertTrue(invalid.toString().contains("errorMessage=problem"));
        assertFalse(invalid.isValid());
        assertNull(invalid.getParsed());
    }

    @Test
    public void junitRunnerDiscoversThisTestClass() {
        assertTrue(1 + 1 == 2);
    }
}
