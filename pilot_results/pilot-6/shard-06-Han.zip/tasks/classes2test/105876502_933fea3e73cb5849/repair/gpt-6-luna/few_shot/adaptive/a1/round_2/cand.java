package org.ec4j.core.model;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

import org.junit.Test;

import static org.junit.Assert.*;

public class PropertyType_ArrowTest {

    @Test
    public void standardTypesContainAllWidelySupportedTypes() {
        Set<PropertyType<?>> types = PropertyType.standardTypes();

        assertEquals(8, types.size());
        assertTrue(types.containsAll(Arrays.asList(
                PropertyType.charset,
                PropertyType.end_of_line,
                PropertyType.indent_size,
                PropertyType.indent_style,
                PropertyType.insert_final_newline,
                PropertyType.root,
                PropertyType.tab_width,
                PropertyType.trim_trailing_whitespace)));
        try {
            types.clear();
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // Expected: standard types are immutable.
        }
    }

    @Test
    public void propertyTypeExposesItsConfigurationAndIdentityNormalization() {
        PropertyType<String> type = new PropertyType<String>("custom", "description",
                PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER, "one", "two");

        assertEquals("custom", type.getName());
        assertEquals("description", type.getDescription());
        assertEquals(new LinkedHashSet<String>(Arrays.asList("one", "two")), type.getPossibleValues());
        assertEquals("custom", type.toString());
        assertSame("Mixed", type.normalizeIfNeeded("Mixed"));
        assertNull(type.normalizeIfNeeded(null));
        try {
            type.getPossibleValues().add("three");
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // Expected: possible values are immutable.
        }
    }

    @Test
    public void lowerCasingNormalizationUsesUsLocaleAndPreservesNull() {
        PropertyType.LowerCasingPropertyType<String> type =
                new PropertyType.LowerCasingPropertyType<String>("name", "",
                        PropertyType.PropertyValueParser.IDENTITY_VALUE_PARSER);

        assertEquals("mixed", type.normalizeIfNeeded("MiXeD"));
        assertNull(type.normalizeIfNeeded(null));
    }

    @Test
    public void endOfLineValuesMapStringsAndExposeImmutableNames() {
        assertEquals(PropertyType.EndOfLineValue.cr,
                PropertyType.EndOfLineValue.ofEndOfLineString("\r"));
        assertEquals(PropertyType.EndOfLineValue.crlf,
                PropertyType.EndOfLineValue.ofEndOfLineString("\r\n"));
        assertEquals(PropertyType.EndOfLineValue.lf,
                PropertyType.EndOfLineValue.ofEndOfLineString("\n"));
        assertNull(PropertyType.EndOfLineValue.ofEndOfLineString("invalid"));
        assertEquals(new LinkedHashSet<String>(Arrays.asList("cr", "crlf", "lf")),
                PropertyType.EndOfLineValue.valueSet());
        try {
            PropertyType.EndOfLineValue.valueSet().add("invalid");
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // Expected: enum names are immutable.
        }
        assertEquals("\r", PropertyType.EndOfLineValue.cr.getEndOfLineString());
        assertEquals("\r\n", PropertyType.EndOfLineValue.crlf.getEndOfLineString());
        assertEquals("\n", PropertyType.EndOfLineValue.lf.getEndOfLineString());
    }

    @Test
    public void indentStyleValuesExposeCharactersAndImmutableNames() {
        assertEquals(' ', PropertyType.IndentStyleValue.space.getIndentChar());
        assertEquals('\t', PropertyType.IndentStyleValue.tab.getIndentChar());
        assertEquals(new LinkedHashSet<String>(Arrays.asList("space", "tab")),
                PropertyType.IndentStyleValue.valueSet());
        try {
            PropertyType.IndentStyleValue.valueSet().add("invalid");
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // Expected: enum names are immutable.
        }
    }

    @Test
    public void booleanParserAcceptsCaseInsensitiveValuesAndReportsInvalidInput() {
        PropertyType.PropertyValue<Boolean> trueValue = PropertyType.insert_final_newline.parse("TrUe");
        assertTrue(trueValue.isValid());
        assertEquals(Boolean.TRUE, trueValue.getParsed());
        assertEquals("TrUe", trueValue.getSource());

        PropertyType.PropertyValue<Boolean> falseValue = PropertyType.root.parse("FALSE");
        assertTrue(falseValue.isValid());
        assertEquals(Boolean.FALSE, falseValue.getParsed());

        PropertyType.PropertyValue<Boolean> invalid = PropertyType.root.parse("yes");
        assertFalse(invalid.isValid());
        assertNull(invalid.getParsed());
        assertEquals("Property 'root' expects a boolean. The parsed 'yes' is not a boolean.",
                invalid.getErrorMessage());

        PropertyType.PropertyValue<Boolean> nullValue = PropertyType.root.parse(null);
        assertFalse(nullValue.isValid());
        assertEquals("Property 'root' expects a boolean; found: null", nullValue.getErrorMessage());
    }

    @Test
    public void positiveIntegerParserDistinguishesPositiveNonPositiveAndMalformedValues() {
        PropertyType.PropertyValue<Integer> valid = PropertyType.tab_width.parse("12");
        assertTrue(valid.isValid());
        assertEquals(Integer.valueOf(12), valid.getParsed());

        PropertyType.PropertyValue<Integer> zero = PropertyType.tab_width.parse("0");
        assertFalse(zero.isValid());
        assertEquals("Property 'tab_width' expects a positive integer; found '0'", zero.getErrorMessage());

        PropertyType.PropertyValue<Integer> malformed = PropertyType.tab_width.parse("abc");
        assertFalse(malformed.isValid());
        assertEquals("Property 'tab_width' expects an integer. The parsed 'abc' is not an integer.",
                malformed.getErrorMessage());
    }

    @Test
    public void indentSizeAcceptsTabAndPositiveIntegers() {
        PropertyType.PropertyValue<Integer> tab = PropertyType.indent_size.parse("TAB");
        assertTrue(tab.isValid());
        assertNull(tab.getParsed());

        PropertyType.PropertyValue<Integer> number = PropertyType.indent_size.parse("4");
        assertTrue(number.isValid());
        assertEquals(Integer.valueOf(4), number.getParsed());

        assertFalse(PropertyType.indent_size.parse("-1").isValid());
    }

    @Test
    public void enumParserAndLowerCasingTypesParseCaseInsensitively() {
        PropertyType.PropertyValue<PropertyType.EndOfLineValue> eol = PropertyType.end_of_line.parse("CRLF");
        assertTrue(eol.isValid());
        assertEquals(PropertyType.EndOfLineValue.crlf, eol.getParsed());

        PropertyType.PropertyValue<PropertyType.IndentStyleValue> style = PropertyType.indent_style.parse("SPACE");
        assertTrue(style.isValid());
        assertEquals(PropertyType.IndentStyleValue.space, style.getParsed());

        PropertyType.PropertyValue<PropertyType.EndOfLineValue> invalid = PropertyType.end_of_line.parse("unknown");
        assertFalse(invalid.isValid());
        assertEquals("Unexpected parsed \"unknown\" for enum " + PropertyType.EndOfLineValue.class.getName(),
                invalid.getErrorMessage());

        PropertyType.PropertyValue<PropertyType.EndOfLineValue> nullValue = PropertyType.end_of_line.parse(null);
        assertFalse(nullValue.isValid());
        assertEquals("Cannot make enum " + PropertyType.EndOfLineValue.class.getName() + " out of null",
                nullValue.getErrorMessage());
    }

    @Test
    public void propertyValuesImplementEqualityHashCodeAndStringRepresentation() {
        PropertyType.PropertyValue<String> first = PropertyType.PropertyValue.valid("source", "parsed");
        PropertyType.PropertyValue<String> same = PropertyType.PropertyValue.valid("source", "parsed");
        PropertyType.PropertyValue<String> different = PropertyType.PropertyValue.valid("other", "parsed");
        PropertyType.PropertyValue<String> invalid = PropertyType.PropertyValue.invalid("source", "bad");

        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertNotEquals(first, invalid);
        assertEquals("source", first.getSource());
        assertEquals("parsed", first.getParsed());
        assertNull(first.getErrorMessage());
        assertTrue(first.isValid());
        assertFalse(invalid.isValid());
        assertEquals("bad", invalid.getErrorMessage());
        assertEquals("PropertyValue [errorMessage=null, parsed=parsed, source=source]", first.toString());
        assertNotEquals(first, null);
        assertNotEquals(first, "source");
    }

    @Test
    public void identityParserPreservesNullAndSource() {
        PropertyType.PropertyValue<String> value = PropertyType.charset.parse("UTF-8");
        assertTrue(value.isValid());
        assertEquals("UTF-8", value.getSource());
        assertEquals("UTF-8", value.getParsed());

        PropertyType.PropertyValue<String> nullValue = PropertyType.charset.parse(null);
        assertTrue(nullValue.isValid());
        assertNull(nullValue.getSource());
        assertNull(nullValue.getParsed());
    }
}
