package edu.berkeley.cs.jqf.fuzz.rl;

import org.json.JSONException;
import org.junit.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.*;

public class RLParamParser_ArrowTest {

    @Test
    public void example() {
        assertTrue(1 + 1 == 2);
    }

    @Test
    public void parsesAllSupportedParameterTypes() {
        RLParams params = new RLParamParser().getParams("{\"params\":[" +
                "{\"name\":\"text\",\"type\":\"string\",\"val\":\"hello\"}," +
                "{\"name\":\"enabled\",\"type\":\"bool\",\"val\":true}," +
                "{\"name\":\"large\",\"type\":\"long\",\"val\":1234567890123}," +
                "{\"name\":\"count\",\"type\":\"int\",\"val\":42}," +
                "{\"name\":\"ratio\",\"type\":\"double\",\"val\":2.5}," +
                "{\"name\":\"words\",\"type\":\"string_array\",\"val\":[\"a\",\"b\"]}," +
                "{\"name\":\"flags\",\"type\":\"bool_array\",\"val\":[true,false]}," +
                "{\"name\":\"numbers\",\"type\":\"int_array\",\"val\":[1,2,3]}," +
                "{\"name\":\"values\",\"type\":\"double_array\",\"val\":[1.25,2.5]}]}");

        assertEquals("hello", params.get("text"));
        assertEquals(Boolean.TRUE, params.get("enabled"));
        assertEquals(Long.valueOf(1234567890123L), params.get("large"));
        assertEquals(Integer.valueOf(42), params.get("count"));
        assertEquals(Double.valueOf(2.5), params.get("ratio"));
        assertEquals(Arrays.asList("a", "b"), params.get("words"));
        assertEquals(Arrays.asList(true, false), params.get("flags"));
        assertEquals(Arrays.asList(1, 2, 3), params.get("numbers"));
        assertEquals(Arrays.asList(1.25, 2.5), params.get("values"));
    }

    @Test
    public void parsesEmptyParamsArray() {
        RLParams params = new RLParamParser().getParams("{\"params\":[]}");
        assertNotNull(params);
        assertNull(params.get("missing"));
    }

    @Test
    public void rejectsJsonWithoutParamsRoot() {
        try {
            new RLParamParser().getParams("{\"other\":[]}");
            fail("Expected JSONException");
        } catch (JSONException expected) {
            assertTrue(expected.getMessage().contains("params"));
        }
    }

    @Test
    public void ignoresUnknownParameterTypes() {
        RLParams params = new RLParamParser().getParams(
                "{\"params\":[{\"name\":\"ignored\",\"type\":\"unknown\",\"val\":1}]}");
        assertNull(params.get("ignored"));
    }

    @Test
    public void parsesParamsFromFile() throws IOException {
        Path file = Files.createTempFile("rl-params", ".json");
        try {
            Files.write(file, Collections.singletonList(
                    "{\"params\":[{\"name\":\"fromFile\",\"type\":\"int\",\"val\":7}]}"),
                    StandardCharsets.UTF_8);

            RLParams params = new RLParamParser().getParamsFile(file.toString());
            assertEquals(Integer.valueOf(7), params.get("fromFile"));
        } finally {
            Files.deleteIfExists(file);
        }
    }
}
