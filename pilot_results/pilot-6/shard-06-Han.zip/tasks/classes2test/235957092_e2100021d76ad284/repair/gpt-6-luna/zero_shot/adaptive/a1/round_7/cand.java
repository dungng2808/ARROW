package edu.berkeley.cs.jqf.fuzz.rl;

import static org.junit.Assert.*;

import org.junit.Test;

public class RLParamParser_ArrowTest {
    @Test
    public void example() {
        assertTrue(1 + 1 == 2);
    }
}
