package edu.berkeley.cs.jqf.fuzz.rl;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class RLParamParser_ArrowTest {

    @Test
    public void example() {
        assertTrue(1 + 1 == 2);
    }
}
