package edu.berkeley.cs.jqf.fuzz.rl;

import org.json.JSONException;
import org.junit.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import static org.junit.Assert.*;

public class RLParamParser_ArrowTest {

    @Test
    public void parsesAllSupportedParameterTypes() {
        RLParamParser parser = new RLParamParser();
        String json = "{\"params\":["
                + "{\"name\":\"text\",\"type\":\"string\",\"val\":\"hello\"},"
                + "{\"name\":\"enabled\",\"type\":\"bool\",\"val\":true},"
                + "{\"name\":\"large\",\"type\":\"long\",\"val\":1234567890123},"
                + "{\"name\":\"count\",\"type\":\"int\",\"val\":42},"
                + "{\"name\":\"ratio\",\"type\":\"double\",\"val\":2.5},"
                + "{\"name\":\"words\",\"type\":\"string_array\",\"val\":[\"one\",\"two\"]},"
                + "{\"name\":\"flags\",\"type\":\"bool_array\",\"val\":[true,false]},"
                + "{\"name\":\"counts\",\"type\":\"int_array\",\"val\":[1,2,3]},"
                + "{\"name\":\"ratios\",\"type\":\"double_array\",\"val\":[1.25,2.5]}"
                + "]}";

        RLParams params = parser.getParams(json);

        assertNotNull(params);
        assertEquals("hello", params.get("text"));
        assertEquals(Boolean.TRUE, params.get("enabled"));
        assertEquals(Long.valueOf(1234567890123L), params.get("large"));
        assertEquals(Integer.valueOf(42), params.get("count"));
        assertEquals(Double.valueOf(2.5), params.get("ratio"));
        assertEquals(Arrays.asList("one", "two"), params.get("words"));
        assertEquals(Arrays.asList(true, false), params.get("flags"));
        assertEquals(Arrays.asList(1, 2, 3), params.get("counts"));
        assertEquals(Arrays.asList(1.25, 2.5), params.get("ratios"));
    }

    @Test
    public void parsesEmptyParamsArray() {
        RLParams params = new RLParamParser().getParams("{\"params\":[]}");
        assertNotNull(params);
    }

    @Test
    public void rejectsJsonWithoutParamsRoot() {
        try {
            new RLParamParser().getParams("{\"other\":[]}");
            fail("Expected a JSONException");
        } catch (JSONException expected) {
            assertTrue(expected.getMessage().contains("params"));
        }
    }

    @Test
    public void parsesParamsFromFile() throws IOException {
        Path file = Files.createTempFile("rl-params", ".json");
        try {
            Files.write(file, "{\"params\":[{\"name\":\"answer\",\"type\":\"int\",\"val\":7}]}"
                    .getBytes(StandardCharsets.UTF_8));

            RLParams params = new RLParamParser().getParamsFile(file.toString());

            assertEquals(Integer.valueOf(7), params.get("answer"));
        } finally {
            Files.deleteIfExists(file);
        }
    }

    @Test
    public void example() {
        assertTrue(1 + 1 == 2);
    }
}
