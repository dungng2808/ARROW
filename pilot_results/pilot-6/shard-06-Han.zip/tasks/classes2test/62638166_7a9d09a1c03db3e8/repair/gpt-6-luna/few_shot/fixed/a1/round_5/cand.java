package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import org.junit.Test;

public class FlowParser_ArrowTest {

    @Test
    public void createReturnsParser() {
        assertNotNull(FlowParser.create());
    }

    @Test
    public void createWithConfigurationReturnsParser() {
        assertNotNull(FlowParser.create(new FlowConfiguration(Charset.defaultCharset())));
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String path = new File("missing-flow-parser-test-file.flow").getAbsolutePath();
        try {
            FlowParser.parseFile(path);
            fail("Expected an AssertionError for a missing file");
        } catch (AssertionError expected) {
            // Expected.
        }
    }

    @Test
    public void parseFileParsesExistingFile() throws Exception {
        File file = Files.createTempFile("flow-parser-test", ".flow").toFile();
        try {
            Files.write(file.toPath(), validFlowSource().getBytes(Charset.defaultCharset()));
            assertNotNull(FlowParser.parseFile(file.getAbsolutePath()));
        } finally {
            Files.deleteIfExists(file.toPath());
        }
    }

    @Test
    public void parseStringParsesSource() {
        assertNotNull(FlowParser.parseString(validFlowSource()));
    }

    private static String validFlowSource() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<Values>\n"
                + "  <value name=\"test\">value</value>\n"
                + "</Values>\n";
    }
}
