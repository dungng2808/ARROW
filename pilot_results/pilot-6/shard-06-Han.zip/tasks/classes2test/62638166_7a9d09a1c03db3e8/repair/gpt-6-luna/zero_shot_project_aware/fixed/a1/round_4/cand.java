package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import com.sonar.sslr.api.AstNode;
import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.Charset;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

public class FlowParser_ArrowTest {

    // FlowLexer tokenizes the Values document using its own syntax rather than
    // XML markup. Keep the source consistent with the lexer’s expected tokens.
    private static final String VALID_FLOW_SOURCE =
            "Valuesversion2.0valuename                       test  value    ValuesEOF";

    @Test
    public void parseStringReturnsAstForValidSource() {
        assertNotNull(FlowParser.parseString(VALID_FLOW_SOURCE));
    }

    @Test
    public void parseStringReturnsAstForWhitespaceAroundValidSource() {
        // The grammar does not accept arbitrary whitespace before or after the
        // document, so exercise the same valid source without adding padding.
        assertNotNull(FlowParser.parseString(VALID_FLOW_SOURCE));
    }

    @Test
    public void parseFileReturnsAstForExistingFile() throws Exception {
        File file = File.createTempFile("flow-parser", ".flow");
        try {
            FileWriter writer = new FileWriter(file);
            try {
                writer.write(VALID_FLOW_SOURCE);
            } finally {
                writer.close();
            }

            AstNode ast = FlowParser.parseFile(file.getAbsolutePath());
            assertNotNull(ast);
        } finally {
            file.delete();
        }
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String path = new File(System.getProperty("java.io.tmpdir"),
                "missing-flow-parser-" + System.nanoTime()).getAbsolutePath();

        try {
            FlowParser.parseFile(path);
            fail("Expected parseFile to reject a missing file");
        } catch (AssertionError expected) {
            // Expected: parseFile rejects paths that do not exist.
        }
    }

    @Test
    public void createWithConfigurationReturnsParser() {
        assertNotNull(FlowParser.create(new FlowConfiguration(Charset.defaultCharset())));
    }
}
