package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.api.RecognitionException;
import org.junit.Test;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

public class FlowParser_ArrowTest {

    @Test
    public void createWithConfigurationReturnsParserThatRejectsEmptySource() {
        assertNotNull(FlowParser.create(new FlowConfiguration(Charset.defaultCharset())));
        assertEmptySourceRejected();
    }

    @Test
    public void createReturnsParserThatRejectsEmptySource() {
        assertNotNull(FlowParser.create());
        assertEmptySourceRejected();
    }

    @Test
    public void parseFileRejectsEmptyExistingFile() throws Exception {
        File file = Files.createTempFile("flow-parser", ".flow").toFile();
        try {
            Files.write(file.toPath(), new byte[0]);
            try {
                FlowParser.parseFile(file.getAbsolutePath());
                fail("Expected parseFile to reject an empty file");
            } catch (RecognitionException expected) {
                // Empty input is not a valid Flow source.
            }
        } finally {
            Files.deleteIfExists(file.toPath());
        }
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String missingPath = new File(System.getProperty("java.io.tmpdir"),
                "flow-parser-missing-" + System.nanoTime()).getAbsolutePath();

        try {
            FlowParser.parseFile(missingPath);
            fail("Expected parseFile to reject a missing file");
        } catch (AssertionError expected) {
            // Expected: parseFile reports missing files with an AssertionError.
        }
    }

    private static void assertEmptySourceRejected() {
        try {
            FlowParser.parseString("");
            fail("Expected the parser to reject empty source");
        } catch (RecognitionException expected) {
            // Empty input is not a valid Flow source.
        }
    }
}
