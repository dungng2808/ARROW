package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import org.junit.Test;

public class FlowParser_ArrowTest {

    // A minimal valid Flow document; the parser does not accept empty input.
    private static final String VALID_SOURCE =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<Values version=\"2.0\">\n"
                    + "  <value name=\"name\">test</value>\n"
                    + "</Values>\n";

    @Test
    public void createReturnsParser() {
        assertNotNull(FlowParser.create());
    }

    @Test
    public void createWithConfigurationReturnsParser() {
        assertNotNull(FlowParser.create(new FlowConfiguration(Charset.defaultCharset())));
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String path = new File("missing-flow-parser-test-file.flow").getAbsolutePath();
        try {
            FlowParser.parseFile(path);
            fail("Expected an AssertionError for a missing file");
        } catch (AssertionError expected) {
            // Expected.
        }
    }

    @Test
    public void parseFileParsesExistingFile() throws Exception {
        File file = Files.createTempFile("flow-parser-test", ".flow").toFile();
        try {
            Files.write(file.toPath(), VALID_SOURCE.getBytes(Charset.defaultCharset()));
            assertNotNull(FlowParser.parseFile(file.getAbsolutePath()));
        } finally {
            Files.deleteIfExists(file.toPath());
        }
    }

    @Test
    public void parseStringParsesSource() {
        assertNotNull(FlowParser.parseString(VALID_SOURCE));
    }
}
