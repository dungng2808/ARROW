package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import com.sonar.sslr.api.AstNode;
import org.junit.Test;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

public class FlowParser_ArrowTest {

    @Test
    public void createWithConfigurationReturnsParserThatParsesEmptySource() {
        assertNotNull(FlowParser.create(new FlowConfiguration(Charset.defaultCharset())));
        assertNotNull(FlowParser.parseString(""));
    }

    @Test
    public void createReturnsParserThatParsesEmptySource() {
        assertNotNull(FlowParser.create());
        assertNotNull(FlowParser.parseString(""));
    }

    @Test
    public void parseFileParsesExistingFile() throws Exception {
        File file = Files.createTempFile("flow-parser", ".flow").toFile();
        try {
            Files.write(file.toPath(), new byte[0]);
            AstNode result = FlowParser.parseFile(file.getAbsolutePath());
            assertNotNull(result);
        } finally {
            Files.deleteIfExists(file.toPath());
        }
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String missingPath = new File(System.getProperty("java.io.tmpdir"),
                "flow-parser-missing-" + System.nanoTime()).getAbsolutePath();

        assertThrows(AssertionError.class, () -> FlowParser.parseFile(missingPath));
    }
}
