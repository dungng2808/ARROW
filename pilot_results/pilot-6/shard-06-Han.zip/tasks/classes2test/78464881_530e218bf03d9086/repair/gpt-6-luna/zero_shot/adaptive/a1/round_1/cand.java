package com.solace.spring.boot.autoconfigure;

import com.solace.services.core.model.SolaceServiceCredentials;
import com.solace.spring.cloud.core.SolaceMessagingInfo;
import org.junit.Test;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.ServiceInfo;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class SolaceJmsAutoCloudConfiguration_ArrowTest {

    @Test
    void returnsFirstSolaceMessagingInfoAndStopsSearching() throws Exception {
        SolaceJmsAutoCloudConfiguration configuration = newConfiguration();
        SolaceMessagingInfo first = mock(SolaceMessagingInfo.class);
        SolaceMessagingInfo second = mock(SolaceMessagingInfo.class);
        ServiceInfo unrelated = mock(ServiceInfo.class);
        setCloud(configuration, cloudWith(unrelated, first, second));

        assertSame(first, configuration.findFirstSolaceMessagingInfo());
    }

    @Test
    void throwsWhenCloudHasNoSolaceMessagingInfo() throws Exception {
        SolaceJmsAutoCloudConfiguration configuration = newConfiguration();
        setCloud(configuration, cloudWith(mock(ServiceInfo.class)));

        try {
            configuration.findFirstSolaceMessagingInfo();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException exception) {
            assertEquals(
                    "Unable to create SolConnectionFactory did not find SolaceMessagingInfo in the current cloud environment",
                    exception.getMessage());
        }
    }

    @Test
    void returnsAllSolaceMessagingInfosInCloudOrder() throws Exception {
        SolaceJmsAutoCloudConfiguration configuration = newConfiguration();
        SolaceMessagingInfo first = mock(SolaceMessagingInfo.class);
        SolaceMessagingInfo second = mock(SolaceMessagingInfo.class);
        setCloud(configuration, cloudWith(mock(ServiceInfo.class), first, second));

        List<SolaceMessagingInfo> result = configuration.getSolaceMessagingInfos();

        assertEquals(2, result.size());
        assertSame(first, result.get(0));
        assertSame(second, result.get(1));
    }

    @Test
    void exposesMessagingInfosAsServiceCredentials() throws Exception {
        SolaceJmsAutoCloudConfiguration configuration = newConfiguration();
        SolaceMessagingInfo first = mock(SolaceMessagingInfo.class);
        SolaceMessagingInfo second = mock(SolaceMessagingInfo.class);
        setCloud(configuration, cloudWith(first, second));

        List<SolaceServiceCredentials> result = configuration.getSolaceServiceCredentials();

        assertEquals(2, result.size());
        assertSame(first, result.get(0));
        assertSame(second, result.get(1));
    }

    @Test
    void returnsEmptyListsWhenCloudHasNoServices() throws Exception {
        SolaceJmsAutoCloudConfiguration configuration = newConfiguration();
        setCloud(configuration, cloudWith());

        assertEquals(Collections.emptyList(), configuration.getSolaceMessagingInfos());
        assertEquals(Collections.emptyList(), configuration.getSolaceServiceCredentials());
    }

    private static SolaceJmsAutoCloudConfiguration newConfiguration() {
        return new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());
    }

    private static Cloud cloudWith(ServiceInfo... serviceInfos) {
        Cloud cloud = mock(Cloud.class);
        when(cloud.getServiceInfos()).thenReturn(Arrays.asList(serviceInfos));
        return cloud;
    }

    private static void setCloud(SolaceJmsAutoCloudConfiguration configuration, Cloud cloud)
            throws Exception {
        Field field = SolaceJmsAutoCloudConfiguration.class.getDeclaredField("cloudFactory");
        field.setAccessible(true);
        CloudFactory cloudFactory = mock(CloudFactory.class);
        when(cloudFactory.getCloud()).thenReturn(cloud);
        field.set(configuration, cloudFactory);
    }
}
