package com.solace.spring.boot.autoconfigure;

import com.solace.services.core.model.SolaceServiceCredentials;
import com.solace.spring.cloud.core.SolaceMessagingInfo;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.CloudConnector;
import org.springframework.cloud.service.ServiceInfo;
import org.springframework.cloud.service.ServiceConnectorCreator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

public class SolaceJmsAutoCloudConfiguration_ArrowTest {

  private SolaceJmsAutoCloudConfiguration configuration;

  @Before
  public void setUp() {
    configuration = new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());
  }

  @Test
  public void findsFirstSolaceMessagingInfoAmongOtherServices() throws Exception {
    SolaceMessagingInfo first = messagingInfo();
    SolaceMessagingInfo second = messagingInfo();
    ServiceInfo unrelated = serviceInfo("other");

    setCloudServices(Arrays.asList(unrelated, first, second));

    assertSame(first, configuration.findFirstSolaceMessagingInfo());
    assertSame(first, configuration.findFirstSolaceServiceCredentialsImpl());
  }

  @Test
  public void returnsAllSolaceMessagingInfosAndCredentials() throws Exception {
    SolaceMessagingInfo first = messagingInfo();
    SolaceMessagingInfo second = messagingInfo();
    ServiceInfo unrelated = serviceInfo("other");
    setCloudServices(Arrays.asList(first, unrelated, second));

    List<SolaceMessagingInfo> infos = configuration.getSolaceMessagingInfos();
    assertEquals(Arrays.asList(first, second), infos);

    List<SolaceServiceCredentials> credentials = configuration.getSolaceServiceCredentials();
    assertEquals(2, credentials.size());
    assertSame(first, credentials.get(0));
    assertSame(second, credentials.get(1));
  }

  @Test
  public void throwsWhenNoSolaceMessagingInfoExists() throws Exception {
    setCloudServices(Collections.singletonList(serviceInfo("other")));

    try {
      configuration.findFirstSolaceMessagingInfo();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException exception) {
      assertEquals(
          "Unable to create SolConnectionFactory did not find SolaceMessagingInfo in the current cloud environment",
          exception.getMessage());
    }
  }

  @Test
  public void returnedListsAreNonNullWhenCloudHasNoServices() throws Exception {
    setCloudServices(Collections.<ServiceInfo>emptyList());

    assertNotNull(configuration.getSolaceMessagingInfos());
    assertEquals(0, configuration.getSolaceMessagingInfos().size());
    assertNotNull(configuration.getSolaceServiceCredentials());
    assertEquals(0, configuration.getSolaceServiceCredentials().size());
  }

  private SolaceMessagingInfo messagingInfo() {
    return new SolaceMessagingInfo();
  }

  private ServiceInfo serviceInfo(final String id) {
    return new ServiceInfo() {
      @Override
      public String getId() {
        return id;
      }
    };
  }

  private void setCloudServices(final List<ServiceInfo> services) throws Exception {
    CloudConnector connector = new CloudConnector() {
      @Override
      public boolean isInMatchingCloud() {
        return true;
      }

      @Override
      public List<ServiceInfo> getServiceInfos() {
        return services;
      }
    };

    Cloud cloud = new Cloud(connector, Collections.<ServiceConnectorCreator<?, ?>>emptyList());

    CloudFactory factory = new CloudFactory();
    Field cloudField = CloudFactory.class.getDeclaredField("cloud");
    cloudField.setAccessible(true);
    cloudField.set(factory, cloud);

    Field factoryField = SolaceJmsAutoCloudConfiguration.class.getDeclaredField("cloudFactory");
    factoryField.setAccessible(true);
    factoryField.set(configuration, factory);
  }
}
