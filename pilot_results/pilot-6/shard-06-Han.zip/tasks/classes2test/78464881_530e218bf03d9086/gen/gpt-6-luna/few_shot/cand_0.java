package com.solace.spring.boot.autoconfigure;

import com.solace.services.core.model.SolaceServiceCredentials;
import com.solace.spring.cloud.core.SolaceMessagingInfo;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.ServiceInfo;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

class SolaceJmsAutoCloudConfiguration_ArrowTest {

  private SolaceJmsAutoCloudConfiguration configuration;

  @Before
  void setUp() {
    configuration = new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());
  }

  @Test
  void findsFirstSolaceMessagingInfoAmongOtherServices() throws Exception {
    SolaceMessagingInfo first = messagingInfo("first");
    SolaceMessagingInfo second = messagingInfo("second");
    ServiceInfo unrelated = new ServiceInfo("other") {};

    setCloudServices(Arrays.asList(unrelated, first, second));

    assertSame(first, configuration.findFirstSolaceMessagingInfo());
    assertSame(first, configuration.findFirstSolaceServiceCredentialsImpl());
  }

  @Test
  void returnsAllSolaceMessagingInfosAndCredentials() throws Exception {
    SolaceMessagingInfo first = messagingInfo("first");
    SolaceMessagingInfo second = messagingInfo("second");
    ServiceInfo unrelated = new ServiceInfo("other") {};
    setCloudServices(Arrays.asList(first, unrelated, second));

    List<SolaceMessagingInfo> infos = configuration.getSolaceMessagingInfos();
    assertEquals(Arrays.asList(first, second), infos);

    List<SolaceServiceCredentials> credentials = configuration.getSolaceServiceCredentials();
    assertEquals(2, credentials.size());
    assertSame(first, credentials.get(0));
    assertSame(second, credentials.get(1));
  }

  @Test
  void throwsWhenNoSolaceMessagingInfoExists() throws Exception {
    setCloudServices(Collections.singletonList(new ServiceInfo("other") {}));

    IllegalStateException exception =
        assertThrows(IllegalStateException.class, configuration::findFirstSolaceMessagingInfo);
    assertEquals(
        "Unable to create SolConnectionFactory did not find SolaceMessagingInfo in the current cloud environment",
        exception.getMessage());
  }

  @Test
  void returnedListsAreNonNullWhenCloudHasNoServices() throws Exception {
    setCloudServices(Collections.emptyList());

    assertNotNull(configuration.getSolaceMessagingInfos());
    assertEquals(0, configuration.getSolaceMessagingInfos().size());
    assertNotNull(configuration.getSolaceServiceCredentials());
    assertEquals(0, configuration.getSolaceServiceCredentials().size());
  }

  private SolaceMessagingInfo messagingInfo(String id) {
    return new SolaceMessagingInfo(id, Collections.emptyMap());
  }

  private void setCloudServices(List<ServiceInfo> services) throws Exception {
    Cloud cloud = new Cloud(null, services, null, null) {};
    CloudFactory factory = new CloudFactory();
    Field cloudField = CloudFactory.class.getDeclaredField("cloud");
    cloudField.setAccessible(true);
    cloudField.set(factory, cloud);

    Field factoryField = SolaceJmsAutoCloudConfiguration.class.getDeclaredField("cloudFactory");
    factoryField.setAccessible(true);
    factoryField.set(configuration, factory);
  }
}
