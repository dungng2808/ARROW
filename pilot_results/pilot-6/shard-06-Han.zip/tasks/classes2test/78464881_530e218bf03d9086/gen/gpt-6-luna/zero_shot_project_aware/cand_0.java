package com.solace.spring.boot.autoconfigure;

import com.solace.services.core.model.SolaceServiceCredentials;
import com.solace.spring.cloud.core.SolaceMessagingInfo;
import org.junit.Before;
import org.junit.Test;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.ServiceInfo;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class SolaceJmsAutoCloudConfiguration_ArrowTest {

    private SolaceJmsAutoCloudConfiguration configuration;
    private CloudFactory cloudFactory;
    private Cloud cloud;

    @Before
    public void setUp() throws Exception {
        configuration = new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());
        cloudFactory = mock(CloudFactory.class);
        cloud = mock(Cloud.class);

        Field field = SolaceJmsAutoCloudConfiguration.class.getDeclaredField("cloudFactory");
        field.setAccessible(true);
        field.set(configuration, cloudFactory);
        when(cloudFactory.getCloud()).thenReturn(cloud);
    }

    @Test
    public void findsFirstSolaceMessagingInfoAndStopsAtIt() {
        SolaceMessagingInfo first = mock(SolaceMessagingInfo.class);
        SolaceMessagingInfo second = mock(SolaceMessagingInfo.class);
        ServiceInfo unrelated = mock(ServiceInfo.class);
        when(first.getId()).thenReturn("first");
        when(cloud.getServiceInfos()).thenReturn(Arrays.<ServiceInfo>asList(unrelated, first, second));

        assertSame(first, configuration.findFirstSolaceMessagingInfo());
        verify(first).getId();
        verifyNoInteractions(second);
    }

    @Test
    public void throwsWhenCloudHasNoSolaceMessagingInfo() {
        when(cloud.getServiceInfos()).thenReturn(Collections.<ServiceInfo>emptyList());

        try {
            configuration.findFirstSolaceMessagingInfo();
            fail("Expected missing Solace service to be rejected");
        } catch (IllegalStateException expected) {
            assertEquals("Unable to create SolConnectionFactory did not find SolaceMessagingInfo in the current cloud environment",
                    expected.getMessage());
        }
    }

    @Test
    public void returnsAllSolaceMessagingInfosInCloudOrder() {
        SolaceMessagingInfo first = mock(SolaceMessagingInfo.class);
        SolaceMessagingInfo second = mock(SolaceMessagingInfo.class);
        ServiceInfo unrelated = mock(ServiceInfo.class);
        when(cloud.getServiceInfos()).thenReturn(Arrays.<ServiceInfo>asList(first, unrelated, second));

        List<SolaceMessagingInfo> result = configuration.getSolaceMessagingInfos();

        assertEquals(Arrays.asList(first, second), result);
    }

    @Test
    public void exposesMessagingInfosAsServiceCredentials() {
        SolaceMessagingInfo first = mock(SolaceMessagingInfo.class);
        SolaceMessagingInfo second = mock(SolaceMessagingInfo.class);
        when(cloud.getServiceInfos()).thenReturn(Arrays.<ServiceInfo>asList(first, second));

        List<SolaceServiceCredentials> result = configuration.getSolaceServiceCredentials();

        assertEquals(2, result.size());
        assertSame(first, result.get(0));
        assertSame(second, result.get(1));
    }
}
