package fr.xebia.ldi;

import com.jasongoodwin.monads.Try;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import org.apache.avro.Schema;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class RegistryActionFunction_ArrowTest {

    @TempDir
    File tempDir;

    private RegistryActionFunction function() {
        return new RegistryActionFunction(ConfigFactory.empty(), new SchemaRegistryClient() {
            @Override
            public int register(String subject, Schema schema) {
                throw new UnsupportedOperationException();
            }

            @Override
            public io.confluent.kafka.schemaregistry.client.rest.entities.Schema getByID(int id) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Schema getById(int id) {
                throw new UnsupportedOperationException();
            }

            @Override
            public io.confluent.kafka.schemaregistry.client.rest.entities.Schema getBySubjectAndID(
                    String subject, int id) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Schema getBySubjectAndId(String subject, int id) {
                throw new UnsupportedOperationException();
            }

            @Override
            public int getId(String subject, Schema schema) {
                throw new UnsupportedOperationException();
            }

            @Override
            public List<io.confluent.kafka.schemaregistry.client.rest.entities.Schema> getAllVersions(
                    String subject) {
                throw new UnsupportedOperationException();
            }

            @Override
            public SchemaMetadata getLatestSchemaMetadata(String subject) {
                throw new UnsupportedOperationException();
            }

            @Override
            public SchemaMetadata getSchemaMetadata(String subject, String version) {
                throw new UnsupportedOperationException();
            }

            @Override
            public boolean testCompatibility(String subject, Schema schema) {
                throw new UnsupportedOperationException();
            }

            @Override
            public List<Integer> getAllSubjects() {
                throw new UnsupportedOperationException();
            }

            @Override
            public List<String> getAllSubjectsById(int id) {
                throw new UnsupportedOperationException();
            }

            @Override
            public int getVersion(String subject, Schema schema) {
                throw new UnsupportedOperationException();
            }

            @Override
            public void reset() {
                throw new UnsupportedOperationException();
            }

            @Override
            public void close() {
            }
        });
    }

    @Test
    void lazilyCreatesYamlAndParser() {
        RegistryActionFunction function = function();

        assertNotNull(function.getYaml());
        assertSame(function.getYaml(), function.getYaml());
        assertNotNull(function.getParser());
        assertNotSame(function.getParser(), function.getParser());
    }

    @Test
    void mapsSubjectsToFilesUnderConfiguredDirectory() {
        Config config = ConfigFactory.parseString(
                "avro.files.path = \"" + tempDir.getAbsolutePath().replace("\\", "\\\\") + "\"");
        RegistryActionFunction function = new RegistryActionFunction(config, null);

        SchemaList.SubjectEntry first = new SchemaList.SubjectEntry();
        first.setSubject("orders");
        first.setFile("orders.avsc");
        SchemaList.SubjectEntry second = new SchemaList.SubjectEntry();
        second.setSubject("users");
        second.setFile("nested/users.avsc");

        List<KeyValuePair<String, File>> result =
                function.mapSubjectToFile(Arrays.asList(first, second));

        assertEquals(Arrays.asList("orders", "users"),
                result.stream().map(pair -> pair.key).collect(Collectors.toList()));
        assertEquals(new File(tempDir, "orders.avsc"), result.get(0).value);
        assertEquals(new File(tempDir, "nested/users.avsc"), result.get(1).value);
    }

    @Test
    void parsesSchemaFilesAndPreservesSubjects() throws IOException {
        File schemaFile = new File(tempDir, "order.avsc");
        Files.write(schemaFile.toPath(),
                "{\"type\":\"record\",\"name\":\"Order\",\"fields\":[{\"name\":\"id\",\"type\":\"string\"}]}"
                        .getBytes(StandardCharsets.UTF_8));

        RegistryActionFunction function = function();
        KeyValuePair<String, File> input = KeyValuePair.pair("orders", schemaFile);

        Try<KeyValuePair<String, Schema>> parsed = function.parseOne(input);
        assertTrue(parsed.isSuccess());
        assertEquals("orders", parsed.getUnchecked().key);
        assertEquals("Order", parsed.getUnchecked().value.getName());

        Try<List<KeyValuePair<String, Schema>>> all = function.parseAll(Collections.singletonList(input));
        assertTrue(all.isSuccess());
        assertEquals(1, all.getUnchecked().size());
        assertEquals("orders", all.getUnchecked().get(0).key);
    }

    @Test
    void parseAllFailsWhenAnySchemaFileIsInvalid() throws IOException {
        File invalid = new File(tempDir, "invalid.avsc");
        Files.write(invalid.toPath(), "not a schema".getBytes(StandardCharsets.UTF_8));

        Try<List<KeyValuePair<String, Schema>>> result =
                function().parseAll(Collections.singletonList(KeyValuePair.pair("bad", invalid)));

        assertFalse(result.isSuccess());
    }

    @Test
    void traversHandlesSuccessFailureAndEmptyInput() {
        RegistryActionFunction function = function();

        Try<List<Integer>> successes = function.travers(Arrays.asList(
                Try.ofFailable(() -> 1), Try.ofFailable(() -> 2)))
                .map(stream -> stream.collect(Collectors.toList()));
        assertTrue(successes.isSuccess());
        assertEquals(Arrays.asList(1, 2), successes.getUnchecked());

        Try<List<Integer>> failure = function.travers(Arrays.asList(
                Try.ofFailable(() -> 1),
                Try.<Integer>failure(new IllegalArgumentException("broken")),
                Try.<Integer>failure(new IllegalStateException("later"))))
                .map(stream -> stream.collect(Collectors.toList()));
        assertFalse(failure.isSuccess());

        Try<List<Integer>> empty = function.travers(Collections.<Try<Integer>>emptyList())
                .map(stream -> stream.collect(Collectors.toList()));
        assertTrue(empty.isSuccess());
        assertTrue(empty.getUnchecked().isEmpty());
    }

    @Test
    void loadsYamlSubjectsAndReportsMissingFiles() throws IOException {
        File yamlFile = new File(tempDir, "subjects.yaml");
        Files.write(yamlFile.toPath(),
                "schemas:\n  - subject: orders\n    file: orders.avsc\n"
                        .getBytes(StandardCharsets.UTF_8));

        Config config = ConfigFactory.parseString(
                "avro.subjects.yaml = \"" + yamlFile.getAbsolutePath().replace("\\", "\\\\") + "\"");
        RegistryActionFunction function = new RegistryActionFunction(config, null);

        Try<FileInputStream> stream = function.tryStreamFileSubjects();
        assertTrue(stream.isSuccess());
        Try<List<SchemaList.SubjectEntry>> parsed = function.parseYaml(stream.getUnchecked());
        assertTrue(parsed.isSuccess());
        assertEquals(1, parsed.getUnchecked().size());
        assertEquals("orders", parsed.getUnchecked().get(0).getSubject());
        stream.getUnchecked().close();

        Config missingConfig = ConfigFactory.parseString(
                "avro.subjects.yaml = \"" + new File(tempDir, "missing.yaml")
                        .getAbsolutePath().replace("\\", "\\\\") + "\"");
        assertFalse(new RegistryActionFunction(missingConfig, null)
                .tryStreamFileSubjects().isSuccess());
    }
}
