package fr.xebia.ldi;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import org.apache.avro.Schema;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class RegistryActionFunction_ArrowTest {

    private Config config() {
        return ConfigFactory.parseString(
                "avro.files.path = \"/tmp/schemas\"\n" +
                "avro.subjects.yaml = \"/tmp/subjects.yaml\"");
    }

    private RegistryActionFunction function() {
        return new RegistryActionFunction(config(), null);
    }

    @Test
    void lazilyCreatesYamlAndParser() {
        RegistryActionFunction function = function();

        assertNotNull(function.getYaml());
        assertSame(function.getYaml(), function.getYaml());
        assertNotNull(function.getParser());
        assertNotSame(function.getParser(), function.getParser());
    }

    @Test
    void mapsSubjectsToFiles() {
        RegistryActionFunction function = function();

        SchemaList.SubjectEntry first = new SchemaList.SubjectEntry();
        first.setSubject("first");
        first.setFile("first.avsc");

        SchemaList.SubjectEntry second = new SchemaList.SubjectEntry();
        second.setSubject("second");
        second.setFile("nested/second.avsc");

        List<KeyValuePair<String, File>> result =
                function.mapSubjectToFile(Arrays.asList(first, second));

        assertEquals(2, result.size());
        assertEquals("first", result.get(0).key);
        assertEquals(new File("/tmp/schemas", "first.avsc"), result.get(0).value);
        assertEquals("second", result.get(1).key);
        assertEquals(new File("/tmp/schemas", "nested/second.avsc"), result.get(1).value);
    }

    @Test
    void parsesSchemaFilesAndPreservesSubjects() throws Exception {
        RegistryActionFunction function = function();
        File schemaFile = Files.createTempFile("registry-action", ".avsc").toFile();
        schemaFile.deleteOnExit();
        Files.write(schemaFile.toPath(),
                "{\"type\":\"record\",\"name\":\"Example\",\"fields\":[]}".getBytes("UTF-8"));

        KeyValuePair<String, Schema> parsed =
                function.parseOne(KeyValuePair.pair("example-subject", schemaFile)).get();

        assertEquals("example-subject", parsed.key);
        assertEquals("Example", parsed.value.getName());
        assertTrue(function.parseAll(Collections.singletonList(
                KeyValuePair.pair("example-subject", schemaFile))).isSuccess());
    }

    @Test
    void parseAllFailsWhenAnySchemaIsInvalid() throws Exception {
        RegistryActionFunction function = function();
        File valid = Files.createTempFile("registry-valid", ".avsc").toFile();
        File invalid = Files.createTempFile("registry-invalid", ".avsc").toFile();
        valid.deleteOnExit();
        invalid.deleteOnExit();
        Files.write(valid.toPath(),
                "{\"type\":\"record\",\"name\":\"Valid\",\"fields\":[]}".getBytes("UTF-8"));
        Files.write(invalid.toPath(), "not a schema".getBytes("UTF-8"));

        assertFalse(function.parseAll(Arrays.asList(
                KeyValuePair.pair("valid", valid),
                KeyValuePair.pair("invalid", invalid))).isSuccess());
    }

    @Test
    void testsCompatibilityAndPropagatesFailure() {
        SchemaRegistryClient client = new SchemaRegistryClient() {
            @Override
            public boolean testCompatibility(String subject, Schema schema) {
                if ("broken".equals(subject)) {
                    throw new RuntimeException("registry unavailable");
                }
                return true;
            }

            @Override
            public void reset() {
                // No state to reset in this test client.
            }

            @Override
            public Integer deleteSchemaVersion(
                    java.util.Map<String, String> requestProperties,
                    String subject,
                    String version) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Integer deleteSchemaVersion(String subject, String version) {
                throw new UnsupportedOperationException();
            }
        };
        RegistryActionFunction function = new RegistryActionFunction(config(), client);
        Schema schema = new Schema.Parser().parse(
                "{\"type\":\"record\",\"name\":\"TestRecord\",\"fields\":[]}");

        KeyValuePair<String, Boolean> result =
                function.testOne(KeyValuePair.pair("subject", schema)).get();
        assertEquals("subject", result.key);
        assertTrue(result.value);

        assertFalse(function.testOne(KeyValuePair.pair("broken", schema)).isSuccess());
        assertFalse(function.testAll(Arrays.asList(
                KeyValuePair.pair("subject", schema),
                KeyValuePair.pair("broken", schema))).isSuccess());
    }

    @Test
    void traversCollectsSuccessesAndReturnsFirstFailure() {
        RegistryActionFunction function = function();

        List<String> values = function.travers(Arrays.asList(
                com.jasongoodwin.monads.Try.ofFailable(() -> "one"),
                com.jasongoodwin.monads.Try.ofFailable(() -> "two")))
                .get()
                .collect(Collectors.toList());
        assertEquals(Arrays.asList("one", "two"), values);

        com.jasongoodwin.monads.Try<String> failure =
                com.jasongoodwin.monads.Try.failure(new IllegalArgumentException("expected"));
        assertFalse(function.travers(Arrays.asList(
                com.jasongoodwin.monads.Try.ofFailable(() -> "ok"), failure)).isSuccess());
    }

    @Test
    void negatesPredicates() {
        assertTrue(RegistryActionFunction.not((Integer value) -> value > 3).test(2));
        assertFalse(RegistryActionFunction.not((Integer value) -> value > 3).test(4));
    }

    @Test
    void opensConfiguredSubjectsFileAndReportsMissingFileAsFailure() throws Exception {
        File subjects = Files.createTempFile("subjects", ".yaml").toFile();
        subjects.deleteOnExit();
        Config fileConfig = ConfigFactory.parseString(
                "avro.files.path = \"/tmp/schemas\"\n" +
                "avro.subjects.yaml = \"" + subjects.getAbsolutePath().replace("\\", "\\\\") + "\"");
        RegistryActionFunction function = new RegistryActionFunction(fileConfig, null);

        assertTrue(function.tryStreamFileSubjects().isSuccess());

        Config missingConfig = ConfigFactory.parseString(
                "avro.files.path = \"/tmp/schemas\"\n" +
                "avro.subjects.yaml = \"/path/that/does/not/exist/subjects.yaml\"");
        assertFalse(new RegistryActionFunction(missingConfig, null)
                .tryStreamFileSubjects().isSuccess());
    }
}
