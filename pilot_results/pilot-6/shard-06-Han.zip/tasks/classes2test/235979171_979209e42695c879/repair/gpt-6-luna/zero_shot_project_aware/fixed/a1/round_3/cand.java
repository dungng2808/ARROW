package fr.xebia.ldi;

import com.jasongoodwin.monads.Try;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import org.apache.avro.Schema;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class RegistryActionFunction_ArrowTest {

    private RegistryActionFunction function() {
        return new RegistryActionFunction(ConfigFactory.empty(), new SchemaRegistryClient() {
            @Override
            public int register(String subject, Schema schema) {
                return 0;
            }

            @Override
            public Schema getByID(int id) {
                return null;
            }

            @Override
            public Schema getBySubjectAndID(String subject, int id) {
                return null;
            }

            @Override
            public int getId(String subject, Schema schema) {
                return 0;
            }

            @Override
            public List<Integer> getAllVersions(String subject) {
                return Collections.emptyList();
            }

            @Override
            public io.confluent.kafka.schemaregistry.client.SchemaMetadata getLatestSchemaMetadata(
                    String subject) {
                return null;
            }

            @Override
            public io.confluent.kafka.schemaregistry.client.SchemaMetadata getSchemaMetadata(
                    String subject, String schema) {
                return null;
            }

            @Override
            public boolean testCompatibility(String subject, Schema schema) {
                return true;
            }

            @Override
            public List<String> getAllSubjects() {
                return Collections.emptyList();
            }

            @Override
            public void reset() {
            }

            @Override
            public void close() {
            }

            @Override
            public Integer deleteSchemaVersion(String subject, String version) {
                return 0;
            }
        });
    }

    @Test
    void lazilyCreatesYamlAndParser() {
        RegistryActionFunction function = function();
        assertNotNull(function.getYaml());
        assertSame(function.getYaml(), function.getYaml());
        assertNotNull(function.getParser());
        assertNotSame(function.getParser(), function.getParser());
    }

    @Test
    void mapsSubjectsToFiles() {
        Config config = ConfigFactory.parseString("\"avro.files.path\"=\"schemas\"");
        RegistryActionFunction function = new RegistryActionFunction(config, null);
        SchemaList.SubjectEntry first = new SchemaList.SubjectEntry();
        first.setSubject("orders");
        first.setFile("orders.avsc");
        SchemaList.SubjectEntry second = new SchemaList.SubjectEntry();
        second.setSubject("users");
        second.setFile("users.avsc");

        List<KeyValuePair<String, File>> mapped =
                function.mapSubjectToFile(Arrays.asList(first, second));

        assertEquals(2, mapped.size());
        assertEquals("orders", mapped.get(0).key);
        assertEquals(new File("schemas", "orders.avsc"), mapped.get(0).value);
        assertEquals("users", mapped.get(1).key);
        assertEquals(new File("schemas", "users.avsc"), mapped.get(1).value);
    }

    @Test
    void parsesOneAndAllSchemas() throws Exception {
        File schemaFile = File.createTempFile("registry-action", ".avsc");
        schemaFile.deleteOnExit();
        Files.write(schemaFile.toPath(),
                "{\"type\":\"record\",\"name\":\"Order\",\"fields\":[{\"name\":\"id\",\"type\":\"string\"}]}"
                        .getBytes(StandardCharsets.UTF_8));

        RegistryActionFunction function = function();
        KeyValuePair<String, File> input = KeyValuePair.pair("orders", schemaFile);

        Try<KeyValuePair<String, Schema>> one = function.parseOne(input);
        assertTrue(one.isSuccess());
        assertEquals("orders", one.getUnchecked().key);
        assertEquals("Order", one.getUnchecked().value.getName());

        Try<List<KeyValuePair<String, Schema>>> all =
                function.parseAll(Collections.singletonList(input));
        assertTrue(all.isSuccess());
        assertEquals(1, all.getUnchecked().size());
        assertEquals("Order", all.getUnchecked().get(0).value.getName());

        Try<KeyValuePair<String, Schema>> invalid =
                function.parseOne(KeyValuePair.pair("bad", new File("missing-schema-file.avsc")));
        assertFalse(invalid.isSuccess());
        assertFalse(function.parseAll(Collections.singletonList(
                KeyValuePair.pair("bad", new File("missing-schema-file.avsc")))).isSuccess());
    }

    @Test
    void testsCompatibilityForOneAndAll() throws Exception {
        Schema schema = new Schema.Parser().parse("{\"type\":\"string\"}");
        RegistryActionFunction function = function();

        Try<KeyValuePair<String, Boolean>> one =
                function.testOne(KeyValuePair.pair("orders", schema));
        assertTrue(one.isSuccess());
        assertEquals("orders", one.getUnchecked().key);
        assertTrue(one.getUnchecked().value);

        Try<List<KeyValuePair<String, Boolean>>> all =
                function.testAll(Arrays.asList(
                        KeyValuePair.pair("orders", schema),
                        KeyValuePair.pair("users", schema)));
        assertTrue(all.isSuccess());
        assertEquals(Arrays.asList("orders", "users"),
                all.getUnchecked().stream().map(pair -> pair.key).collect(Collectors.toList()));
        assertTrue(all.getUnchecked().stream().allMatch(pair -> pair.value));
    }

    @Test
    void traversesSuccessfulAndFailedValues() {
        RegistryActionFunction function = function();
        Try<List<Integer>> successes = function.travers(Arrays.asList(
                        Try.ofFailable(() -> 1),
                        Try.ofFailable(() -> 2),
                        Try.ofFailable(() -> 3)))
                .map(stream -> stream.collect(Collectors.toList()));
        assertTrue(successes.isSuccess());
        assertEquals(Arrays.asList(1, 2, 3), successes.getUnchecked());

        Try<List<Integer>> failed = function.travers(Arrays.asList(
                        Try.ofFailable(() -> 1),
                        Try.ofFailable(() -> {
                            throw new IllegalArgumentException("expected");
                        }),
                        Try.ofFailable(() -> 3)))
                .map(stream -> stream.collect(Collectors.toList()));
        assertFalse(failed.isSuccess());
    }

    @Test
    void loadsAndParsesSubjectYaml() throws Exception {
        File yamlFile = File.createTempFile("registry-subjects", ".yaml");
        yamlFile.deleteOnExit();
        Files.write(yamlFile.toPath(),
                "schemas:\n  - subject: orders\n    file: orders.avsc\n".getBytes(StandardCharsets.UTF_8));

        Config config = ConfigFactory.parseString(
                "\"avro.subjects.yaml\"=\"" + yamlFile.getAbsolutePath().replace("\\", "\\\\") + "\"");
        RegistryActionFunction function = new RegistryActionFunction(config, null);

        Try<FileInputStream> stream = function.tryStreamFileSubjects();
        assertTrue(stream.isSuccess());
        Try<List<SchemaList.SubjectEntry>> parsed = function.parseYaml(stream.getUnchecked());
        assertTrue(parsed.isSuccess());
        assertEquals(1, parsed.getUnchecked().size());
        assertEquals("orders", parsed.getUnchecked().get(0).getSubject());
        assertEquals("orders.avsc", parsed.getUnchecked().get(0).getFile());
        stream.getUnchecked().close();
    }

    @Test
    void reportsMissingSubjectFileAsFailure() {
        Config config = ConfigFactory.parseString(
                "\"avro.subjects.yaml\"=\"/path/that/does/not/exist.yaml\"");
        RegistryActionFunction function = new RegistryActionFunction(config, null);
        assertFalse(function.tryStreamFileSubjects().isSuccess());
    }
}
