package fr.xebia.ldi;

import com.jasongoodwin.monads.Try;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import org.apache.avro.Schema;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class RegistryActionFunction_ArrowTest {

    private Config config() {
        return ConfigFactory.parseString(
                "avro.files.path = \"/tmp/schemas\"\n" +
                "avro.subjects.yaml = \"/tmp/subjects.yaml\"");
    }

    private SchemaRegistryClient unusedClient() {
        // These tests do not call the registry except where a client is supplied explicitly.
        return null;
    }

    @Test
    void lazilyCreatesYamlAndParser() {
        RegistryActionFunction function = new RegistryActionFunction(config(), unusedClient());

        assertNotNull(function.getYaml());
        assertSame(function.getYaml(), function.getYaml());
        assertNotNull(function.getParser());
        assertNotSame(function.getParser(), function.getParser());
    }

    @Test
    void mapsSubjectsToFiles() {
        RegistryActionFunction function = new RegistryActionFunction(config(), unusedClient());
        SchemaList.SubjectEntry first = new SchemaList.SubjectEntry();
        first.setSubject("first");
        first.setFile("first.avsc");
        SchemaList.SubjectEntry second = new SchemaList.SubjectEntry();
        second.setSubject("second");
        second.setFile("nested/second.avsc");

        List<KeyValuePair<String, File>> result =
                function.mapSubjectToFile(Arrays.asList(first, second));

        assertEquals(2, result.size());
        assertEquals("first", result.get(0).key);
        assertEquals(new File("/tmp/schemas", "first.avsc"), result.get(0).value);
        assertEquals("second", result.get(1).key);
        assertEquals(new File("/tmp/schemas", "nested/second.avsc"), result.get(1).value);
    }

    @Test
    void parsesSchemaFilesAndPreservesSubjects() throws Exception {
        RegistryActionFunction function = new RegistryActionFunction(config(), unusedClient());
        File schemaFile = Files.createTempFile("registry-action", ".avsc").toFile();
        schemaFile.deleteOnExit();
        Files.write(schemaFile.toPath(),
                "{\"type\":\"record\",\"name\":\"Example\",\"fields\":[]}".getBytes("UTF-8"));

        KeyValuePair<String, Schema> parsed =
                function.parseOne(KeyValuePair.pair("example-subject", schemaFile)).get();

        assertEquals("example-subject", parsed.key);
        assertEquals("Example", parsed.value.getName());
        assertTrue(function.parseAll(Collections.singletonList(
                KeyValuePair.pair("example-subject", schemaFile))).isSuccess());
    }

    @Test
    void parseAllFailsWhenAnySchemaIsInvalid() throws Exception {
        RegistryActionFunction function = new RegistryActionFunction(config(), unusedClient());
        File valid = Files.createTempFile("registry-valid", ".avsc").toFile();
        File invalid = Files.createTempFile("registry-invalid", ".avsc").toFile();
        valid.deleteOnExit();
        invalid.deleteOnExit();
        Files.write(valid.toPath(),
                "{\"type\":\"record\",\"name\":\"Valid\",\"fields\":[]}".getBytes("UTF-8"));
        Files.write(invalid.toPath(), "not a schema".getBytes("UTF-8"));

        assertFalse(function.parseAll(Arrays.asList(
                KeyValuePair.pair("valid", valid),
                KeyValuePair.pair("invalid", invalid))).isSuccess());
    }

    @Test
    void testsCompatibilityAndPropagatesFailure() throws Exception {
        // SchemaRegistryClient is an interface; use a small implementation rather than Mockito.
        SchemaRegistryClient client = new SchemaRegistryClient() {
            @Override
            public boolean testCompatibility(String subject, Schema schema) {
                if ("broken".equals(subject)) {
                    throw new RuntimeException("registry unavailable");
                }
                return "subject".equals(subject);
            }
        };
        RegistryActionFunction function = new RegistryActionFunction(config(), client);
        Schema schema = new Schema.Parser().parse(
                "{\"type\":\"record\",\"name\":\"TestRecord\",\"fields\":[]}");

        KeyValuePair<String, Boolean> result =
                function.testOne(KeyValuePair.pair("subject", schema)).get();
        assertEquals("subject", result.key);
        assertTrue(result.value);

        assertFalse(function.testOne(KeyValuePair.pair("broken", schema)).isSuccess());
        assertFalse(function.testAll(Arrays.asList(
                KeyValuePair.pair("subject", schema),
                KeyValuePair.pair("broken", schema))).isSuccess());
    }

    @Test
    void traversCollectsSuccessesAndReturnsFirstFailure() {
        RegistryActionFunction function = new RegistryActionFunction(config(), unusedClient());

        List<String> values = function.travers(Arrays.asList(
                Try.ofFailable(() -> "one"),
                Try.ofFailable(() -> "two")))
                .get()
                .collect(Collectors.toList());
        assertEquals(Arrays.asList("one", "two"), values);

        Try<String> failure =
                Try.failure(new IllegalArgumentException("expected"));
        assertFalse(function.travers(Arrays.asList(
                Try.ofFailable(() -> "ok"), failure)).isSuccess());
    }

    @Test
    void negatesPredicates() {
        assertTrue(RegistryActionFunction.<Integer>not(value -> value > 3).test(2));
        assertFalse(RegistryActionFunction.<Integer>not(value -> value > 3).test(4));
    }

    @Test
    void opensConfiguredSubjectsFileAndReportsMissingFileAsFailure() throws Exception {
        File subjects = Files.createTempFile("subjects", ".yaml").toFile();
        subjects.deleteOnExit();
        Config fileConfig = ConfigFactory.parseString(
                "avro.files.path = \"/tmp/schemas\"\n" +
                "avro.subjects.yaml = \"" + subjects.getAbsolutePath().replace("\\", "\\\\") + "\"");
        RegistryActionFunction function =
                new RegistryActionFunction(fileConfig, unusedClient());

        assertTrue(function.tryStreamFileSubjects().isSuccess());

        Config missingConfig = ConfigFactory.parseString(
                "avro.files.path = \"/tmp/schemas\"\n" +
                "avro.subjects.yaml = \"/path/that/does/not/exist/subjects.yaml\"");
        assertFalse(new RegistryActionFunction(missingConfig, unusedClient())
                .tryStreamFileSubjects().isSuccess());
    }
}
