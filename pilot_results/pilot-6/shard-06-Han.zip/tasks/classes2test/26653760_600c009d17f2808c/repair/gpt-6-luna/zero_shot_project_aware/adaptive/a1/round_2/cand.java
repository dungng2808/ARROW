package be.drissamri.service.verifier;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PhishTankUrlVerifier_ArrowTest {
    private RestTemplate client;
    private PhishTankConfig config;
    private PhishTankUrlVerifier verifier;
    private MultiValueMap<String, String> parameters;

    @Before
    public void setUp() {
        client = mock(RestTemplate.class);
        config = mock(PhishTankConfig.class);
        parameters = new LinkedMultiValueMap<String, String>();

        // Stub the config methods used by the verifier. Avoid invoking the
        // real getParameters() implementation on the mock.
        when(config.getParameters()).thenReturn(parameters);
        when(config.getApiUrl()).thenReturn("https://example.test/check");
        verifier = new PhishTankUrlVerifier(client, config);
    }

    @Test
    public void reportsConfiguredState() {
        when(config.isConfigured()).thenReturn(true);
        assertTrue(verifier.canValidate());

        when(config.isConfigured()).thenReturn(false);
        assertFalse(verifier.canValidate());
    }

    @Test
    public void returnsSafeWhenApiReportsNoPhish() {
        when(client.postForEntity(eq("https://example.test/check"), any(Object.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(
                        "{\"results\":{\"in_database\":false}}", HttpStatus.OK));

        assertTrue(verifier.isSafe("https://clean.test"));
        assertEquals("https://clean.test", parameters.getFirst("url"));
    }

    @Test
    public void returnsUnsafeWhenApiReportsPhish() {
        when(client.postForEntity(eq("https://example.test/check"), any(Object.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(
                        "{\"results\":{\"in_database\":true}}", HttpStatus.OK));

        assertFalse(verifier.isSafe("https://phishing.test"));
    }

    @Test
    public void remainsSafeForNonOkResponse() {
        when(client.postForEntity(eq("https://example.test/check"), any(Object.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>("{}", HttpStatus.SERVICE_UNAVAILABLE));

        assertTrue(verifier.isSafe("https://unknown.test"));
    }

    @Test
    public void remainsSafeWhenResponseDoesNotContainExpectedPath() {
        when(client.postForEntity(eq("https://example.test/check"), any(Object.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>("{}", HttpStatus.OK));

        assertTrue(verifier.isSafe("https://unknown.test"));
    }

    @Test
    public void remainsSafeWhenRequestFails() {
        when(client.postForEntity(eq("https://example.test/check"), any(Object.class), eq(String.class)))
                .thenThrow(new RestClientException("network failure"));

        assertTrue(verifier.isSafe("https://unknown.test"));
    }
}
