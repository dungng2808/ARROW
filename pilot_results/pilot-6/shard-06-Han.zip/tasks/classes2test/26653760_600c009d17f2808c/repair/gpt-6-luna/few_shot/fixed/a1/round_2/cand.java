package be.drissamri.service.verifier;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PhishTankUrlVerifier_ArrowTest {

    private RestTemplate client;
    private PhishTankConfig config;
    private PhishTankUrlVerifier verifier;

    @Before
    public void setUp() {
        client = mock(RestTemplate.class);
        config = mock(PhishTankConfig.class);
        when(config.getApiUrl()).thenReturn("https://example.test/check");
        when(config.getParameters()).thenAnswer(
                invocation -> new LinkedMultiValueMap<String, String>());
        verifier = new PhishTankUrlVerifier(client, config);
    }

    @Test
    public void reportsConfiguredState() {
        when(config.isConfigured()).thenReturn(true);
        assertTrue(verifier.canValidate());

        when(config.isConfigured()).thenReturn(false);
        assertFalse(verifier.canValidate());
    }

    @Test
    public void returnsUnsafeWhenPhishTankReportsUrlInDatabase() {
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(LinkedMultiValueMap.class),
                eq(String.class)))
                .thenReturn(ResponseEntity.ok("{\"results\":{\"in_database\":true}}"));

        assertFalse(verifier.isSafe("https://malicious.test"));
    }

    @Test
    public void returnsSafeWhenPhishTankReportsUrlNotInDatabase() {
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(LinkedMultiValueMap.class),
                eq(String.class)))
                .thenReturn(ResponseEntity.ok("{\"results\":{\"in_database\":false}}"));

        assertTrue(verifier.isSafe("https://safe.test"));
    }

    @Test
    public void returnsSafeForNonOkResponse() {
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(LinkedMultiValueMap.class),
                eq(String.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{}"));

        assertTrue(verifier.isSafe("https://safe.test"));
    }

    @Test
    public void returnsSafeWhenResponseDoesNotContainExpectedPath() {
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(LinkedMultiValueMap.class),
                eq(String.class)))
                .thenReturn(ResponseEntity.ok("{\"results\":{}}"));

        assertTrue(verifier.isSafe("https://safe.test"));
    }

    @Test
    public void returnsSafeWhenRequestFails() {
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(LinkedMultiValueMap.class),
                eq(String.class)))
                .thenThrow(new RestClientException("request failed"));

        assertTrue(verifier.isSafe("https://safe.test"));
    }
}
