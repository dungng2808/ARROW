package be.drissamri.service.verifier;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PhishTankUrlVerifier_ArrowTest {

    private RestTemplate client;
    private PhishTankConfig config;
    private PhishTankUrlVerifier verifier;

    @Before
    public void setUp() {
        client = mock(RestTemplate.class);
        config = mock(PhishTankConfig.class);
        verifier = new PhishTankUrlVerifier(client, config);
    }

    @Test
    public void reportsConfiguredState() {
        when(config.isConfigured()).thenReturn(true);
        assertTrue(verifier.canValidate());

        when(config.isConfigured()).thenReturn(false);
        assertFalse(verifier.canValidate());
    }

    @Test
    public void returnsUnsafeWhenPhishTankReportsUrlInDatabase() {
        when(config.getApiUrl()).thenReturn("https://example.test/check");
        when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(MultiValueMap.class),
                eq(String.class)))
                .thenReturn(ResponseEntity.ok("{\"results\":{\"in_database\":true}}"));

        assertFalse(verifier.isSafe("https://malicious.test"));
    }

    @Test
    public void returnsSafeWhenPhishTankReportsUrlNotInDatabase() {
        when(config.getApiUrl()).thenReturn("https://example.test/check");
        when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(MultiValueMap.class),
                eq(String.class)))
                .thenReturn(ResponseEntity.ok("{\"results\":{\"in_database\":false}}"));

        assertTrue(verifier.isSafe("https://safe.test"));
    }

    @Test
    public void returnsSafeForNonOkResponse() {
        when(config.getApiUrl()).thenReturn("https://example.test/check");
        when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(MultiValueMap.class),
                eq(String.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{}"));

        assertTrue(verifier.isSafe("https://safe.test"));
    }

    @Test
    public void returnsSafeWhenResponseDoesNotContainExpectedPath() {
        when(config.getApiUrl()).thenReturn("https://example.test/check");
        when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(MultiValueMap.class),
                eq(String.class)))
                .thenReturn(ResponseEntity.ok("{\"results\":{}}"));

        assertTrue(verifier.isSafe("https://safe.test"));
    }

    @Test
    public void returnsSafeWhenRequestFails() {
        when(config.getApiUrl()).thenReturn("https://example.test/check");
        when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
        when(client.postForEntity(
                eq("https://example.test/check"),
                any(MultiValueMap.class),
                eq(String.class)))
                .thenThrow(new RestClientException("request failed"));

        assertTrue(verifier.isSafe("https://safe.test"));
    }
}
