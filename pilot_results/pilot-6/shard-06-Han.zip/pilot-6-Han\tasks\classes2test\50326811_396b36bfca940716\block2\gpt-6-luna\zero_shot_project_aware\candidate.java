package net.md_5.bungee.api.chat;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;

public class TranslatableComponent_ArrowTest
{
    @Test
    public void unknownTranslationKeyIsRenderedLiterally()
    {
        TranslatableComponent component = new TranslatableComponent( "arrow.unknown.translation.key" );

        assertEquals( "arrow.unknown.translation.key", component.toPlainText() );
    }

    @Test
    public void substitutionsAreRenderedInOrderAndPercentEscapesAreResolved()
    {
        TranslatableComponent component = new TranslatableComponent( "arrow %s then %s (100%%)", "first", "second" );

        assertEquals( "arrow first then second (100%)", component.toPlainText() );
    }

    @Test
    public void numberedSubstitutionsCanBeRenderedOutOfOrder()
    {
        TranslatableComponent component = new TranslatableComponent( "arrow %2$s before %1$s", "first", "second" );

        assertEquals( "arrow second before first", component.toPlainText() );
    }

    @Test
    public void addWithCreatesAndAppendsSubstitutions()
    {
        TranslatableComponent component = new TranslatableComponent( "arrow %s/%s" );
        component.addWith( "left" );
        component.addWith( new TextComponent( "right" ) );

        assertEquals( "arrow left/right", component.toPlainText() );
    }

    @Test
    public void setWithReplacesSubstitutionsAndSetsTheirParent()
    {
        TranslatableComponent component = new TranslatableComponent( "arrow %s" );
        TextComponent replacement = new TextComponent( "replacement" );
        List<BaseComponent> substitutions = new ArrayList<BaseComponent>();
        substitutions.add( replacement );

        component.setWith( substitutions );

        assertEquals( "arrow replacement", component.toPlainText() );
        assertSame( component, replacement.parent );
    }

    @Test
    public void duplicateCopiesSubstitutionsWithoutSharingThem()
    {
        TranslatableComponent original = new TranslatableComponent( "arrow %s", "value" );

        TranslatableComponent duplicate = (TranslatableComponent) original.duplicate();

        assertEquals( "arrow value", duplicate.toPlainText() );
        assertNotSame( original, duplicate );
        assertNotSame( original.getWith().get( 0 ), duplicate.getWith().get( 0 ) );
    }
}
