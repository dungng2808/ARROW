package be.drissamri.service.verifier;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class PhishTankUrlVerifier_ArrowTest {

  @Test
  public void reportsUnsafeWhenPhishTankFindsUrlInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = mock(PhishTankConfig.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    when(config.getParameters()).thenReturn(parameters);
    when(config.getApiUrl()).thenReturn("https://example.test/check");
    when(client.postForEntity(
            eq("https://example.test/check"), any(MultiValueMap.class), eq(String.class)))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":true}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertFalse(verifier.isSafe("https://malicious.test"));
    verify(client)
        .postForEntity(
            eq("https://example.test/check"), eq(parameters), eq(String.class));
    assertTrue(parameters.getFirst("url").equals("https://malicious.test"));
  }

  @Test
  public void reportsSafeWhenPhishTankDoesNotFindUrlInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
    when(config.getApiUrl()).thenReturn("https://example.test/check");
    when(client.postForEntity(
            eq("https://example.test/check"), any(MultiValueMap.class), eq(String.class)))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":false}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://safe.test"));
    verify(client).postForEntity(
        eq("https://example.test/check"), any(MultiValueMap.class), eq(String.class));
  }

  @Test
  public void remainsSafeWhenApiReturnsNonOkStatus() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
    when(config.getApiUrl()).thenReturn("https://example.test/check");
    when(client.postForEntity(
            eq("https://example.test/check"), any(MultiValueMap.class), eq(String.class)))
        .thenReturn(new ResponseEntity<String>("", HttpStatus.SERVICE_UNAVAILABLE));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://unknown.test"));
    verify(client).postForEntity(
        eq("https://example.test/check"), any(MultiValueMap.class), eq(String.class));
  }

  @Test
  public void remainsSafeWhenRequestThrowsRestClientException() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
    when(config.getApiUrl()).thenReturn("https://example.test/check");
    when(client.postForEntity(
            eq("https://example.test/check"), any(MultiValueMap.class), eq(String.class)))
        .thenThrow(new RestClientException("offline"));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://unknown.test"));
    verify(client).postForEntity(
        eq("https://example.test/check"), any(MultiValueMap.class), eq(String.class));
  }

  @Test
  public void canValidateReflectsConfiguration() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.isConfigured()).thenReturn(true);
    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.canValidate());

    when(config.isConfigured()).thenReturn(false);
    assertFalse(verifier.canValidate());
  }
}
