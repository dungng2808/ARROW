package com.solace.spring.boot.autoconfigure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

import com.solace.services.core.model.SolaceServiceCredentials;
import com.solace.spring.cloud.core.SolaceMessagingInfo;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.ServiceInfo;

public class SolaceJmsAutoCloudConfiguration_ArrowTest {

    @Test
    @SuppressWarnings("deprecation")
    public void returnsFirstSolaceMessagingInfoFromCloudServices() throws Exception {
        SolaceMessagingInfo first = new SolaceMessagingInfo();
        SolaceMessagingInfo second = new SolaceMessagingInfo();
        SolaceJmsAutoCloudConfiguration configuration =
                newConfigurationWithServices(Arrays.<ServiceInfo>asList(first, second));

        assertSame(first, configuration.findFirstSolaceMessagingInfo());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void returnsAllSolaceCredentialsAndMessagingInfos() throws Exception {
        SolaceMessagingInfo first = new SolaceMessagingInfo();
        SolaceMessagingInfo second = new SolaceMessagingInfo();
        SolaceJmsAutoCloudConfiguration configuration =
                newConfigurationWithServices(Arrays.<ServiceInfo>asList(first, second));

        List<SolaceMessagingInfo> messagingInfos = configuration.getSolaceMessagingInfos();
        assertEquals(Arrays.asList(first, second), messagingInfos);

        List<SolaceServiceCredentials> credentials = configuration.getSolaceServiceCredentials();
        assertEquals(2, credentials.size());
        assertSame(first, credentials.get(0));
        assertSame(second, credentials.get(1));
    }

    @Test
    @SuppressWarnings("deprecation")
    public void throwsWhenCloudHasNoSolaceMessagingInfo() throws Exception {
        SolaceJmsAutoCloudConfiguration configuration =
                newConfigurationWithServices(Collections.<ServiceInfo>emptyList());

        try {
            configuration.findFirstSolaceMessagingInfo();
            fail("Expected an IllegalStateException when no Solace service is present");
        } catch (IllegalStateException exception) {
            assertEquals(
                    "Unable to create SolConnectionFactory did not find SolaceMessagingInfo in the current cloud environment",
                    exception.getMessage());
        }
    }

    private SolaceJmsAutoCloudConfiguration newConfigurationWithServices(List<ServiceInfo> services)
            throws Exception {
        SolaceJmsAutoCloudConfiguration configuration =
                new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());

        Cloud cloud = new Cloud(null) {
            @Override
            public List<ServiceInfo> getServiceInfos() {
                return services;
            }
        };
        CloudFactory cloudFactory = new CloudFactory() {
            @Override
            public Cloud getCloud() {
                return cloud;
            }
        };

        Field field = SolaceJmsAutoCloudConfiguration.class.getDeclaredField("cloudFactory");
        field.setAccessible(true);
        field.set(configuration, cloudFactory);
        return configuration;
    }
}
