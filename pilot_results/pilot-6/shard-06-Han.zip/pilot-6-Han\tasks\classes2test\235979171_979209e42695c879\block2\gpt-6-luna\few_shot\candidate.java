package fr.xebia.ldi;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.typesafe.config.ConfigFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import org.apache.avro.Schema;
import org.junit.Test;

public class RegistryActionFunction_ArrowTest {

    @Test
    public void lazilyCreatesYamlAndParser() {
        RegistryActionFunction function =
                new RegistryActionFunction(ConfigFactory.empty(), null);

        assertNotNull(function.getYaml());
        assertNotNull(function.getYaml());
        assertNotNull(function.getParser());
    }

    @Test
    public void mapsSubjectsToFilesUnderConfiguredDirectory() {
        RegistryActionFunction function = new RegistryActionFunction(
                ConfigFactory.parseString("avro.files.path = \"/schemas\""),
                null);
        SchemaList.SubjectEntry first = new SchemaList.SubjectEntry("first", "first.avsc");
        SchemaList.SubjectEntry second = new SchemaList.SubjectEntry("second", "nested/second.avsc");

        List<KeyValuePair<String, File>> result =
                function.mapSubjectToFile(Arrays.asList(first, second));

        assertEquals(2, result.size());
        assertEquals("first", result.get(0).key);
        assertEquals(new File("/schemas", "first.avsc"), result.get(0).value);
        assertEquals("second", result.get(1).key);
        assertEquals(new File("/schemas", "nested/second.avsc"), result.get(1).value);
    }

    @Test
    public void parsesSchemaFileAndPreservesSubject() throws IOException {
        File schemaFile = Files.createTempFile("registry-action", ".avsc").toFile();
        try {
            Files.write(schemaFile.toPath(),
                    "{\"type\":\"record\",\"name\":\"Example\",\"fields\":[]}"
                            .getBytes(StandardCharsets.UTF_8));
            RegistryActionFunction function =
                    new RegistryActionFunction(ConfigFactory.empty(), null);

            KeyValuePair<String, Schema> result = function
                    .parseOne(KeyValuePair.pair("example-subject", schemaFile))
                    .getUnchecked();

            assertEquals("example-subject", result.key);
            assertEquals("Example", result.value.getName());
            assertEquals(Schema.Type.RECORD, result.value.getType());
        } finally {
            Files.deleteIfExists(schemaFile.toPath());
        }
    }

    @Test
    public void parseAllReturnsFailureWhenAnySchemaFileIsInvalid() throws IOException {
        File validFile = Files.createTempFile("registry-valid", ".avsc").toFile();
        File invalidFile = Files.createTempFile("registry-invalid", ".avsc").toFile();
        try {
            Files.write(validFile.toPath(),
                    "{\"type\":\"record\",\"name\":\"Valid\",\"fields\":[]}"
                            .getBytes(StandardCharsets.UTF_8));
            Files.write(invalidFile.toPath(), "not a schema".getBytes(StandardCharsets.UTF_8));
            RegistryActionFunction function =
                    new RegistryActionFunction(ConfigFactory.empty(), null);

            assertFalse(function.parseAll(Arrays.asList(
                    KeyValuePair.pair("valid", validFile),
                    KeyValuePair.pair("invalid", invalidFile))).isSuccess());
        } finally {
            Files.deleteIfExists(validFile.toPath());
            Files.deleteIfExists(invalidFile.toPath());
        }
    }

    @Test
    public void traversCollectsSuccessfulValuesAndPropagatesFailure() {
        RegistryActionFunction function =
                new RegistryActionFunction(ConfigFactory.empty(), null);

        List<String> values = function.travers(Arrays.asList(
                com.jasongoodwin.monads.Try.ofFailable(() -> "one"),
                com.jasongoodwin.monads.Try.ofFailable(() -> "two")))
                .getUnchecked()
                .collect(java.util.stream.Collectors.toList());
        assertEquals(Arrays.asList("one", "two"), values);

        assertFalse(function.travers(Arrays.asList(
                com.jasongoodwin.monads.Try.ofFailable(() -> "one"),
                com.jasongoodwin.monads.Try.<String>failure(
                        new IllegalArgumentException("bad")))).isSuccess());
    }

    @Test
    public void notNegatesPredicate() {
        Predicate<String> nonEmpty = RegistryActionFunction.not(String::isEmpty);

        assertTrue(nonEmpty.test("schema"));
        assertFalse(nonEmpty.test(""));
    }

    @Test
    public void parsesYamlSubjects() throws IOException {
        File yamlFile = Files.createTempFile("registry-subjects", ".yaml").toFile();
        try {
            Files.write(yamlFile.toPath(),
                    "schemas:\n  - subject: example\n    file: example.avsc\n"
                            .getBytes(StandardCharsets.UTF_8));
            RegistryActionFunction function =
                    new RegistryActionFunction(ConfigFactory.empty(), null);

            List<SchemaList.SubjectEntry> subjects;
            try (FileInputStream input = new FileInputStream(yamlFile)) {
                subjects = function.parseYaml(input).getUnchecked();
            }

            assertEquals(1, subjects.size());
            assertEquals("example", subjects.get(0).getSubject());
            assertEquals("example.avsc", subjects.get(0).getFile());
        } finally {
            Files.deleteIfExists(yamlFile.toPath());
        }
    }
}
