package be.drissamri.service.verifier;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PhishTankUrlVerifier_ArrowTest {

  private PhishTankConfig configuredConfig() {
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.getApiUrl()).thenReturn("https://example.invalid/check");
    when(config.getParameters()).thenAnswer(invocation ->
        new LinkedMultiValueMap<String, String>());
    return config;
  }

  @Test
  public void isSafeReturnsFalseWhenPhishTankReportsUrlInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = configuredConfig();
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    parameters.add("url", "http://phishing.example");
    when(config.getParameters()).thenReturn(parameters);
    when(client.postForEntity(
        "https://example.invalid/check",
        parameters,
        String.class))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":true}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertFalse(verifier.isSafe("http://phishing.example"));
    assertTrue(parameters.get("url").contains("http://phishing.example"));
  }

  @Test
  public void isSafeReturnsTrueWhenPhishTankReportsUrlNotInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = configuredConfig();
    when(client.postForEntity(
        "https://example.invalid/check",
        new LinkedMultiValueMap<String, String>(),
        String.class))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":false}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("http://safe.example"));
  }

  @Test
  public void isSafeReturnsTrueWhenApiRespondsWithNonOkStatus() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = configuredConfig();
    when(client.postForEntity(
        "https://example.invalid/check",
        new LinkedMultiValueMap<String, String>(),
        String.class))
        .thenReturn(new ResponseEntity<String>("unavailable", HttpStatus.SERVICE_UNAVAILABLE));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("http://unknown.example"));
  }

  @Test
  public void isSafeReturnsTrueWhenResponseDoesNotContainExpectedPath() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = configuredConfig();
    when(client.postForEntity(
        "https://example.invalid/check",
        new LinkedMultiValueMap<String, String>(),
        String.class))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("http://unknown.example"));
  }

  @Test
  public void canValidateReflectsConfigurationState() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.isConfigured()).thenReturn(true);
    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.canValidate());
  }
}
