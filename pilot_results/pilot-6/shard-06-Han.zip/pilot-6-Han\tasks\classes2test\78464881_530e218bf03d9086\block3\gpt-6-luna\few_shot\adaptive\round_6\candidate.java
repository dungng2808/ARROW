package com.solace.spring.boot.autoconfigure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

import com.solace.services.core.model.SolaceServiceCredentials;
import com.solace.spring.cloud.core.SolaceMessagingInfo;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.ServiceInfo;

public class SolaceJmsAutoCloudConfiguration_ArrowTest {

    @Test
    public void returnsFirstSolaceMessagingInfoFromCloudServices() {
        SolaceMessagingInfo first = new SolaceMessagingInfo("first", Collections.<String, Object>emptyMap());
        SolaceMessagingInfo second = new SolaceMessagingInfo("second", Collections.<String, Object>emptyMap());
        ServiceInfo unrelated = new ServiceInfo("other") {
        };

        SolaceJmsAutoCloudConfiguration configuration = newConfigurationWithServices(
                Arrays.<ServiceInfo>asList(unrelated, first, second));

        assertSame(first, configuration.findFirstSolaceMessagingInfo());
    }

    @Test
    public void returnsAllSolaceCredentialsAndMessagingInfos() {
        SolaceMessagingInfo first = new SolaceMessagingInfo("first", Collections.<String, Object>emptyMap());
        SolaceMessagingInfo second = new SolaceMessagingInfo("second", Collections.<String, Object>emptyMap());
        ServiceInfo unrelated = new ServiceInfo("other") {
        };
        SolaceJmsAutoCloudConfiguration configuration = newConfigurationWithServices(
                Arrays.<ServiceInfo>asList(first, unrelated, second));

        List<SolaceMessagingInfo> messagingInfos = configuration.getSolaceMessagingInfos();
        assertEquals(Arrays.asList(first, second), messagingInfos);

        List<SolaceServiceCredentials> credentials = configuration.getSolaceServiceCredentials();
        assertEquals(2, credentials.size());
        assertSame(first, credentials.get(0));
        assertSame(second, credentials.get(1));
    }

    @Test
    public void throwsWhenCloudHasNoSolaceMessagingInfo() {
        SolaceJmsAutoCloudConfiguration configuration =
                newConfigurationWithServices(Collections.<ServiceInfo>emptyList());

        try {
            configuration.findFirstSolaceMessagingInfo();
            fail("Expected an IllegalStateException when no Solace messaging service is present");
        } catch (IllegalStateException exception) {
            assertEquals(
                    "Unable to create SolConnectionFactory did not find SolaceMessagingInfo in the current cloud environment",
                    exception.getMessage());
        }
    }

    private SolaceJmsAutoCloudConfiguration newConfigurationWithServices(List<ServiceInfo> services) {
        SolaceJmsAutoCloudConfiguration configuration =
                new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());

        final Cloud cloud = new Cloud(services, Collections.emptyList(), null);
        CloudFactory cloudFactory = new CloudFactory() {
            @Override
            public Cloud getCloud() {
                return cloud;
            }
        };

        try {
            java.lang.reflect.Field field =
                    SolaceJmsAutoCloudConfiguration.class.getDeclaredField("cloudFactory");
            field.setAccessible(true);
            field.set(configuration, cloudFactory);
        } catch (ReflectiveOperationException exception) {
            throw new AssertionError(exception);
        }
        return configuration;
    }
}
