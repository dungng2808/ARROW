package net.md_5.bungee.api.chat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

public class TranslatableComponent_ArrowTest
{
    @Test
    public void missingTranslationKeyIsRenderedLiterally()
    {
        TranslatableComponent component = new TranslatableComponent( "arrow.test.missing.key" );

        assertEquals( "arrow.test.missing.key", component.toPlainText() );
    }

    @Test
    public void substitutionsAreRenderedInOrderAndPercentEscapesAreResolved()
    {
        TranslatableComponent component = new TranslatableComponent( "first %s, second %s, percent %%", "one", "two" );

        assertEquals( "first one, second two, percent %", component.toPlainText() );
    }

    @Test
    public void numberedSubstitutionsCanBeRenderedOutOfOrder()
    {
        TranslatableComponent component = new TranslatableComponent( "%2$s then %1$s", "first", "second" );

        assertEquals( "second then first", component.toPlainText() );
    }

    @Test
    public void addWithCreatesAndAppendsSubstitutions()
    {
        TranslatableComponent component = new TranslatableComponent( "%s/%s" );
        component.addWith( "left" );
        component.addWith( new TextComponent( "right" ) );

        assertEquals( "left/right", component.toPlainText() );
    }

    @Test
    public void setWithReplacesSubstitutionsAndSetsTheirParent()
    {
        TranslatableComponent component = new TranslatableComponent( "%s" );
        TextComponent previous = new TextComponent( "old" );
        component.setWith( Arrays.<BaseComponent>asList( previous ) );

        TextComponent replacement = new TextComponent( "new" );
        List<BaseComponent> replacements = new ArrayList<BaseComponent>();
        replacements.add( replacement );
        component.setWith( replacements );

        assertEquals( "new", component.toPlainText() );
        assertEquals( component, replacement.parent );
    }

    @Test
    public void duplicateCopiesTranslationAndDeepCopiesSubstitutions()
    {
        TranslatableComponent original = new TranslatableComponent( "%s", "value" );

        TranslatableComponent duplicate = (TranslatableComponent) original.duplicate();

        assertNotSame( original, duplicate );
        assertEquals( original.getTranslate(), duplicate.getTranslate() );
        assertEquals( original.toPlainText(), duplicate.toPlainText() );
        assertNotSame( original.getWith().get( 0 ), duplicate.getWith().get( 0 ) );
    }
}
