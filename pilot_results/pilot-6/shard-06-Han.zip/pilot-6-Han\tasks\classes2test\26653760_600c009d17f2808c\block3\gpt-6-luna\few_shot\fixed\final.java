package be.drissamri.service.verifier;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class PhishTankUrlVerifier_ArrowTest {

  private static final String API_URL = "https://example.test/check";

  private PhishTankConfig configWithParameters(
      MultiValueMap<String, String> parameters) {
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.getParameters()).thenReturn(parameters);
    when(config.getApiUrl()).thenReturn(API_URL);
    return config;
  }

  @Test
  public void reportsUnsafeWhenPhishTankFindsUrlInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(eq(API_URL), any(MultiValueMap.class), eq(String.class)))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":true}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertFalse(verifier.isSafe("https://malicious.test"));
    verify(client).postForEntity(eq(API_URL), eq(parameters), eq(String.class));
    assertTrue("https://malicious.test".equals(parameters.getFirst("url")));
  }

  @Test
  public void reportsSafeWhenPhishTankDoesNotFindUrlInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    parameters.add("format", "json");
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(eq(API_URL), any(MultiValueMap.class), eq(String.class)))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":false}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://safe.test"));
    assertTrue("https://safe.test".equals(parameters.getFirst("url")));
  }

  @Test
  public void remainsSafeWhenApiReturnsNonOkStatus() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    parameters.add("format", "json");
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(eq(API_URL), any(MultiValueMap.class), eq(String.class)))
        .thenReturn(new ResponseEntity<String>("", HttpStatus.SERVICE_UNAVAILABLE));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://unknown.test"));
    assertTrue("https://unknown.test".equals(parameters.getFirst("url")));
  }

  @Test
  public void remainsSafeWhenRequestThrowsRestClientException() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    parameters.add("format", "json");
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(eq(API_URL), any(MultiValueMap.class), eq(String.class)))
        .thenThrow(new RestClientException("offline"));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://unknown.test"));
    assertTrue("https://unknown.test".equals(parameters.getFirst("url")));
  }

  @Test
  public void remainsSafeWhenResponseDoesNotContainDatabaseResult() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    parameters.add("format", "json");
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(eq(API_URL), any(MultiValueMap.class), eq(String.class)))
        .thenReturn(new ResponseEntity<String>("{\"results\":{}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://unknown.test"));
    assertTrue("https://unknown.test".equals(parameters.getFirst("url")));
  }

  @Test
  public void canValidateReflectsConfiguration() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.isConfigured()).thenReturn(true);
    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.canValidate());
    verify(config).isConfigured();
  }
}
