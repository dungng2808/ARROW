package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import com.sonar.sslr.api.AstNode;
import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class FlowParser_ArrowTest {

    @Test
    public void createWithConfigurationReturnsParserThatParsesEmptySource() {
        FlowConfiguration configuration = new FlowConfiguration(Charset.defaultCharset());

        AstNode ast = FlowParser.create(configuration).parse("");

        assertNotNull(ast);
    }

    @Test
    public void createWithoutConfigurationReturnsParserThatParsesEmptySource() {
        AstNode ast = FlowParser.create().parse("");

        assertNotNull(ast);
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String missingPath = new File(System.getProperty("java.io.tmpdir"),
                "flow-parser-missing-" + System.nanoTime()).getAbsolutePath();

        try {
            FlowParser.parseFile(missingPath);
            fail("Expected an AssertionError for a missing file.");
        } catch (AssertionError expected) {
            assertTrue(expected.getMessage().contains(missingPath));
        }
    }

    @Test
    public void parseFileParsesExistingEmptyFile() throws IOException {
        File file = File.createTempFile("flow-parser-", ".flow");
        try {
            FileWriter writer = new FileWriter(file);
            try {
                writer.write("");
            } finally {
                writer.close();
            }

            AstNode ast = FlowParser.create().parse(file);
            assertNotNull(ast);
        } finally {
            if (file.exists()) {
                assertTrue(file.delete());
            }
        }
    }
}
