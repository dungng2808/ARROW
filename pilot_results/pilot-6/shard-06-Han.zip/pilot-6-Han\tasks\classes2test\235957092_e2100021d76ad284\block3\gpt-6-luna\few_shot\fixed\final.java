package edu.berkeley.cs.jqf.fuzz.rl;

import org.json.JSONException;
import org.junit.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

public class RLParamParser_ArrowTest {

    @Test
    public void parsesSupportedScalarAndArrayParameterTypes() {
        RLParamParser parser = new RLParamParser();
        String json = "{\"params\":["
                + "{\"name\":\"text\",\"type\":\"string\",\"val\":\"hello\"},"
                + "{\"name\":\"enabled\",\"type\":\"bool\",\"val\":true},"
                + "{\"name\":\"count\",\"type\":\"long\",\"val\":1234567890123},"
                + "{\"name\":\"index\",\"type\":\"int\",\"val\":42},"
                + "{\"name\":\"ratio\",\"type\":\"double\",\"val\":2.5},"
                + "{\"name\":\"words\",\"type\":\"string_array\",\"val\":[\"one\",\"two\"]},"
                + "{\"name\":\"flags\",\"type\":\"bool_array\",\"val\":[true,false]},"
                + "{\"name\":\"numbers\",\"type\":\"int_array\",\"val\":[3,7]},"
                + "{\"name\":\"measurements\",\"type\":\"double_array\",\"val\":[1.25,4.5]}"
                + "]}";

        RLParams params = parser.getParams(json);

        assertEquals("hello", params.get("text"));
        assertEquals(Boolean.TRUE, params.get("enabled"));
        assertEquals(Long.valueOf(1234567890123L), params.get("count"));
        assertEquals(Integer.valueOf(42), params.get("index"));
        assertEquals(Double.valueOf(2.5), params.get("ratio"));
        assertEquals(Arrays.asList("one", "two"), params.get("words"));
        assertEquals(Arrays.asList(true, false), params.get("flags"));
        assertEquals(Arrays.asList(3, 7), params.get("numbers"));
        assertEquals(Arrays.asList(1.25, 4.5), params.get("measurements"));
    }

    @Test
    public void parsesEmptyParamsObject() {
        RLParams params = new RLParamParser().getParams("{\"params\":[]}");

        assertNull(params.get("missing"));
    }

    @Test
    public void rejectsJsonWithoutParamsRootProperty() {
        try {
            new RLParamParser().getParams("{\"other\":[]}");
            fail("Expected a JSONException when params is absent");
        } catch (JSONException expected) {
            assertEquals("Object needs to have params as root", expected.getMessage());
        }
    }

    @Test
    public void parsesParamsFromFile() throws IOException {
        Path file = Files.createTempFile("rl-params", ".json");
        try {
            Files.write(file,
                    "{\"params\":[{\"name\":\"fromFile\",\"type\":\"int\",\"val\":9}]}"
                            .getBytes(StandardCharsets.UTF_8));

            RLParams params = new RLParamParser().getParamsFile(file.toString());

            assertEquals(Integer.valueOf(9), params.get("fromFile"));
        } finally {
            Files.deleteIfExists(file);
        }
    }
}
