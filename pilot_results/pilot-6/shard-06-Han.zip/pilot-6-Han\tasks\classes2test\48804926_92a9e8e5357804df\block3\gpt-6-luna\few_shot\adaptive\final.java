package edu.jhuapl.dorset;

import static org.junit.Assert.assertSame;

import edu.jhuapl.dorset.agents.Agent;
import edu.jhuapl.dorset.routing.Router;
import java.lang.reflect.Proxy;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import org.junit.Test;

public class Application_ArrowTest {

    @Test
    public void getAgentsReturnsAgentsProvidedByRouter() {
        final Agent[] expectedAgents = new Agent[0];
        Router router = (Router) Proxy.newProxyInstance(
                Router.class.getClassLoader(),
                new Class<?>[] {Router.class},
                new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        if ("getAgents".equals(method.getName())) {
                            return expectedAgents;
                        }
                        return null;
                    }
                });

        Application application = new Application(router);

        assertSame(expectedAgents, application.getAgents());
    }
}
