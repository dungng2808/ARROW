package fr.xebia.ldi;

import com.jasongoodwin.monads.Try;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import org.apache.avro.Schema;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class RegistryActionFunction_ArrowTest {

    private Config config() {
        return ConfigFactory.parseString("avro.files.path = \"/tmp\"");
    }

    @Test
    public void getYamlLazilyCreatesAndCachesYaml() {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);

        assertThat(function.getYaml(), is(notNullValue()));
        assertThat(function.getYaml(), is(function.getYaml()));
    }

    @Test
    public void getParserReturnsUsableAvroParser() {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);

        Schema schema = function.getParser().parse(
                "{\"type\":\"record\",\"name\":\"Example\",\"fields\":[]}");
        assertThat(schema.getName(), is("Example"));
        assertThat(schema.getType(), is(Schema.Type.RECORD));
    }

    @Test
    public void mapSubjectToFileUsesConfiguredDirectoryAndSubjectFileNames() {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);
        SchemaList.SubjectEntry first = new SchemaList.SubjectEntry();
        first.setSubject("orders");
        first.setFile("orders.avsc");
        SchemaList.SubjectEntry second = new SchemaList.SubjectEntry();
        second.setSubject("users");
        second.setFile("users.avsc");

        List<KeyValuePair<String, File>> mapped =
                function.mapSubjectToFile(Arrays.asList(first, second));

        assertThat(mapped.size(), is(2));
        assertThat(mapped.get(0).key, is("orders"));
        assertThat(mapped.get(0).value, is(new File("/tmp", "orders.avsc")));
        assertThat(mapped.get(1).key, is("users"));
        assertThat(mapped.get(1).value, is(new File("/tmp", "users.avsc")));
    }

    @Test
    public void parseOneParsesSchemaAndPreservesSubject() throws IOException {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);
        File schemaFile = File.createTempFile("registry-action", ".avsc");
        try {
            Files.write(schemaFile.toPath(),
                    "{\"type\":\"record\",\"name\":\"Order\",\"fields\":[]}"
                            .getBytes(StandardCharsets.UTF_8));

            Try<KeyValuePair<String, Schema>> result =
                    function.parseOne(KeyValuePair.pair("orders", schemaFile));

            assertTrue(result.isSuccess());
            KeyValuePair<String, Schema> parsed = result.getUnchecked();
            assertThat(parsed.key, is("orders"));
            assertThat(parsed.value.getName(), is("Order"));
        } finally {
            Files.deleteIfExists(schemaFile.toPath());
        }
    }

    @Test
    public void parseOneReturnsFailureForInvalidSchemaFile() throws IOException {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);
        File schemaFile = File.createTempFile("registry-action-invalid", ".avsc");
        try {
            Files.write(schemaFile.toPath(), "not a schema".getBytes(StandardCharsets.UTF_8));

            Try<KeyValuePair<String, Schema>> result =
                    function.parseOne(KeyValuePair.pair("invalid", schemaFile));

            assertFalse(result.isSuccess());
        } finally {
            Files.deleteIfExists(schemaFile.toPath());
        }
    }

    @Test
    public void parseAllReturnsParsedSchemasInInputOrder() throws IOException {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);
        File first = File.createTempFile("registry-action-first", ".avsc");
        File second = File.createTempFile("registry-action-second", ".avsc");
        try {
            Files.write(first.toPath(),
                    "{\"type\":\"record\",\"name\":\"First\",\"fields\":[]}"
                            .getBytes(StandardCharsets.UTF_8));
            Files.write(second.toPath(),
                    "{\"type\":\"record\",\"name\":\"Second\",\"fields\":[]}"
                            .getBytes(StandardCharsets.UTF_8));

            Try<List<KeyValuePair<String, Schema>>> result = function.parseAll(Arrays.asList(
                    KeyValuePair.pair("first", first),
                    KeyValuePair.pair("second", second)));

            assertTrue(result.isSuccess());
            List<KeyValuePair<String, Schema>> parsed = result.getUnchecked();
            assertThat(parsed.stream().map(pair -> pair.key).collect(Collectors.toList()),
                    contains("first", "second"));
            assertThat(parsed.stream().map(pair -> pair.value.getName()).collect(Collectors.toList()),
                    contains("First", "Second"));
        } finally {
            Files.deleteIfExists(first.toPath());
            Files.deleteIfExists(second.toPath());
        }
    }

    @Test
    public void parseAllFailsWhenAnySchemaCannotBeParsed() throws IOException {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);
        File valid = File.createTempFile("registry-action-valid", ".avsc");
        File invalid = File.createTempFile("registry-action-invalid", ".avsc");
        try {
            Files.write(valid.toPath(),
                    "{\"type\":\"record\",\"name\":\"Valid\",\"fields\":[]}"
                            .getBytes(StandardCharsets.UTF_8));
            Files.write(invalid.toPath(), "invalid".getBytes(StandardCharsets.UTF_8));

            Try<List<KeyValuePair<String, Schema>>> result = function.parseAll(Arrays.asList(
                    KeyValuePair.pair("valid", valid),
                    KeyValuePair.pair("invalid", invalid)));

            assertFalse(result.isSuccess());
        } finally {
            Files.deleteIfExists(valid.toPath());
            Files.deleteIfExists(invalid.toPath());
        }
    }

    @Test
    public void traversCollectsSuccessfulValuesInOrder() {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);
        List<Try<String>> tries = Arrays.asList(
                Try.ofFailable(() -> "first"),
                Try.ofFailable(() -> "second"));

        Try<Stream<String>> result = function.travers(tries);

        assertTrue(result.isSuccess());
        assertThat(result.getUnchecked().collect(Collectors.toList()),
                contains("first", "second"));
    }

    @Test
    public void traversReturnsFailureWhenAnElementFails() {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);
        List<Try<String>> tries = Arrays.asList(
                Try.ofFailable(() -> "first"),
                Try.<String>failure(new IllegalArgumentException("broken")));

        Try<Stream<String>> result = function.travers(tries);

        assertFalse(result.isSuccess());
    }

    @Test
    public void traversOfEmptyListSucceedsWithEmptyStream() {
        RegistryActionFunction function = new RegistryActionFunction(config(),
                (SchemaRegistryClient) null);

        Try<Stream<String>> result = function.travers(Collections.<Try<String>>emptyList());

        assertTrue(result.isSuccess());
        assertThat(result.getUnchecked().collect(Collectors.toList()), is(Collections.emptyList()));
    }

    @Test
    public void notNegatesPredicate() {
        Predicate<String> nonEmpty = value -> !value.isEmpty();
        Predicate<String> empty = RegistryActionFunction.not(nonEmpty);

        assertTrue(empty.test(""));
        assertFalse(empty.test("value"));
    }

    @Test
    public void tryStreamFileSubjectsReturnsFailureForMissingFile() {
        Config fileConfig = ConfigFactory.parseString(
                "avro.subjects.yaml = \"/path/that/does/not/exist/subjects.yaml\"");
        RegistryActionFunction function = new RegistryActionFunction(fileConfig,
                (SchemaRegistryClient) null);

        Try<FileInputStream> result = function.tryStreamFileSubjects();

        assertFalse(result.isSuccess());
    }
}
