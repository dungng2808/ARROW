package be.drissamri.service.verifier;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PhishTankUrlVerifier_ArrowTest {

  private static final String API_URL = "https://example.invalid/check";

  private PhishTankConfig configWithParameters(MultiValueMap<String, String> parameters) {
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.getParameters()).thenReturn(parameters);
    when(config.getApiUrl()).thenReturn(API_URL);
    return config;
  }

  @Test
  public void isSafeReturnsFalseWhenPhishTankReportsUrlInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(API_URL, parameters, String.class))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":true}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertFalse(verifier.isSafe("http://phishing.example"));
    assertTrue(parameters.get("url").contains("http://phishing.example"));
  }

  @Test
  public void isSafeReturnsTrueWhenPhishTankReportsUrlNotInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(API_URL, parameters, String.class))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":false}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("http://safe.example"));
  }

  @Test
  public void isSafeReturnsTrueWhenApiRespondsWithNonOkStatus() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(API_URL, parameters, String.class))
        .thenReturn(new ResponseEntity<String>("unavailable", HttpStatus.SERVICE_UNAVAILABLE));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("http://unknown.example"));
  }

  @Test
  public void isSafeReturnsTrueWhenResponseDoesNotContainExpectedPath() {
    RestTemplate client = mock(RestTemplate.class);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<String, String>();
    PhishTankConfig config = configWithParameters(parameters);
    when(client.postForEntity(API_URL, parameters, String.class))
        .thenReturn(new ResponseEntity<String>("{\"results\":{}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("http://unknown.example"));
  }

  @Test
  public void canValidateReturnsTrueWhenConfigurationIsEnabled() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = new PhishTankConfig();
    config.setApiKey("test-api-key");
    config.setAppUrl("https://example.invalid");
    config.setAppName("test-app");
    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.canValidate());
  }

  @Test
  public void canValidateReturnsFalseWhenConfigurationIsDisabled() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = new PhishTankConfig();
    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertFalse(verifier.canValidate());
  }
}
