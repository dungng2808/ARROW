package edu.jhuapl.dorset;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;

import edu.jhuapl.dorset.agents.Agent;
import edu.jhuapl.dorset.agents.AgentRequest;
import edu.jhuapl.dorset.agents.AgentResponse;
import edu.jhuapl.dorset.reporting.Report;
import edu.jhuapl.dorset.reporting.Reporter;
import edu.jhuapl.dorset.routing.Router;

public class Application_ArrowTest {

    @Test
    public void getAgentsReturnsAgentsProvidedByRouter() {
        Agent agent = mock(Agent.class);
        Agent[] agents = new Agent[] { agent };
        Router router = mock(Router.class);
        when(router.getAgents()).thenReturn(agents);

        Application application = new Application(router);

        assertSame(agents, application.getAgents());
    }

    @Test
    public void processReturnsFirstNonNullAgentResponseAndStoresReport() {
        Agent firstAgent = mock(Agent.class);
        Agent secondAgent = mock(Agent.class);
        Agent[] agents = new Agent[] { firstAgent, secondAgent };
        Router router = mock(Router.class);
        when(router.getAgents()).thenReturn(agents);
        when(router.route(org.mockito.Matchers.any(Request.class))).thenReturn(agents);

        AgentResponse expectedAgentResponse = new AgentResponse("answer");
        when(firstAgent.process(org.mockito.Matchers.any(AgentRequest.class)))
                .thenReturn(expectedAgentResponse);

        Reporter reporter = mock(Reporter.class);
        Application application = new Application(router, reporter);
        Request request = new Request("hello");

        Response response = application.process(request);

        assertNotNull(response);
        assertEquals("answer", response.getText());
        verify(firstAgent).process(org.mockito.Matchers.any(AgentRequest.class));
        verify(secondAgent, never())
                .process(org.mockito.Matchers.any(AgentRequest.class));
        verify(reporter).store(org.mockito.Matchers.any(Report.class));
    }

    @Test
    public void processReturnsNoAvailableAgentWhenRouterHasNoRoute() {
        Router router = mock(Router.class);
        when(router.getAgents()).thenReturn(new Agent[0]);
        when(router.route(org.mockito.Matchers.any(Request.class))).thenReturn(new Agent[0]);

        Application application = new Application(router);
        Response response = application.process(new Request("unhandled"));

        assertEquals(ResponseStatus.Code.NO_AVAILABLE_AGENT, response.getStatus().getCode());
    }

    @Test
    public void processReturnsNoResponseWhenAllRoutedAgentsReturnNull() {
        Agent agent = mock(Agent.class);
        Agent[] agents = new Agent[] { agent };
        Router router = mock(Router.class);
        when(router.getAgents()).thenReturn(agents);
        when(router.route(org.mockito.Matchers.any(Request.class))).thenReturn(agents);
        when(agent.process(org.mockito.Matchers.any(AgentRequest.class))).thenReturn(null);

        Application application = new Application(router);
        Response response = application.process(new Request("no answer"));

        assertEquals(ResponseStatus.Code.NO_RESPONSE_FROM_AGENT, response.getStatus().getCode());
    }

    @Test
    public void shutdownInvokesRegisteredListeners() {
        Router router = mock(Router.class);
        when(router.getAgents()).thenReturn(new Agent[0]);
        Application application = new Application(router);
        final int[] calls = new int[] { 0 };

        application.addShutdownListener(new ShutdownListener() {
            @Override
            public void shutdown() {
                calls[0]++;
            }
        });

        application.shutdown();

        assertEquals(1, calls[0]);
    }
}
