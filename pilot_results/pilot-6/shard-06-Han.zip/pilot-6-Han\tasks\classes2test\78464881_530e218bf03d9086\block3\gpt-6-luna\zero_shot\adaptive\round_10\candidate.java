package com.solace.spring.boot.autoconfigure;

import com.solace.spring.cloud.core.SolaceMessagingInfo;
import org.junit.Test;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.ServiceInfo;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

public class SolaceJmsAutoCloudConfiguration_ArrowTest {

    @Test
    public void getSolaceMessagingInfosReturnsMatchingServicesInOrder() throws Exception {
        SolaceMessagingInfo first = new SolaceMessagingInfo();
        SolaceMessagingInfo second = new SolaceMessagingInfo();
        ServiceInfo other = new ServiceInfo() {
            @Override
            public String getId() {
                return "other";
            }
        };

        SolaceJmsAutoCloudConfiguration configuration =
                new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());
        setCloudFactory(configuration, cloudFactoryWith(Arrays.<ServiceInfo>asList(other, first, second)));

        List<SolaceMessagingInfo> infos = configuration.getSolaceMessagingInfos();

        assertEquals(2, infos.size());
        assertSame(first, infos.get(0));
        assertSame(second, infos.get(1));
    }

    @Test
    public void findFirstSolaceMessagingInfoReturnsFirstMatchingService() throws Exception {
        SolaceMessagingInfo first = new SolaceMessagingInfo();
        SolaceMessagingInfo second = new SolaceMessagingInfo();
        ServiceInfo other = new ServiceInfo() {
            @Override
            public String getId() {
                return "other";
            }
        };

        SolaceJmsAutoCloudConfiguration configuration =
                new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());
        setCloudFactory(configuration, cloudFactoryWith(Arrays.<ServiceInfo>asList(other, first, second)));

        assertSame(first, configuration.findFirstSolaceMessagingInfo());
    }

    @Test
    public void findFirstSolaceMessagingInfoFailsWhenNoSolaceServiceExists() throws Exception {
        SolaceJmsAutoCloudConfiguration configuration =
                new SolaceJmsAutoCloudConfiguration(new SolaceJmsProperties());
        setCloudFactory(configuration, cloudFactoryWith(Collections.<ServiceInfo>emptyList()));

        try {
            configuration.findFirstSolaceMessagingInfo();
            fail("Expected an IllegalStateException when no Solace service is available");
        } catch (IllegalStateException expected) {
            assertEquals(
                    "Unable to create SolConnectionFactory did not find SolaceMessagingInfo in the current cloud environment",
                    expected.getMessage());
        }
    }

    private static CloudFactory cloudFactoryWith(final List<ServiceInfo> serviceInfos) {
        return new CloudFactory() {
            @Override
            public Cloud getCloud() {
                return new Cloud(null, null) {
                    @Override
                    public List<ServiceInfo> getServiceInfos() {
                        return serviceInfos;
                    }
                };
            }
        };
    }

    private static void setCloudFactory(SolaceJmsAutoCloudConfiguration configuration,
                                        CloudFactory cloudFactory) throws Exception {
        Field field = SolaceJmsAutoCloudConfiguration.class.getDeclaredField("cloudFactory");
        field.setAccessible(true);
        field.set(configuration, cloudFactory);
    }
}
