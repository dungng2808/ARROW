# Báo cáo pilot: pilot-6-shard-06-Han

Pilot kiểm tra môi trường, công cụ, chi phí (phần 1) và chọn số vòng sửa tối đa N (phần 2). Pilot **không** trả lời câu hỏi nghiên cứu và không gộp vào kết quả chính.

## Thông tin run

- Cấu hình thực nghiệm: `pilot-v1` (sha256 `d5567edc789801809a9b2dc43e94ea6ef4ffd9cce12182fb5df771dddd991950`), `n_max` = 10, quy tắc N = `share95`
- Model id trả về: `gpt-6-luna`
- Thời điểm tạo báo cáo: 2026-10-13 09:46 UTC

| Máy | Hệ điều hành | CPU | RAM (GB) | Endpoint | Commit tool | Shard |
| --- | --- | --- | --- | --- | --- | --- |
| Han | win-x64 | 12 | 23 | api.teamorouter.com | `976fc02c` (dirty) | shard-06 |

## Phần 1: môi trường, công cụ, chi phí

### 1.1. Thời gian và chi phí theo bước (`part1_cost.csv`)

| Bước | Dataset | Số lần | Trung vị (s) | p90 (s) | Max (s) | Tổng (s) | Token vào | Token ra | Chi phí (USD) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| clone | classes2test | 10 | 3.2 | 58.2 | 126.9 | 196 | 0 | 0 | 0.0000 |
| baseline | classes2test | 10 | 19.9 | 47.6 | 196.2 | 375 | 0 | 0 | 0.0000 |
| llm_generate | classes2test | 30 | 5.8 | 34.7 | 154.0 | 504 | 55598 | 23766 | 0.0087 |
| build_verify | classes2test | 28 | 8.2 | 19.8 | 41.7 | 338 | 0 | 0 | 0.0000 |
| llm_repair | classes2test | 313 | 4.9 | 18.4 | 249.2 | 3616 | 786316 | 239694 | 0.0992 |
| build_repair | classes2test | 251 | 14.4 | 22.9 | 187.4 | 4301 | 0 | 0 | 0.0000 |
| evosuite | classes2test | 10 | 134.0 | 170.3 | 173.5 | 1286 | 0 | 0 | 0.0000 |
| jacoco | classes2test | 32 | 17.6 | 39.1 | 50.0 | 726 | 0 | 0 | 0.0000 |
| pit | classes2test | 32 | 20.0 | 29.6 | 148.3 | 839 | 0 | 0 | 0.0000 |
| tsdetect | classes2test | 32 | 2.0 | 2.6 | 2.8 | 64 | 0 | 0 | 0.0000 |

### 1.2. Lỗi hạ tầng (`part1_infra_errors.csv`)

Không có job lỗi hạ tầng.

### 1.3. Kết quả bước sinh test (chỉ để kiểm tra pipeline, không phải kết quả RQ1)

| Dataset | Quy trình | COMPILE | UNKNOWN | DISCOVERY | RUNTIME | ASSERTION | REGRESSION | VALID | INFRA | Output không hợp lệ |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| classes2test | few_shot | 2 | 5 | 1 | 1 | 1 | 0 | 0 | 0 | 1 |
| classes2test | zero_shot | 2 | 5 | 1 | 1 | 0 | 0 | 1 | 0 | 1 |
| classes2test | zero_shot_project_aware | 0 | 4 | 1 | 2 | 1 | 0 | 2 | 0 | 0 |

Bước kiểm tra và chuẩn hóa output (specs/04 Mục 3) là một phần của pipeline, áp dụng giống nhau cho mọi quy trình prompting.

### 1.4. Ước tính cho phần GPT-6 Luna của thực nghiệm chính

| Hạng mục | Số lượng | Thời gian ước tính (giờ, một máy) | Chi phí ước tính (USD) |
| --- | --- | ---: | ---: |
| RQ1 | 200 × 3 + 32 × 3 = 696 ứng viên | 2.7 | 0.20 |
| RQ2 | 120 ứng viên Classes2Test + ứng viên GitBug-Java thất bại, × 2 cơ chế × tối đa N = 7 vòng (cận trên, chưa gồm GitBug-Java) | 9.0 | 0.53 |
| RQ3 | EvoSuite, JaCoCo, PIT, tsDetect cho 232 CUT | 11.2 | 0 |

Ước tính dựa trên thời gian trung vị và chi phí trung bình mỗi lượt của pilot (chỉ GPT-6 Luna). Phần Qwen3-Coder-30B **không** ước tính được từ pilot.

## Phần 2: chọn N (chỉ Classes2Test)

- Chuỗi sửa (ứng viên × cơ chế) dùng để tính: 50; loại vì lỗi hạ tầng chưa giải quyết: 0; chưa chạy xong: 0.
- Ứng viên không vào bước sửa: 2 (INVALID_OUTPUT: 2).
- Số liệu chung hai cơ chế; báo cáo pilot không tách Fixed và Adaptive.

| Vòng k | S(k) cộng dồn | S(k) / S(n_max) |
| ---: | ---: | ---: |
| 1 | 10 | 0.42 |
| 2 | 21 | 0.88 |
| 3 | 21 | 0.88 |
| 4 | 21 | 0.88 |
| 5 | 22 | 0.92 |
| 6 | 22 | 0.92 |
| 7 | 23 | 0.96 |
| 8 | 23 | 0.96 |
| 9 | 24 | 1.00 |
| 10 | 24 | 1.00 |

**N theo quy tắc `share95`: 7.**

Phân tích độ nhạy: `report2` → 10, `share90` → 5, `share95` → 7, `share99` → 9.

## Tổng quan để chuẩn bị thực nghiệm chính

Các bảng dưới chỉ để kiểm tra pipeline và ước lượng khối lượng việc; **không phải kết quả RQ1, RQ2, RQ3**. Kết quả sửa gộp chung hai cơ chế; không so chất lượng giữa ARROW và EvoSuite.

### A. Bước sinh test: tỷ lệ qua từng bước xác minh

| Dataset | Quy trình | Ứng viên | Compile | Discovery | Execution | Target pass | Không regression (VALID) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| classes2test | few_shot | 10 | 30% (3/10) | 20% (2/10) | 20% (2/10) | 0% (0/10) | 0% (0/10) |
| classes2test | zero_shot | 10 | 30% (3/10) | 20% (2/10) | 20% (2/10) | 10% (1/10) | 10% (1/10) |
| classes2test | zero_shot_project_aware | 10 | 60% (6/10) | 50% (5/10) | 50% (5/10) | 20% (2/10) | 20% (2/10) |

Lỗi thường gặp nhất ở bước sinh (theo error signature):

| Error signature | Số ứng viên |
| --- | ---: |
| `UNKNOWN \| maven-compiler-plugin \| -` | 14 |
| `DISCOVERY \| no tests executed \| -` | 3 |
| `RUNTIME \| InvalidTestClassError \| -` | 2 |
| `COMPILE \| cannot find symbol \| method` | 2 |
| `COMPILE \| invalid output \| -` | 2 |
| `RUNTIME \| NullPointerException \| PhishTankConfig.getParameters` | 1 |
| `ASSERTION \| AssertionError \| fillTreeAndCalculateProducesStableTree` | 1 |
| `ASSERTION \| AssertionError \| createsLeavesAcrossTheConfiguredRange` | 1 |

### B. Bước sửa (gộp Fixed và Adaptive)

| Chỉ số | Giá trị |
| --- | ---: |
| Chuỗi sửa | 50 |
| Đạt VALID trong 10 vòng | 48% (24/50) |
| Vòng đạt VALID (trung vị) | 2 |
| Thời gian một chuỗi, gồm gọi model và build (trung vị, giây) | 166 |
| Token một chuỗi (trung vị, vào / ra) | 5272 / 1671 |
| Số vòng có rollback / mã trùng / output không hợp lệ / mức 3 (tổng) | 18 / 62 / 0 / 27 |
| Test method bị bỏ ở mức 3 (tổng) | 18 |

Trạng thái ban đầu (c0) của các chuỗi:

| Trạng thái c0 | Chuỗi | Đạt VALID |
| --- | ---: | ---: |
| COMPILE | 4 | 100% (4/4) |
| UNKNOWN | 28 | 39% (11/28) |
| DISCOVERY | 6 | 17% (1/6) |
| RUNTIME | 8 | 50% (4/8) |
| ASSERTION | 4 | 100% (4/4) |

N theo `share95`: 7 (xem phần 2).

### C. EvoSuite chạy được với bao nhiêu CUT

| Dataset | CUT | Sinh được test | Không hỗ trợ JDK (Java > 11) | Lỗi khác | Bộ test VALID |
| --- | ---: | ---: | ---: | ---: | ---: |
| classes2test | 10 | 100% (10/10) | 0 | 0 | 50% (5/10) |

### D. Bộ đo chất lượng chạy được trên bao nhiêu bộ test VALID

| Công cụ | Bộ test đã đo | Đo được (OK) | Lý do không đo được |
| --- | ---: | ---: | --- |
| JaCoCo | 32 | 100% (32/32) | - |
| PIT | 32 | 100% (32/32) | - |
| tsDetect | 32 | 100% (32/32) | - |

## Ngoại lệ đã khai báo

- Cờ build chung bỏ qua plugin định dạng, giấy phép, coverage tối thiểu của repository (specs/02 Mục 4.3), như nhau cho mọi hệ thống; ghi trong `run_config.lock.json`.
- JVM của mọi bước build chạy với locale `en_US` và múi giờ UTC (specs/02 Mục 3 bước 6).
- EvoSuite: `evosuite-standalone-runtime-1.2.0.jar` thêm vào scope test chỉ trong workspace của job EvoSuite và job đo bộ test EvoSuite (specs/06 Mục 1).
- PIT chạy bản dòng lệnh 1.17.4 cho mọi build tool; module JUnit 5 thêm `pitest-junit5-plugin` 1.2.1 và `junit-platform-launcher` cùng phiên bản platform (specs/06 Mục 2.2).
- Mẫu Classes2Test của pilot sàng lọc bằng S0 (tiêu chí B, `evaluation_manifest/pilot/README.md`); revision là content-matched.

## Hạn chế

- Pilot chỉ chạy GPT-6 Luna; N chọn trên GPT-6 Luna được áp dụng cho cả Qwen3-Coder-30B, có thể chưa tối ưu cho Qwen.
- Thực nghiệm chạy một lần cho mỗi cấu hình.
