package fr.xebia.ldi;

import com.jasongoodwin.monads.Try;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import org.apache.avro.Schema;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

import static org.junit.jupiter.api.Assertions.*;

public class RegistryActionFunction_ArrowTest {

    private Config config() {
        return ConfigFactory.parseString(
                "schema.registry.url = \"http://localhost:8081\"\n" +
                "schema.registry.capacity = 10\n" +
                "schema.registry.config {}\n" +
                "avro.files.path = \"/tmp/registry-action-test\"\n" +
                "avro.subjects.yaml = \"/tmp/registry-action-test-subjects.yaml\"");
    }

    @Test
    public void getParserParsesValidAvroSchema() {
        RegistryActionFunction function = new RegistryActionFunction(config());
        Schema schema = function.getParser().parse(
                "{\"type\":\"record\",\"name\":\"Example\",\"fields\":[{\"name\":\"value\",\"type\":\"string\"}]}");

        assertEquals("Example", schema.getName());
        assertEquals(Schema.Type.RECORD, schema.getType());
        assertEquals(Schema.Type.STRING, schema.getField("value").schema().getType());
    }

    @Test
    public void mapSubjectToFileUsesConfiguredBaseDirectory() {
        RegistryActionFunction function = new RegistryActionFunction(config());
        SchemaList.SubjectEntry subject = new SchemaList.SubjectEntry();
        subject.setSubject("orders-value");
        subject.setFile("orders.avsc");

        List<KeyValuePair<String, File>> mapped =
                function.mapSubjectToFile(Collections.singletonList(subject));

        assertEquals(1, mapped.size());
        assertEquals("orders-value", mapped.get(0).key);
        assertEquals(new File("/tmp/registry-action-test", "orders.avsc"), mapped.get(0).value);
    }

    @Test
    public void parseAllReturnsParsedSchemasForEverySubject() {
        RegistryActionFunction function = new RegistryActionFunction(config());
        File first = writeSchema("First", "{\"type\":\"record\",\"name\":\"First\",\"fields\":[]}");
        File second = writeSchema("Second", "{\"type\":\"record\",\"name\":\"Second\",\"fields\":[]}");

        try {
            List<KeyValuePair<String, File>> inputs = Arrays.asList(
                    KeyValuePair.pair("first-subject", first),
                    KeyValuePair.pair("second-subject", second));

            List<KeyValuePair<String, Schema>> parsed = function.parseAll(inputs).get();

            assertEquals(2, parsed.size());
            assertEquals("first-subject", parsed.get(0).key);
            assertEquals("First", parsed.get(0).value.getName());
            assertEquals("second-subject", parsed.get(1).key);
            assertEquals("Second", parsed.get(1).value.getName());
        } finally {
            first.delete();
            second.delete();
        }
    }

    @Test
    public void parseAllFailsWhenAnySchemaFileIsInvalid() {
        RegistryActionFunction function = new RegistryActionFunction(config());
        File valid = writeSchema("Valid", "{\"type\":\"record\",\"name\":\"Valid\",\"fields\":[]}");
        File missing = new File(valid.getParentFile(), "missing-schema-" + valid.getName());

        try {
            List<KeyValuePair<String, File>> inputs = Arrays.asList(
                    KeyValuePair.pair("valid-subject", valid),
                    KeyValuePair.pair("missing-subject", missing));

            Try<List<KeyValuePair<String, Schema>>> result = function.parseAll(inputs);

            assertFalse(result.isSuccess());
        } finally {
            valid.delete();
        }
    }

    @Test
    public void testOneUsesInjectedSchemaRegistryClient() throws Exception {
        SchemaRegistryClient client = (SchemaRegistryClient) Proxy.newProxyInstance(
                SchemaRegistryClient.class.getClassLoader(),
                new Class<?>[]{SchemaRegistryClient.class},
                (proxy, method, args) -> {
                    if ("testCompatibility".equals(method.getName())) {
                        return "compatible-subject".equals(args[0])
                                && "Compatible".equals(((Schema) args[1]).getName());
                    }
                    return null;
                });

        RegistryActionFunction function = new RegistryActionFunction(config(), client);
        Schema schema = new Schema.Parser().parse(
                "{\"type\":\"record\",\"name\":\"Compatible\",\"fields\":[]}");

        KeyValuePair<String, Boolean> result =
                function.testOne(KeyValuePair.pair("compatible-subject", schema)).get();

        assertEquals("compatible-subject", result.key);
        assertTrue(result.value);
    }

    @Test
    public void notNegatesPredicate() {
        Predicate<String> nonEmpty = RegistryActionFunction.not(String::isEmpty);

        assertTrue(nonEmpty.test("value"));
        assertFalse(nonEmpty.test(""));
    }

    private File writeSchema(String name, String contents) {
        try {
            File file = File.createTempFile("registry-action-" + name, ".avsc");
            java.nio.file.Files.write(file.toPath(), contents.getBytes("UTF-8"));
            file.deleteOnExit();
            return file;
        } catch (Exception e) {
            throw new AssertionError(e);
        }
    }
}
