package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.impl.Parser;
import org.junit.Test;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class FlowParser_ArrowTest {

    private static final String VALID_SOURCE = "flow test { }";

    @Test
    public void createWithoutConfigurationParsesFlowSource() {
        Parser<?> parser = FlowParser.create();

        AstNode astNode = parser.parse(VALID_SOURCE);

        assertNotNull(astNode);
    }

    @Test
    public void createWithConfigurationParsesFlowSource() {
        Parser<?> parser = FlowParser.create(new FlowConfiguration(Charset.defaultCharset()));

        AstNode astNode = parser.parse(VALID_SOURCE);

        assertNotNull(astNode);
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String missingPath = new File(System.getProperty("java.io.tmpdir"),
                "flow-parser-missing-" + System.nanoTime()).getAbsolutePath();

        try {
            FlowParser.parseFile(missingPath);
            fail("Expected an AssertionError for a missing file");
        } catch (AssertionError expected) {
            assertTrue(expected.getMessage().contains(missingPath));
        }
    }

    @Test
    public void parseFileParsesExistingFlowFile() throws Exception {
        File file = File.createTempFile("flow-parser-", ".flow");
        try {
            Files.write(file.toPath(), VALID_SOURCE.getBytes(Charset.defaultCharset()));

            AstNode astNode = FlowParser.parseFile(file.getAbsolutePath());

            assertNotNull(astNode);
        } finally {
            Files.deleteIfExists(file.toPath());
        }
    }

    @Test
    public void parseStringParsesFlowSource() {
        AstNode astNode = FlowParser.parseString(VALID_SOURCE);

        assertNotNull(astNode);
    }
}
