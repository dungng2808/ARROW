package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.impl.Parser;
import org.junit.Test;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class FlowParser_ArrowTest {

    @Test
    public void createWithoutConfigurationParsesEmptySource() {
        Parser<?> parser = FlowParser.create();

        AstNode astNode = parser.parse("");

        assertNotNull(astNode);
    }

    @Test
    public void createWithConfigurationParsesEmptySource() {
        Parser<?> parser = FlowParser.create(new FlowConfiguration(Charset.defaultCharset()));

        AstNode astNode = parser.parse("");

        assertNotNull(astNode);
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String missingPath = new File(System.getProperty("java.io.tmpdir"),
                "flow-parser-missing-" + System.nanoTime()).getAbsolutePath();

        try {
            FlowParser.parseFile(missingPath);
            fail("Expected an AssertionError for a missing file");
        } catch (AssertionError expected) {
            assertTrue(expected.getMessage().contains(missingPath));
        }
    }

    @Test
    public void parseFileParsesExistingEmptyFile() throws Exception {
        File file = File.createTempFile("flow-parser-", ".flow");
        try {
            Files.write(file.toPath(), new byte[0]);

            AstNode astNode = FlowParser.parseFile(file.getAbsolutePath());

            assertNotNull(astNode);
        } finally {
            Files.deleteIfExists(file.toPath());
        }
    }

    @Test
    public void parseStringParsesEmptySource() {
        AstNode astNode = FlowParser.parseString("");

        assertNotNull(astNode);
    }
}
