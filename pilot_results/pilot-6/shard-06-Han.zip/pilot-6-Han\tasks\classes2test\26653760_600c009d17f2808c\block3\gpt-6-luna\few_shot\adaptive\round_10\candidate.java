package be.drissamri.service.verifier;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class PhishTankUrlVerifier_ArrowTest {

  private static final String API_URL = "https://example.test/check";

  private PhishTankConfig configuredConfig() {
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.getParameters()).thenReturn(null);
    when(config.getApiUrl()).thenReturn(API_URL);
    return config;
  }

  private MultiValueMap<String, String> capturedParameters(RestTemplate client) {
    org.mockito.ArgumentCaptor<MultiValueMap> captor =
        org.mockito.ArgumentCaptor.forClass(MultiValueMap.class);
    verify(client).postForEntity(
        org.mockito.Matchers.eq(API_URL), captor.capture(),
        org.mockito.Matchers.eq(String.class));
    return captor.getValue();
  }

  @Test
  public void reportsUnsafeWhenPhishTankFindsUrlInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = configuredConfig();
    when(client.postForEntity(
        org.mockito.Matchers.eq(API_URL), any(MultiValueMap.class),
        org.mockito.Matchers.eq(String.class)))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":true}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertFalse(verifier.isSafe("https://malicious.test"));
    assertTrue(capturedParameters(client).getFirst("url").equals("https://malicious.test"));
  }

  @Test
  public void reportsSafeWhenPhishTankDoesNotFindUrlInDatabase() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = configuredConfig();
    when(client.postForEntity(
        org.mockito.Matchers.eq(API_URL), any(MultiValueMap.class),
        org.mockito.Matchers.eq(String.class)))
        .thenReturn(new ResponseEntity<String>(
            "{\"results\":{\"in_database\":false}}", HttpStatus.OK));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://safe.test"));
    assertTrue(capturedParameters(client).getFirst("url").equals("https://safe.test"));
  }

  @Test
  public void remainsSafeWhenApiReturnsNonOkStatus() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = configuredConfig();
    when(client.postForEntity(
        org.mockito.Matchers.eq(API_URL), any(MultiValueMap.class),
        org.mockito.Matchers.eq(String.class)))
        .thenReturn(new ResponseEntity<String>("", HttpStatus.SERVICE_UNAVAILABLE));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://unknown.test"));
    assertTrue(capturedParameters(client).getFirst("url").equals("https://unknown.test"));
  }

  @Test
  public void remainsSafeWhenRequestThrowsRestClientException() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = configuredConfig();
    when(client.postForEntity(
        org.mockito.Matchers.eq(API_URL), any(MultiValueMap.class),
        org.mockito.Matchers.eq(String.class)))
        .thenThrow(new RestClientException("offline"));

    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.isSafe("https://unknown.test"));
    assertTrue(capturedParameters(client).getFirst("url").equals("https://unknown.test"));
  }

  @Test
  public void canValidateReflectsConfiguration() {
    RestTemplate client = mock(RestTemplate.class);
    PhishTankConfig config = mock(PhishTankConfig.class);
    when(config.isConfigured()).thenReturn(true);
    PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

    assertTrue(verifier.canValidate());

    when(config.isConfigured()).thenReturn(false);
    assertFalse(verifier.canValidate());
  }
}
