package edu.jhuapl.dorset;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

import org.junit.Test;

import edu.jhuapl.dorset.ResponseStatus.Code;
import edu.jhuapl.dorset.agents.Agent;
import edu.jhuapl.dorset.agents.AgentRequest;
import edu.jhuapl.dorset.agents.AgentResponse;
import edu.jhuapl.dorset.agents.Description;
import edu.jhuapl.dorset.routing.Router;

public class Application_ArrowTest {

    @Test
    public void processReturnsNoAvailableAgentWhenRouterHasNoAgents() {
        Router router = new Router() {
            @Override
            public Agent[] getAgents() {
                return new Agent[0];
            }

            @Override
            public Agent[] route(Request request) {
                return new Agent[0];
            }
        };
        Application application = new Application(router);

        Response response = application.process(new Request("hello"));

        assertNotNull(response);
        assertEquals(Code.NO_AVAILABLE_AGENT, response.getStatus().getCode());
    }

    @Test
    public void processReturnsFirstAgentResponse() {
        final AgentResponse expectedAgentResponse = new AgentResponse("answer");
        Agent agent = new Agent() {
            @Override
            public AgentResponse process(AgentRequest request) {
                return expectedAgentResponse;
            }

            @Override
            public Description getDescription() {
                return null;
            }

            @Override
            public void setDescription(Description description) {
            }
        };
        Router router = new Router() {
            @Override
            public Agent[] getAgents() {
                return new Agent[] { agent };
            }

            @Override
            public Agent[] route(Request request) {
                return new Agent[] { agent };
            }
        };
        Application application = new Application(router);

        Response response = application.process(new Request("question"));

        assertNotNull(response);
        assertEquals("answer", response.getText());
    }

    @Test
    public void getAgentsReturnsAgentsProvidedByRouter() {
        Agent agent = new Agent() {
            @Override
            public AgentResponse process(AgentRequest request) {
                return null;
            }

            @Override
            public Description getDescription() {
                return null;
            }

            @Override
            public void setDescription(Description description) {
            }
        };
        final Agent[] agents = new Agent[] { agent };
        Router router = new Router() {
            @Override
            public Agent[] getAgents() {
                return agents;
            }

            @Override
            public Agent[] route(Request request) {
                return agents;
            }
        };

        Application application = new Application(router);

        assertSame(agents, application.getAgents());
    }
}
