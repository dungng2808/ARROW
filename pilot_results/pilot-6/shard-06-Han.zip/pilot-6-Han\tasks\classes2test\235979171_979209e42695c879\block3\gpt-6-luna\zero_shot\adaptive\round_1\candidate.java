package fr.xebia.ldi;

import com.jasongoodwin.monads.Try;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import org.apache.avro.Schema;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import static org.junit.jupiter.api.Assertions.*;

public class RegistryActionFunction_ArrowTest {

    private Config config() {
        return ConfigFactory.parseString(
                "schema.registry.url = \"http://localhost:8081\"\n" +
                "schema.registry.capacity = 10\n" +
                "schema.registry.config {}\n" +
                "avro.files.path = \"/tmp/registry-action-test\"\n" +
                "avro.subjects.yaml = \"/tmp/registry-action-test-subjects.yaml\"");
    }

    @Test
    public void getParserParsesValidAvroSchema() {
        RegistryActionFunction function = new RegistryActionFunction(config());
        Schema schema = function.getParser().parse(
                "{\"type\":\"record\",\"name\":\"Example\",\"fields\":[{\"name\":\"value\",\"type\":\"string\"}]}");

        assertEquals("Example", schema.getName());
        assertEquals(Schema.Type.RECORD, schema.getType());
        assertEquals(Schema.Type.STRING, schema.getField("value").schema().getType());
    }

    @Test
    public void mapSubjectToFileUsesConfiguredBaseDirectory() {
        RegistryActionFunction function = new RegistryActionFunction(config());
        SchemaList.SubjectEntry subject = new SchemaList.SubjectEntry();
        subject.setSubject("orders-value");
        subject.setFile("orders.avsc");

        List<KeyValuePair<String, File>> mapped =
                function.mapSubjectToFile(Collections.singletonList(subject));

        assertEquals(1, mapped.size());
        assertEquals("orders-value", mapped.get(0).key);
        assertEquals(new File("/tmp/registry-action-test", "orders.avsc"), mapped.get(0).value);
    }

    @Test
    public void parseAllReturnsParsedSchemasForEverySubject() {
        RegistryActionFunction function = new RegistryActionFunction(config());
        File first = writeSchema("First", "{\"type\":\"record\",\"name\":\"First\",\"fields\":[]}");
        File second = writeSchema("Second", "{\"type\":\"record\",\"name\":\"Second\",\"fields\":[]}");

        try {
            List<KeyValuePair<String, File>> inputs = Arrays.asList(
                    KeyValuePair.pair("first-subject", first),
                    KeyValuePair.pair("second-subject", second));

            List<KeyValuePair<String, Schema>> parsed = function.parseAll(inputs).get();

            assertEquals(2, parsed.size());
            assertEquals("first-subject", parsed.get(0).key);
            assertEquals("First", parsed.get(0).value.getName());
            assertEquals("second-subject", parsed.get(1).key);
            assertEquals("Second", parsed.get(1).value.getName());
        } finally {
            first.delete();
            second.delete();
        }
    }

    @Test
    public void parseAllReturnsFailedTryWhenSchemaFileIsMissing() {
        RegistryActionFunction function = new RegistryActionFunction(config());
        File missing = new File(System.getProperty("java.io.tmpdir"),
                "registry-action-missing-" + System.nanoTime() + ".avsc");

        Try<List<KeyValuePair<String, Schema>>> result =
                function.parseAll(Collections.singletonList(
                        KeyValuePair.pair("missing-subject", missing)));

        assertFalse(result.isSuccess());
    }

    @Test
    public void testOneUsesInjectedSchemaRegistryClient() throws Exception {
        SchemaRegistryClient client = new CachedSchemaRegistryClient(
                "http://localhost:8081", 10, Collections.<String, String>emptyMap()) {
            @Override
            public boolean testCompatibility(String subject, Schema schema) {
                return "compatible-subject".equals(subject) && "Compatible".equals(schema.getName());
            }
        };
        RegistryActionFunction function = new RegistryActionFunction(config(), client);
        Schema schema = new Schema.Parser().parse(
                "{\"type\":\"record\",\"name\":\"Compatible\",\"fields\":[]}");

        KeyValuePair<String, Boolean> result =
                function.testOne(KeyValuePair.pair("compatible-subject", schema)).get();

        assertEquals("compatible-subject", result.key);
        assertTrue(result.value);
    }

    @Test
    public void getClientReturnsInjectedClient() {
        SchemaRegistryClient client = new CachedSchemaRegistryClient(
                "http://localhost:8081", 10, Collections.<String, String>emptyMap());
        RegistryActionFunction function = new RegistryActionFunction(config(), client);

        assertSame(client, function.getClient());
    }

    @Test
    public void notNegatesPredicate() {
        Predicate<String> nonEmpty = RegistryActionFunction.not(String::isEmpty);

        assertTrue(nonEmpty.test("value"));
        assertFalse(nonEmpty.test(""));
    }

    private File writeSchema(String name, String contents) {
        try {
            File file = File.createTempFile("registry-action-" + name, ".avsc");
            java.nio.file.Files.write(file.toPath(), contents.getBytes("UTF-8"));
            file.deleteOnExit();
            return file;
        } catch (Exception e) {
            throw new AssertionError(e);
        }
    }
}
