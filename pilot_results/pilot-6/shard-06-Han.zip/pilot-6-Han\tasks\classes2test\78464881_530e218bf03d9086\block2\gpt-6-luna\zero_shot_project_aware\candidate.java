package com.solace.spring.boot.autoconfigure;

import com.solace.spring.cloud.core.SolaceMessagingInfo;
import com.solace.spring.boot.autoconfigure.SolaceJmsProperties;
import com.solacesystems.jms.SolConnectionFactory;
import javax.jms.ConnectionFactory;
import org.junit.Test;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.jms.JmsAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.CloudFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import static org.assertj.core.api.Assertions.assertThat;

public class SolaceJmsAutoCloudConfiguration_ArrowTest {

    @Test
    public void declaresCloudAutoConfigurationConditionsAndProperties() {
        Class<SolaceJmsAutoCloudConfiguration> configurationClass =
                SolaceJmsAutoCloudConfiguration.class;

        assertThat(configurationClass.getAnnotation(Configuration.class)).isNotNull();

        AutoConfigureBefore autoConfigureBefore =
                configurationClass.getAnnotation(AutoConfigureBefore.class);
        assertThat(autoConfigureBefore).isNotNull();
        assertThat(autoConfigureBefore.value()).contains(JmsAutoConfiguration.class);

        ConditionalOnClass conditionalOnClass =
                configurationClass.getAnnotation(ConditionalOnClass.class);
        assertThat(conditionalOnClass).isNotNull();
        assertThat(conditionalOnClass.value()).contains(
                ConnectionFactory.class, SolConnectionFactory.class, CloudFactory.class);

        ConditionalOnMissingBean conditionalOnMissingBean =
                configurationClass.getAnnotation(ConditionalOnMissingBean.class);
        assertThat(conditionalOnMissingBean).isNotNull();
        assertThat(conditionalOnMissingBean.value()).contains(
                ConnectionFactory.class, org.springframework.jndi.JndiTemplate.class);

        Conditional conditional = configurationClass.getAnnotation(Conditional.class);
        assertThat(conditional).isNotNull();
        assertThat(conditional.value()).contains(CloudCondition.class);

        EnableConfigurationProperties properties =
                configurationClass.getAnnotation(EnableConfigurationProperties.class);
        assertThat(properties).isNotNull();
        assertThat(properties.value()).contains(SolaceJmsProperties.class);
    }

    @Test
    public void firstMessagingInfoFactoryMethodIsPrimaryBean() throws Exception {
        java.lang.reflect.Method factoryMethod =
                SolaceJmsAutoCloudConfiguration.class.getMethod("findFirstSolaceMessagingInfo");

        assertThat(factoryMethod.getReturnType()).isEqualTo(SolaceMessagingInfo.class);
        assertThat(factoryMethod.getAnnotation(Bean.class)).isNotNull();
        assertThat(factoryMethod.getAnnotation(Primary.class)).isNotNull();
    }
}
