package coverage_metrics;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoverageMetrics_ArrowTest {

    @Test
    public void fReturnsZeroForZeroInput() {
        // Arrange
        CoverageMetrics metrics = new CoverageMetrics();

        // Act
        float result = metrics.f(0);

        // Assert
        assertEquals(0.0f, result, 0.0f);
    }

    @Test
    public void fHalvesNonzeroInput() {
        // Arrange
        CoverageMetrics metrics = new CoverageMetrics();

        // Act
        float result = metrics.f(8);

        // Assert
        assertEquals(4.0f, result, 0.0f);
    }

    @Test
    public void fHalvesNegativeInput() {
        // Arrange
        CoverageMetrics metrics = new CoverageMetrics();

        // Act
        float result = metrics.f(-6);

        // Assert
        assertEquals(-3.0f, result, 0.0f);
    }
}
