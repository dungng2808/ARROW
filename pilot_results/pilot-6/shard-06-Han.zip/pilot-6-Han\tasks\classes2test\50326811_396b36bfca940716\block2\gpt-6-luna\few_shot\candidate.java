package net.md_5.bungee.api.chat;

import java.util.Arrays;
import java.util.Collections;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;

public class TranslatableComponent_ArrowTest
{
    @Test
    public void constructorCreatesTextSubstitutionsAndRendersUnknownTranslation()
    {
        TranslatableComponent component = new TranslatableComponent( "custom.key", "Alice", "Bob" );

        assertEquals( "custom.key", component.getTranslate() );
        assertEquals( 2, component.getWith().size() );
        assertEquals( "Alice", component.getWith().get( 0 ).toPlainText() );
        assertEquals( "Bob", component.getWith().get( 1 ).toPlainText() );
        assertEquals( "custom.key", component.toPlainText() );
    }

    @Test
    public void rendersSequentialAndIndexedSubstitutions()
    {
        TranslatableComponent sequential = new TranslatableComponent( "custom %s and %d", "one", "two" );
        TranslatableComponent indexed = new TranslatableComponent( "custom %2$s then %1$s", "one", "two" );

        assertEquals( "custom one and two", sequential.toPlainText() );
        assertEquals( "custom two then one", indexed.toPlainText() );
    }

    @Test
    public void rendersEscapedPercentAndLeavesUnsupportedFormatCodes()
    {
        TranslatableComponent component = new TranslatableComponent( "rate %% %q", "unused" );

        assertEquals( "rate % %q", component.toPlainText() );
    }

    @Test
    public void addWithSetsParentAndDuplicateCopiesSubstitutions()
    {
        TranslatableComponent original = new TranslatableComponent( "custom %s" );
        TextComponent substitution = new TextComponent( "value" );
        original.addWith( substitution );

        TranslatableComponent duplicate = (TranslatableComponent) original.duplicate();

        assertSame( original, substitution.getParent() );
        assertEquals( "custom value", duplicate.toPlainText() );
        assertNotSame( substitution, duplicate.getWith().get( 0 ) );
        assertEquals( "value", duplicate.getWith().get( 0 ).toPlainText() );
    }

    @Test
    public void setWithReplacesExistingSubstitutions()
    {
        TranslatableComponent component = new TranslatableComponent( "custom %s" );
        component.addWith( "old" );
        TextComponent replacement = new TextComponent( "new" );

        component.setWith( Arrays.<BaseComponent>asList( replacement ) );

        assertSame( component, replacement.getParent() );
        assertEquals( "custom new", component.toPlainText() );
    }

    @Test
    public void duplicatePreservesNullSubstitutions()
    {
        TranslatableComponent original = new TranslatableComponent();
        original.setTranslate( "plain text" );
        original.setWith( Collections.<BaseComponent>emptyList() );

        TranslatableComponent duplicate = (TranslatableComponent) original.duplicate();

        assertEquals( "plain text", duplicate.toPlainText() );
        assertEquals( 0, duplicate.getWith().size() );
    }
}
