package coverage_metrics;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CoverageMetrics_ArrowTest {

  @Test
  public void fReturnsZeroForZeroInput() {
    CoverageMetrics metrics = new CoverageMetrics();

    float result = metrics.f(0);

    assertEquals(0.0f, result, 0.0f);
  }

  @Test
  public void fReturnsHalfForNonzeroInput() {
    CoverageMetrics metrics = new CoverageMetrics();

    float result = metrics.f(2);

    assertEquals(1.0f, result, 0.0f);
  }

  @Test
  public void fPreservesNegativeNonzeroInput() {
    CoverageMetrics metrics = new CoverageMetrics();

    float result = metrics.f(-3);

    assertEquals(-1.5f, result, 0.0f);
  }
}
