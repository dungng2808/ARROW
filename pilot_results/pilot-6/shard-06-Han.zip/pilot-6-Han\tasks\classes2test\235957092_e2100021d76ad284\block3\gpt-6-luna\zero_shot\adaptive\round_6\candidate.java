package edu.berkeley.cs.jqf.fuzz.rl;

import org.json.JSONException;
import org.junit.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class RLParamParser_ArrowTest {

    @Test
    public void parsesSupportedScalarAndArrayTypes() {
        RLParamParser parser = new RLParamParser();
        String json = "{\"params\":["
                + "{\"name\":\"text\",\"type\":\"string\",\"val\":\"hello\"},"
                + "{\"name\":\"enabled\",\"type\":\"bool\",\"val\":true},"
                + "{\"name\":\"large\",\"type\":\"long\",\"val\":1234567890123},"
                + "{\"name\":\"count\",\"type\":\"int\",\"val\":42},"
                + "{\"name\":\"ratio\",\"type\":\"double\",\"val\":2.5},"
                + "{\"name\":\"words\",\"type\":\"string_array\",\"val\":[\"a\",\"b\"]},"
                + "{\"name\":\"flags\",\"type\":\"bool_array\",\"val\":[true,false]},"
                + "{\"name\":\"numbers\",\"type\":\"int_array\",\"val\":[1,2,3]},"
                + "{\"name\":\"ratios\",\"type\":\"double_array\",\"val\":[1.25,2.5]}"
                + "]}";

        RLParams params = parser.getParams(json);

        assertEquals("hello", params.get("text"));
        assertEquals(Boolean.TRUE, params.get("enabled"));
        assertEquals(Long.valueOf(1234567890123L), params.get("large"));
        assertEquals(Integer.valueOf(42), params.get("count"));
        assertEquals(Double.valueOf(2.5), params.get("ratio"));
        assertEquals(Arrays.asList("a", "b"), params.get("words"));
        assertEquals(Arrays.asList(true, false), params.get("flags"));
        assertEquals(Arrays.asList(1, 2, 3), params.get("numbers"));
        assertEquals(Arrays.asList(1.25, 2.5), params.get("ratios"));
    }

    @Test
    public void parsesEmptyParamsArray() {
        RLParams params = new RLParamParser().getParams("{\"params\":[]}");

        assertFalse(params.exists("missing"));
    }

    @Test
    public void rejectsJsonWithoutParamsRoot() {
        try {
            new RLParamParser().getParams("{\"other\":[]}");
        } catch (JSONException expected) {
            assertEquals("Object needs to have params as root", expected.getMessage());
            return;
        }
        throw new AssertionError("Expected a JSONException when params is absent");
    }

    @Test
    public void readsParamsFromFile() throws IOException {
        Path file = Files.createTempFile("rl-params", ".json");
        try {
            Files.write(file, "{\"params\":[{\"name\":\"count\",\"type\":\"int\",\"val\":7}]}"
                    .getBytes(StandardCharsets.UTF_8));

            RLParams params = new RLParamParser().getParamsFile(file.toString());

            assertEquals(Integer.valueOf(7), params.get("count"));
        } finally {
            Files.deleteIfExists(file);
        }
    }
}
