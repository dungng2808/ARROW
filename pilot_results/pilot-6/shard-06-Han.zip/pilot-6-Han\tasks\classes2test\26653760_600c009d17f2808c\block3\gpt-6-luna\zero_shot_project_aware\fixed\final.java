package be.drissamri.service.verifier;

import be.drissamri.config.safebrowsing.phishtank.PhishTankConfig;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PhishTankUrlVerifier_ArrowTest {

    private static final String API_URL = "https://phishtank.example/check";

    private PhishTankConfig configuredConfig() {
        PhishTankConfig config = mock(PhishTankConfig.class);
        when(config.getParameters()).thenReturn(new LinkedMultiValueMap<String, String>());
        when(config.getApiUrl()).thenReturn(API_URL);
        return config;
    }

    @Test
    public void isSafeReturnsFalseWhenPhishTankReportsUrlInDatabase() {
        RestTemplate client = mock(RestTemplate.class);
        PhishTankConfig config = configuredConfig();
        when(client.postForEntity(eq(API_URL), any(MultiValueMap.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(
                        "{\"results\":{\"in_database\":true}}", HttpStatus.OK));

        PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

        assertFalse(verifier.isSafe("http://malicious.example"));
    }

    @Test
    public void isSafeReturnsTrueWhenPhishTankReportsUrlNotInDatabase() {
        RestTemplate client = mock(RestTemplate.class);
        PhishTankConfig config = configuredConfig();
        when(client.postForEntity(eq(API_URL), any(MultiValueMap.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(
                        "{\"results\":{\"in_database\":false}}", HttpStatus.OK));

        PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

        assertTrue(verifier.isSafe("http://safe.example"));
    }

    @Test
    public void isSafeReturnsTrueWhenApiRespondsWithNonOkStatus() {
        RestTemplate client = mock(RestTemplate.class);
        PhishTankConfig config = configuredConfig();
        when(client.postForEntity(eq(API_URL), any(MultiValueMap.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>("unavailable", HttpStatus.SERVICE_UNAVAILABLE));

        PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

        assertTrue(verifier.isSafe("http://safe.example"));
    }

    @Test
    public void canValidateReflectsConfigurationState() {
        RestTemplate client = mock(RestTemplate.class);
        PhishTankConfig config = new PhishTankConfig();
        PhishTankUrlVerifier verifier = new PhishTankUrlVerifier(client, config);

        assertFalse(verifier.canValidate());
    }
}
