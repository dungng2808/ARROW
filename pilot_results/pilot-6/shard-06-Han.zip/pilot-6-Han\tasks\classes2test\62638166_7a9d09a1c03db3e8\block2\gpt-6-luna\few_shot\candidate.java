package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.api.Grammar;
import com.sonar.sslr.impl.Parser;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import org.junit.Test;

public class FlowParser_ArrowTest {

    @Test
    public void parseStringParsesFlowSource() {
        Parser<Grammar> parser = FlowParser.create();
        AstNode astNode = parser.parse("");

        assertNotNull(astNode);
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String missingPath = new File(
                System.getProperty("java.io.tmpdir"),
                "flow-parser-missing-" + System.nanoTime()).getAbsolutePath();

        AssertionError error = assertThrows(
                AssertionError.class,
                () -> FlowParser.parseFile(missingPath));

        org.junit.Assert.assertEquals(
                "The file \"" + missingPath + "\" does not exist.",
                error.getMessage());
    }

    @Test
    public void parseFileParsesExistingFile() throws Exception {
        File file = File.createTempFile("flow-parser-", ".flow");
        try {
            Files.write(file.toPath(), new byte[0]);

            FlowParser.create(new FlowConfiguration(Charset.defaultCharset()));
            AstNode astNode = FlowParser.parseFile(file.getAbsolutePath());

            assertNotNull(astNode);
        } finally {
            Files.deleteIfExists(file.toPath());
        }
    }
}
