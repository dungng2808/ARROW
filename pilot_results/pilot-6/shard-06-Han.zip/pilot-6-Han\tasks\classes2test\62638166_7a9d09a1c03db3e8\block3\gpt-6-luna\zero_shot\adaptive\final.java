package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.impl.Parser;
import org.junit.Test;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class FlowParser_ArrowTest {

    @Test
    public void createWithoutConfigurationBuildsParser() {
        Parser<?> parser = FlowParser.create();

        assertNotNull(parser);
    }

    @Test
    public void createWithConfigurationBuildsParser() {
        Parser<?> parser = FlowParser.create(new FlowConfiguration(Charset.defaultCharset()));

        assertNotNull(parser);
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String missingPath = new File(System.getProperty("java.io.tmpdir"),
                "flow-parser-missing-" + System.nanoTime()).getAbsolutePath();

        try {
            FlowParser.parseFile(missingPath);
            fail("Expected an AssertionError for a missing file");
        } catch (AssertionError expected) {
            assertTrue(expected.getMessage().contains(missingPath));
        }
    }

    @Test
    public void parseFileRejectsMalformedXml() throws Exception {
        File file = File.createTempFile("flow-parser-", ".flow");
        try {
            Files.write(file.toPath(), "not xml".getBytes(Charset.defaultCharset()));

            try {
                FlowParser.parseFile(file.getAbsolutePath());
                fail("Expected malformed XML to be rejected");
            } catch (Error expected) {
                assertNotNull(expected.getCause());
            }
        } finally {
            Files.deleteIfExists(file.toPath());
        }
    }

    @Test
    public void parseStringRejectsMalformedXml() {
        try {
            FlowParser.parseString("not xml");
            fail("Expected malformed XML to be rejected");
        } catch (Error expected) {
            assertNotNull(expected.getCause());
        }
    }
}
