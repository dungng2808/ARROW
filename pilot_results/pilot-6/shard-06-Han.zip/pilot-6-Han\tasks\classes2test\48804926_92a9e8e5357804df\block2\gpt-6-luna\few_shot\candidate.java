package edu.jhuapl.dorset;

import static org.junit.Assert.assertSame;

import edu.jhuapl.dorset.agents.Agent;
import edu.jhuapl.dorset.routing.Router;
import java.lang.reflect.Proxy;
import org.junit.Test;

public class Application_ArrowTest {

    @Test
    public void getAgentsReturnsAgentsProvidedByRouter() {
        Agent[] expectedAgents = new Agent[0];
        Router router = (Router) Proxy.newProxyInstance(
                Router.class.getClassLoader(),
                new Class<?>[] {Router.class},
                (proxy, method, args) ->
                        "getAgents".equals(method.getName()) ? expectedAgents : null);

        Application application = new Application(router);

        assertSame(expectedAgents, application.getAgents());
    }
}
