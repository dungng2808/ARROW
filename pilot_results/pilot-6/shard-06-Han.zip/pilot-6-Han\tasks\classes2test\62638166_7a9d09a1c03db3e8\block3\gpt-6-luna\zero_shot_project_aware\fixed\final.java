package be.i8c.codequality.sonar.plugins.sag.webmethods.flow.sslr;

import com.sonar.sslr.api.Grammar;
import com.sonar.sslr.impl.Parser;
import org.junit.Test;

import java.io.File;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class FlowParser_ArrowTest {

    @Test
    public void createWithConfigurationReturnsParser() {
        FlowConfiguration configuration = new FlowConfiguration(java.nio.charset.Charset.defaultCharset());

        Parser<Grammar> parser = FlowParser.create(configuration);

        assertNotNull(parser);
    }

    @Test
    public void createWithoutConfigurationReturnsParser() {
        Parser<Grammar> parser = FlowParser.create();

        assertNotNull(parser);
    }

    @Test
    public void parseStringRejectsMalformedXml() {
        try {
            FlowParser.parseString("<flow>");
            fail("Expected malformed XML to be rejected.");
        } catch (Error expected) {
            assertNotNull(expected.getMessage());
        }
    }

    @Test
    public void parseFileRejectsMissingFile() {
        String missingPath = new File(System.getProperty("java.io.tmpdir"),
                "flow-parser-missing-" + System.nanoTime()).getAbsolutePath();

        try {
            FlowParser.parseFile(missingPath);
            fail("Expected an AssertionError for a missing file.");
        } catch (AssertionError expected) {
            assertTrue(expected.getMessage().contains(missingPath));
        }
    }
}
