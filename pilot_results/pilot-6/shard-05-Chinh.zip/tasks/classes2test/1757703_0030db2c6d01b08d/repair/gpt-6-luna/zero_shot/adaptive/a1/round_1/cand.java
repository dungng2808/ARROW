package net.ontopia.presto.spi.utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.*;

public class Utils_ArrowTest {

    @Test
    public void equalityHelpersHandleNullsAndValues() {
        assertTrue(Utils.equals(null, null));
        assertTrue(Utils.equals("value", "value"));
        assertFalse(Utils.equals(null, "value"));
        assertFalse(Utils.equals("value", null));
        assertFalse(Utils.equals("left", "right"));

        assertFalse(Utils.different(null, null));
        assertFalse(Utils.different("value", "value"));
        assertTrue(Utils.different(null, "value"));
        assertTrue(Utils.different("left", "right"));
    }

    @Test
    public void compareComparablesHandlesNullsOrderingAndComparator() {
        assertEquals(0, Utils.compareComparables(null, null));
        assertTrue(Utils.compareComparables(null, "a") < 0);
        assertTrue(Utils.compareComparables("a", null) > 0);
        assertTrue(Utils.compareComparables("a", "b") < 0);
        assertTrue(Utils.compareComparables("b", "a") > 0);

        assertTrue(Utils.compareComparables("a", "b", true) < 0);
        assertTrue(Utils.compareComparables("a", "b", false) > 0);
        assertEquals(0, Utils.compareComparables(null, null, false));

        assertTrue(Utils.compareComparables("a", "B", String.CASE_INSENSITIVE_ORDER) < 0);
        assertTrue(Utils.compareComparables(null, "B", String.CASE_INSENSITIVE_ORDER) < 0);
        assertTrue(Utils.compareComparables("B", null, String.CASE_INSENSITIVE_ORDER) > 0);
    }

    @Test
    public void validateNotNullAcceptsValuesAndRejectsNull() {
        Utils.validateNotNull("value");
        try {
            Utils.validateNotNull(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException exception) {
            assertEquals("Object cannot be null", exception.getMessage());
        }
    }

    @Test
    public void getNameFallsBackToStringAndNullText() {
        assertEquals("value", Utils.getName("value"));
        assertEquals("null", Utils.getName((Object) null));
        assertEquals("value", Utils.getName(null, "value"));
        assertEquals("null", Utils.getName(null, null));
    }

    @Test
    public void moveValuesToIndexMovesExistingValuesAndPreservesInput() {
        List<String> values = Arrays.asList("a", "b", "c", "d");
        List<String> result = Utils.moveValuesToIndex(values, Arrays.asList("b", "d"), 3, false);

        assertEquals(Arrays.asList("a", "c", "b", "d"), result);
        assertEquals(Arrays.asList("a", "b", "c", "d"), values);
        assertNotSame(values, result);
    }

    @Test
    public void moveValuesToIndexSupportsInsertionAndEmptyMoves() {
        List<String> values = Arrays.asList("a", "b", "c");

        assertEquals(Arrays.asList("a", "x", "b", "c"),
                Utils.moveValuesToIndex(values, Collections.singletonList("x"), 1, true));
        assertEquals(values, Utils.moveValuesToIndex(values, Collections.<String>emptyList(), 1, false));
    }

    @Test
    public void moveValuesToIndexRejectsMissingValuesWhenAddingIsDisallowed() {
        try {
            Utils.moveValuesToIndex(Arrays.asList("a", "b"),
                    Collections.singletonList("x"), 1, false);
            fail("Expected RuntimeException");
        } catch (RuntimeException exception) {
            assertEquals("Not allowed to add new values: x", exception.getMessage());
        }
    }

    @Test
    public void moveValuesToIndexRejectsIndexBeyondSize() {
        try {
            Utils.moveValuesToIndex(Arrays.asList("a", "b"),
                    Collections.<String>emptyList(), 3, true);
            fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException exception) {
            assertEquals("Index: 3, Size: 2", exception.getMessage());
        }
    }

    @Test
    public void newInstanceOfCreatesAssignableClassAndRejectsInvalidClasses() {
        String value = Utils.newInstanceOf(String.class.getName(), String.class);
        assertEquals("", value);

        try {
            Utils.newInstanceOf("no.such.TestClass", Object.class);
            fail("Expected RuntimeException");
        } catch (RuntimeException exception) {
            assertEquals("Class no.such.TestClass not found.", exception.getMessage());
        }

        try {
            Utils.newInstanceOf(String.class.getName(), Number.class);
            fail("Expected RuntimeException");
        } catch (RuntimeException exception) {
            assertTrue(exception.getMessage().contains("not assignable"));
        }
    }
}
