package net.ontopia.presto.spi.utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

class Utils_ArrowTest {

    @Test
    void equalityHelpersHandleNullsAndValues() {
        assertTrue(Utils.equals(null, null));
        assertTrue(Utils.equals("value", "value"));
        assertFalse(Utils.equals(null, "value"));
        assertFalse(Utils.equals("value", null));
        assertFalse(Utils.equals("left", "right"));

        assertFalse(Utils.different(null, null));
        assertFalse(Utils.different("value", "value"));
        assertTrue(Utils.different(null, "value"));
        assertTrue(Utils.different("left", "right"));
    }

    @Test
    void compareComparablesHandlesNullsOrderingAndComparator() {
        assertEquals(0, Utils.compareComparables(null, null));
        assertTrue(Utils.compareComparables(null, "a") < 0);
        assertTrue(Utils.compareComparables("a", null) > 0);
        assertTrue(Utils.compareComparables("a", "b") < 0);
        assertTrue(Utils.compareComparables("b", "a") > 0);

        assertTrue(Utils.compareComparables("a", "b", true) < 0);
        assertTrue(Utils.compareComparables("a", "b", false) > 0);
        assertEquals(0, Utils.compareComparables(null, null, false));

        assertTrue(Utils.compareComparables("a", "B", String.CASE_INSENSITIVE_ORDER) < 0);
        assertTrue(Utils.compareComparables(null, "B", String.CASE_INSENSITIVE_ORDER) < 0);
        assertTrue(Utils.compareComparables("B", null, String.CASE_INSENSITIVE_ORDER) > 0);
    }

    @Test
    void validateNotNullAcceptsValuesAndRejectsNull() {
        Utils.validateNotNull("value");
        NullPointerException exception =
                assertThrows(NullPointerException.class, () -> Utils.validateNotNull(null));
        assertEquals("Object cannot be null", exception.getMessage());
    }

    @Test
    void getNameFallsBackToStringAndNullText() {
        assertEquals("value", Utils.getName("value"));
        assertEquals("null", Utils.getName((Object) null));
        assertEquals("value", Utils.getName(null, "value"));
        assertEquals("null", Utils.getName(null, null));
    }

    @Test
    void moveValuesToIndexMovesExistingValuesAndPreservesInput() {
        List<String> values = Arrays.asList("a", "b", "c", "d");
        List<String> result = Utils.moveValuesToIndex(values, Arrays.asList("b", "d"), 3, false);

        assertEquals(Arrays.asList("a", "c", "b", "d"), result);
        assertEquals(Arrays.asList("a", "b", "c", "d"), values);
        assertNotSame(values, result);
    }

    @Test
    void moveValuesToIndexSupportsInsertionAndEmptyMoves() {
        List<String> values = Arrays.asList("a", "b", "c");

        assertEquals(Arrays.asList("a", "x", "b", "c"),
                Utils.moveValuesToIndex(values, Collections.singletonList("x"), 1, true));
        assertEquals(values, Utils.moveValuesToIndex(values, Collections.emptyList(), 1, false));
    }

    @Test
    void moveValuesToIndexRejectsMissingValuesWhenAddingIsDisallowed() {
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> Utils.moveValuesToIndex(Arrays.asList("a", "b"),
                        Collections.singletonList("x"), 1, false));
        assertEquals("Not allowed to add new values: x", exception.getMessage());
    }

    @Test
    void moveValuesToIndexRejectsIndexBeyondSize() {
        ArrayIndexOutOfBoundsException exception = assertThrows(ArrayIndexOutOfBoundsException.class,
                () -> Utils.moveValuesToIndex(Arrays.asList("a", "b"),
                        Collections.emptyList(), 3, true));
        assertEquals("Index: 3, Size: 2", exception.getMessage());
    }

    @Test
    void newInstanceOfCreatesAssignableClassAndRejectsInvalidClasses() {
        String value = Utils.newInstanceOf(String.class.getName(), String.class);
        assertEquals("", value);

        RuntimeException notFound = assertThrows(RuntimeException.class,
                () -> Utils.newInstanceOf("no.such.TestClass", Object.class));
        assertEquals("Class no.such.TestClass not found.", notFound.getMessage());

        RuntimeException wrongType = assertThrows(RuntimeException.class,
                () -> Utils.newInstanceOf(String.class.getName(), Number.class));
        assertTrue(wrongType.getMessage().contains("not assignable"));
    }
}
