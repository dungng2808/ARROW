package com.intuit.karate.core;

import com.intuit.karate.graal.JsEngine;
import com.intuit.karate.graal.JsValue;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Tags_ArrowTest {

    private static Tag tag(String text) {
        return new Tag(0, text);
    }

    private static Tags tags(String... texts) {
        List<Tag> list = new ArrayList<>();
        for (String text : texts) {
            list.add(tag(text));
        }
        return new Tags(list);
    }

    @Test
    void emptyTagsAndNullInput() {
        // A null collection leaves tagValues uninitialized in Tags, so use an
        // empty collection when exercising methods that access that map.
        Tags empty = new Tags(Collections.emptyList());
        assertTrue(empty.getTags().isEmpty());
        assertTrue(empty.getTagKeys().isEmpty());
        assertTrue(empty.getOriginal().isEmpty());
        assertFalse(empty.contains("@anything"));
        assertTrue(empty.evaluate(null, null));
        assertFalse(empty.evaluate("anyOf('@anything')", null));
        assertEquals("[]", empty.toString());

        // Null input is supported for the basic collection accessors.
        Tags nullInput = new Tags(null);
        assertTrue(nullInput.getTags().isEmpty());
        assertTrue(nullInput.getOriginal().isEmpty());
        assertEquals("[]", nullInput.toString());
    }

    @Test
    void tagLookupAndPrefixHandling() {
        Tags tags = tags("@smoke", "@color=red,blue", "@fast");

        assertTrue(tags.contains("@smoke"));
        assertTrue(tags.contains("smoke"));
        assertFalse(tags.contains("@missing"));
        assertTrue(tags.anyOf("@smoke", "missing"));
        assertTrue(tags.allOf("@smoke", "fast"));
        assertFalse(tags.allOf("@smoke", "missing"));
        assertFalse(tags.not("@fast"));
        assertTrue(tags.not("@missing"));
        assertEquals(Arrays.asList("smoke", "color=red,blue", "fast"), tags.getTags());
        assertEquals(3, tags.getTagKeys().size());
        assertEquals(3, tags.getOriginal().size());
    }

    @Test
    void valuesForAndValuesPredicates() {
        Tags tags = tags("@color=red,blue", "@mode=quick");

        Tags.Values colors = tags.valuesFor("@color");
        assertTrue(colors.isPresent());
        assertTrue(colors.isAnyOf("red", "green"));
        assertTrue(colors.isAllOf("red", "blue"));
        assertTrue(colors.isOnly("red", "blue"));
        assertFalse(colors.isOnly("red"));
        assertFalse(colors.isAnyOf("green"));

        Tags.Values absent = tags.valuesFor("missing");
        assertFalse(absent.isPresent());
        assertFalse(absent.isAnyOf("anything"));
        assertTrue(absent.isAllOf());
        assertTrue(absent.isOnly());

        assertEquals(Arrays.asList("red", "blue"), tags.getTagValues().get("color"));
    }

    @Test
    void evaluateSelectorsAndEnvironmentTags() {
        Tags tags = tags("@smoke", "@color=red,blue");

        assertTrue(tags.evaluate(null, null));
        assertTrue(tags.evaluate("anyOf('@smoke')", null));
        assertTrue(tags.evaluate("allOf('smoke', '@color=red,blue')", null));
        assertFalse(tags.evaluate("not('@smoke')", null));
        assertTrue(tags.evaluate("valuesFor('color').isAnyOf('blue')", null));

        Tags env = tags("@env=dev,qa", "@envnot=prod");
        assertFalse(env.evaluate(null, null));
        assertTrue(env.evaluate(null, "dev"));
        assertFalse(env.evaluate(null, "prod"));
        assertFalse(env.evaluate(null, "stage"));
    }

    @Test
    void ignoreAndSetupTagsPreventEvaluation() {
        assertFalse(tags("@ignore", "@smoke").evaluate(null, null));
        assertFalse(tags("@setup", "@smoke").evaluate(null, null));
    }

    @Test
    void mergeDeduplicatesAndIgnoresNullLists() {
        Tag smoke = tag("@smoke");
        Tag fast = tag("@fast");

        Tags merged = Tags.merge(Arrays.asList(smoke, fast), null, Collections.singletonList(smoke));

        assertEquals(2, merged.getTags().size());
        assertTrue(merged.contains("@smoke"));
        assertTrue(merged.contains("@fast"));
    }

    @Test
    void optionTagsConvertToExpressions() {
        assertNull(Tags.fromKarateOptionsTags((List<String>) null));
        assertNull(Tags.fromKarateOptionsTags(Collections.emptyList()));
        assertNull(Tags.fromKarateOptionsTags(new String[0]));

        assertEquals("anyOf('a','b') && not('c')",
                Tags.fromKarateOptionsTags("a, b", "~c"));
        assertEquals("anyOf('a')", Tags.fromKarateOptionsTags(Arrays.asList("a")));
        assertEquals("valuesFor('x').isPresent()",
                Tags.fromKarateOptionsTags("valuesFor('x').isPresent()"));
    }

    @Test
    void valuesEachExecutesPredicateForEveryValue() {
        Tags.Values values = new Tags.Values(Arrays.asList("one", "two"));
        JsValue predicate = JsEngine.global().eval("(s) => s.length > 0");
        assertTrue(values.isEach((org.graalvm.polyglot.Value) predicate.getOriginal()));

        JsValue falsePredicate = JsEngine.global().eval("(s) => s != 'two'");
        assertFalse(values.isEach((org.graalvm.polyglot.Value) falsePredicate.getOriginal()));

        JsValue nonFunction = JsEngine.global().eval("1");
        assertFalse(values.isEach((org.graalvm.polyglot.Value) nonFunction.getOriginal()));
    }
}
