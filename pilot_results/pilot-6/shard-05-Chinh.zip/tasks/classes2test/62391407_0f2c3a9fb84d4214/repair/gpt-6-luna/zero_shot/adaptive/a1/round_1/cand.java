package com.howtoprogram.repository.feign.auth;

import java.lang.reflect.Field;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class RequestReponseService_ArrowTest {

    @Test
    public void exposesExpectedBasicAuthenticationCredentials() {
        assertEquals("user", RequestReponseService.USERNAME);
        assertEquals("passwd", RequestReponseService.PASSWORD);
    }

    @Test
    public void buildsFeignClientWithBasicAuthenticationAndReturnsDecodedStatus() throws Exception {
        AuthStatus expected = new AuthStatus();
        Field usernameField = findField(AuthStatus.class, "user");
        Field authenticatedField = findField(AuthStatus.class, "authenticated");
        usernameField.setAccessible(true);
        authenticatedField.setAccessible(true);
        usernameField.set(expected, RequestReponseService.USERNAME);
        authenticatedField.set(expected, true);

        RequestReponseService service = new RequestReponseService();
        AuthStatus actual = service.getAuthenticatedUser();

        assertNotNull(actual);
        assertEquals(usernameField.get(expected), usernameField.get(actual));
        assertEquals(authenticatedField.get(expected), authenticatedField.get(actual));
    }

    private static Field findField(Class<?> type, String name) throws NoSuchFieldException {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                // Continue searching superclasses.
            }
        }
        throw new NoSuchFieldException(name);
    }
}
