package com.howtoprogram.repository.feign.auth;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class RequestReponseService_ArrowTest {

    @Test
    public void getAuthenticatedUserReturnsAStatus() {
        AuthStatus status = new RequestReponseService().getAuthenticatedUser();

        assertNotNull(status);
    }
}
