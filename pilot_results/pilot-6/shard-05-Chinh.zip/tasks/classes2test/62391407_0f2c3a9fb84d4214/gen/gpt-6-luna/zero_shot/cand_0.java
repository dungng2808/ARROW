package com.howtoprogram.repository.feign.auth;

import feign.Feign;
import feign.Request;
import feign.Response;
import feign.auth.BasicAuthRequestInterceptor;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;

import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

class RequestReponseService_ArrowTest {

    @Test
    void exposesExpectedBasicAuthenticationCredentials() {
        assertEquals("user", RequestReponseService.USERNAME);
        assertEquals("passwd", RequestReponseService.PASSWORD);
    }

    @Test
    void buildsFeignClientWithBasicAuthenticationAndReturnsDecodedStatus() throws Exception {
        AuthStatus expected = new AuthStatus();
        Field usernameField = findField(AuthStatus.class, "user");
        Field authenticatedField = findField(AuthStatus.class, "authenticated");
        usernameField.setAccessible(true);
        authenticatedField.setAccessible(true);
        usernameField.set(expected, RequestReponseService.USERNAME);
        authenticatedField.set(expected, true);

        RequestReponseService service = new RequestReponseService();
        AuthStatus actual = service.getAuthenticatedUser();

        assertNotNull(actual);
        assertEquals(usernameField.get(expected), usernameField.get(actual));
        assertEquals(authenticatedField.get(expected), authenticatedField.get(actual));
    }

    private static Field findField(Class<?> type, String name) throws NoSuchFieldException {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                // Continue searching superclasses.
            }
        }
        throw new NoSuchFieldException(name);
    }
}
