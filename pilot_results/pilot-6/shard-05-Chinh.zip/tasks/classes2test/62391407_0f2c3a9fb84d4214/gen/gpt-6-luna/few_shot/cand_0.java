package com.howtoprogram.repository.feign.auth;

import org.junit.Test;
import static org.junit.Assert.*;

class RequestReponseService_ArrowTest {

    @Test
    void getAuthenticatedUserReturnsResult() {
        AuthStatus result = new RequestReponseService().getAuthenticatedUser();
        assertNotNull(result);
    }
}
