package org.openape.api.databaseObjectBase;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

class Property_ArrowTest {

    @Test
    void defaultConstructorInitializesEmptyDescriptorsAndNullFields() {
        Property property = new Property();

        assertNull(property.getName());
        assertNull(property.getValue());
        assertNotNull(property.getDescriptors());
        assertTrue(property.getDescriptors().isEmpty());
    }

    @Test
    void constructorsPreserveNameAndValueTypes() {
        Property stringProperty = new Property("text", "value");
        Property booleanProperty = new Property("enabled", true);
        Property integerProperty = new Property("count", 7);
        Property doubleProperty = new Property("ratio", 2.5);

        assertEquals("text", stringProperty.getName());
        assertEquals("value", stringProperty.getValue());
        assertEquals("value", stringProperty.getValueAsString());

        assertEquals("enabled", booleanProperty.getName());
        assertEquals(Boolean.TRUE, booleanProperty.getValue());

        assertEquals("count", integerProperty.getName());
        assertEquals(Integer.valueOf(7), integerProperty.getValue());

        assertEquals("ratio", doubleProperty.getName());
        assertEquals(Double.valueOf(2.5), doubleProperty.getValue());
    }

    @Test
    void settersUpdateNameAndValue() {
        Property property = new Property();

        property.setName("updated");
        property.setValue("string");
        assertEquals("updated", property.getName());
        assertEquals("string", property.getValue());
        assertEquals("string", property.getValueAsString());

        property.setValue(true);
        assertEquals(Boolean.TRUE, property.getValue());

        property.setValue(3.25);
        assertEquals(Double.valueOf(3.25), property.getValue());

        property.setValue(12);
        assertEquals(Integer.valueOf(12), property.getValue());

        property.setValueAsString("as-string");
        assertEquals("as-string", property.getValue());
        assertEquals("as-string", property.getValueAsString());
    }

    @Test
    void descriptorsCanBeAddedAndReplaced() {
        Property property = new Property("name", "value");
        Descriptor descriptor = new Descriptor();

        property.addDescriptor(descriptor);
        assertEquals(1, property.getDescriptors().size());
        assertSame(descriptor, property.getDescriptors().get(0));

        List<Descriptor> replacement = new ArrayList<>();
        Descriptor replacementDescriptor = new Descriptor();
        replacement.add(replacementDescriptor);
        property.setDescriptors(replacement);

        assertSame(replacement, property.getDescriptors());
        assertSame(replacementDescriptor, property.getDescriptors().get(0));
    }

    @Test
    void equalsComparesNameValueAndDescriptors() {
        Property first = new Property("key", "value");
        Property second = new Property("key", "value");

        assertEquals(first, second);
        assertEquals(second, first);

        first.setName("different");
        assertNotEquals(first, second);

        first.setName("key");
        first.setValue("different");
        assertNotEquals(first, second);
    }

    @Test
    void equalsHandlesNullAndOtherTypes() {
        Property property = new Property("key", "value");

        assertNotEquals(property, null);
        assertNotEquals(property, "key");
    }

    @Test
    void equalsReturnsFalseWhenEitherComparedPropertyHasNullAttributes() {
        Property initialized = new Property("key", "value");
        Property nullName = new Property();
        nullName.setValue("value");
        Property nullValue = new Property();
        nullValue.setName("key");

        assertNotEquals(initialized, nullName);
        assertNotEquals(initialized, nullValue);
        assertNotEquals(nullName, initialized);
        assertNotEquals(nullValue, initialized);
    }

    @Test
    void equalsComparesDescriptorNamesAndValues() {
        Property first = new Property("key", "value");
        Property second = new Property("key", "value");

        first.addDescriptor(new Descriptor("color", "blue"));
        second.addDescriptor(new Descriptor("color", "blue"));
        assertEquals(first, second);

        second.getDescriptors().clear();
        second.addDescriptor(new Descriptor("color", "red"));
        assertNotEquals(first, second);

        second.getDescriptors().clear();
        second.addDescriptor(new Descriptor("size", "blue"));
        assertNotEquals(first, second);
    }

    @Test
    void equalsRequiresMatchingDescriptorCounts() {
        Property first = new Property("key", "value");
        Property second = new Property("key", "value");

        first.addDescriptor(new Descriptor("a", "1"));
        second.addDescriptor(new Descriptor("a", "1"));
        second.addDescriptor(new Descriptor("b", "2"));

        assertNotEquals(first, second);
    }
}
