package org.openape.api.databaseObjectBase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.junit.Test;

public class Property_ArrowTest {

    @Test
    public void defaultConstructorInitializesEmptyDescriptors() {
        Property property = new Property();

        assertEquals(null, property.getName());
        assertEquals(null, property.getValue());
        assertTrue(property.getDescriptors().isEmpty());
    }

    @Test
    public void constructorsAndSettersPreserveValuesAndTypes() {
        Property stringProperty = new Property("string", "value");
        assertEquals("string", stringProperty.getName());
        assertEquals("value", stringProperty.getValue());
        assertEquals("value", stringProperty.getValueAsString());

        Property booleanProperty = new Property("boolean", true);
        assertEquals(Boolean.TRUE, booleanProperty.getValue());
        booleanProperty.setValue(false);
        assertEquals(Boolean.FALSE, booleanProperty.getValue());

        Property intProperty = new Property("integer", 42);
        assertEquals(Integer.valueOf(42), intProperty.getValue());
        intProperty.setValue(7);
        assertEquals(Integer.valueOf(7), intProperty.getValue());

        Property doubleProperty = new Property("double", 2.5);
        assertEquals(Double.valueOf(2.5), doubleProperty.getValue());
        doubleProperty.setValue(3.5);
        assertEquals(Double.valueOf(3.5), doubleProperty.getValue());

        stringProperty.setName("renamed");
        stringProperty.setValueAsString("updated");
        assertEquals("renamed", stringProperty.getName());
        assertEquals("updated", stringProperty.getValue());
        assertEquals("updated", stringProperty.getValueAsString());
    }

    @Test
    public void descriptorsCanBeAddedAndReplaced() {
        Property property = new Property("key", "value");
        Descriptor descriptor = new Descriptor("language", "en");

        property.addDescriptor(descriptor);
        assertEquals(Collections.singletonList(descriptor), property.getDescriptors());

        ArrayList<Descriptor> replacement = new ArrayList<Descriptor>();
        Descriptor other = new Descriptor("region", "west");
        replacement.add(other);
        property.setDescriptors(replacement);

        assertSame(replacement, property.getDescriptors());
        assertEquals(Collections.singletonList(other), property.getDescriptors());
    }

    @Test
    public void equalsComparesNameValueAndDescriptorsRegardlessOfDescriptorOrder() {
        Property first = new Property("key", "value");
        first.addDescriptor(new Descriptor("language", "en"));
        first.addDescriptor(new Descriptor("region", "west"));

        Property second = new Property("key", "value");
        second.addDescriptor(new Descriptor("region", "west"));
        second.addDescriptor(new Descriptor("language", "en"));

        assertTrue(first.equals(second));
        assertTrue(second.equals(first));
    }

    @Test
    public void equalsRejectsDifferentNamesValuesOrDescriptors() {
        Property base = new Property("key", "value");
        base.addDescriptor(new Descriptor("language", "en"));

        assertFalse(base.equals(new Property("other", "value")));
        assertFalse(base.equals(new Property("key", "other")));
        assertFalse(base.equals(new Property("key", "value")));
        assertFalse(base.equals(null));
        assertFalse(base.equals("not a property"));
    }

    @Test
    public void equalsHandlesNullFieldsAndEmptyDescriptors() {
        Property emptyOne = new Property();
        Property emptyTwo = new Property();
        assertFalse(emptyOne.equals(emptyTwo));

        Property first = new Property("key", "value");
        Property second = new Property("key", "value");
        assertTrue(first.equals(second));

        Property nullValue = new Property("key", (String) null);
        assertFalse(nullValue.equals(new Property("key", "value")));
    }

    @Test
    public void descriptorListIsMutableAndCanBeSetToEmpty() {
        Property property = new Property("key", "value");
        property.setDescriptors(new ArrayList<Descriptor>());
        assertTrue(property.getDescriptors().isEmpty());

        property.getDescriptors().add(new Descriptor("unit", "metric"));
        assertEquals(1, property.getDescriptors().size());
    }

    @Test
    public void descriptorEqualityIsNotRequiredForPropertyComparison() {
        Property first = new Property("key", "value");
        first.setDescriptors(Arrays.asList(new Descriptor("a", "1"), new Descriptor("b", "2")));

        Property second = new Property("key", "value");
        second.setDescriptors(Arrays.asList(new Descriptor("b", "2"), new Descriptor("a", "1")));

        assertTrue(first.equals(second));
        assertNotSame(first.getDescriptors().get(0), second.getDescriptors().get(1));
    }
}
