package org.openape.api.databaseObjectBase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.*;

public class Property_ArrowTest {

    @Test
    public void defaultConstructorInitializesEmptyDescriptors() {
        Property property = new Property();

        assertNull(property.getName());
        assertNull(property.getValue());
        assertNotNull(property.getDescriptors());
        assertTrue(property.getDescriptors().isEmpty());
    }

    @Test
    public void constructorsPreserveNameAndValueTypes() {
        assertPropertyValue(new Property("text", "value"), "text", "value");
        assertPropertyValue(new Property("flag", true), "flag", Boolean.TRUE);
        assertPropertyValue(new Property("count", 7), "count", Integer.valueOf(7));
        assertPropertyValue(new Property("ratio", 2.5), "ratio", Double.valueOf(2.5));
    }

    @Test
    public void settersAndStringConversionWork() {
        Property property = new Property();
        property.setName("enabled");
        property.setValue(true);

        assertEquals("enabled", property.getName());
        assertEquals(Boolean.TRUE, property.getValue());

        property.setValue(12);
        assertEquals(Integer.valueOf(12), property.getValue());

        property.setValue(3.25);
        assertEquals(Double.valueOf(3.25), property.getValue());

        property.setValueAsString("ready");
        assertEquals("ready", property.getValue());
        assertEquals("ready", property.getValueAsString());
    }

    @Test
    public void descriptorsCanBeAddedAndReplaced() {
        Property property = new Property("item", "value");
        Descriptor first = new Descriptor();
        Descriptor second = new Descriptor();

        property.addDescriptor(first);
        assertEquals(Arrays.asList(first), property.getDescriptors());

        List<Descriptor> replacement = new ArrayList<>();
        replacement.add(second);
        property.setDescriptors(replacement);

        assertSame(replacement, property.getDescriptors());
        assertEquals(Arrays.asList(second), property.getDescriptors());
    }

    @Test
    public void equalsComparesNameValueAndDescriptorsRegardlessOfDescriptorOrder() {
        Property first = new Property("item", "value");
        first.addDescriptor(descriptor("color", "blue"));
        first.addDescriptor(descriptor("size", "large"));

        Property second = new Property("item", "value");
        second.addDescriptor(descriptor("size", "large"));
        second.addDescriptor(descriptor("color", "blue"));

        assertEquals(first, second);
        assertEquals(second, first);
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    public void equalsRejectsDifferentNamesValuesOrDescriptors() {
        Property base = new Property("item", "value");
        base.addDescriptor(descriptor("color", "blue"));

        Property differentDescriptors = new Property("item", "value");
        differentDescriptors.addDescriptor(descriptor("color", "red"));

        assertNotEquals(base, new Property("other", "value"));
        assertNotEquals(base, new Property("item", "other"));
        assertNotEquals(base, differentDescriptors);
        assertNotEquals(base, null);
        assertNotEquals(base, "item");
    }

    @Test
    public void equalsHandlesNullNameOrValueWithoutThrowing() {
        Property unset = new Property();
        assertNotEquals(unset, new Property());
        assertNotEquals(unset, new Property("name", "value"));
    }

    @Test
    public void getValueAsStringUsesValueToString() {
        Property property = new Property("count", 42);

        assertEquals("42", property.getValueAsString());
    }

    private static Descriptor descriptor(String name, String value) {
        Descriptor descriptor = new Descriptor();
        descriptor.setName(name);
        descriptor.setValue(value);
        return descriptor;
    }

    private static void assertPropertyValue(Property property, String name, Object value) {
        assertEquals(name, property.getName());
        assertEquals(value, property.getValue());
    }
}
