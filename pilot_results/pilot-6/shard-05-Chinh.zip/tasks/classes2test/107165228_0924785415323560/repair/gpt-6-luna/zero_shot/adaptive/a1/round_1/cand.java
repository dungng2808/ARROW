package com.devskiller.jpa2ddl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class FileResolver_ArrowTest {

    private Path tempDir;

    @Before
    public void setUp() throws IOException {
        tempDir = Files.createTempDirectory("file-resolver-test");
    }

    @Test
    public void resolvesMigrationsInAscendingVersionOrder() throws IOException {
        Path directory = Files.createDirectory(tempDir.resolve("migrations"));
        Path v10 = Files.createFile(directory.resolve("v10__later.sql"));
        Path v2 = Files.createFile(directory.resolve("v2__earlier.sql"));
        Path unrelated = Files.createFile(directory.resolve("notes.txt"));

        List<Path> migrations = FileResolver.resolveExistingMigrations(directory.toFile(), false, false);

        assertEquals(Arrays.asList(v2, v10, unrelated), migrations);
    }

    @Test
    public void resolvesMigrationsInDescendingVersionOrder() throws IOException {
        Path directory = Files.createDirectory(tempDir.resolve("migrations"));
        Path v10 = Files.createFile(directory.resolve("v10__later.sql"));
        Path v2 = Files.createFile(directory.resolve("v2__earlier.sql"));
        Path unrelated = Files.createFile(directory.resolve("notes.txt"));

        List<Path> migrations = FileResolver.resolveExistingMigrations(directory.toFile(), true, false);

        assertEquals(Arrays.asList(v10, v2, unrelated), migrations);
    }

    @Test
    public void filtersSchemaMigrationsCaseInsensitively() throws IOException {
        Path directory = Files.createDirectory(tempDir.resolve("migrations"));
        Path schema = Files.createFile(directory.resolve("v3__jpa2ddl-schema.sql"));
        Path schemaUppercase = Files.createFile(directory.resolve("V4__JPA2DDL.sql"));
        Files.createFile(directory.resolve("v5__application.sql"));
        Files.createFile(directory.resolve("readme.txt"));

        List<Path> migrations = FileResolver.resolveExistingMigrations(directory.toFile(), false, true);

        assertEquals(Arrays.asList(schema, schemaUppercase), migrations);
    }

    @Test
    public void createsMissingDirectoryAndReturnsNoMigrations() {
        File directory = tempDir.resolve("not-created-yet").toFile();

        List<Path> migrations = FileResolver.resolveExistingMigrations(directory, false, false);

        assertTrue(directory.isDirectory());
        assertTrue(migrations.isEmpty());
    }

    @Test
    public void resolvesNextMigrationAfterHighestVersion() throws IOException {
        Path directory = Files.createDirectory(tempDir.resolve("migrations"));
        Files.createFile(directory.resolve("v2__first.sql"));
        Files.createFile(directory.resolve("v10__latest.sql"));
        Files.createFile(directory.resolve("notes.txt"));

        File next = FileResolver.resolveNextMigrationFile(directory.toFile());

        assertEquals(directory.resolve("v11__jpa2ddl.sql").toFile(), next);
    }

    @Test
    public void resolvesFirstMigrationWhenDirectoryIsEmpty() throws IOException {
        Path directory = Files.createDirectory(tempDir.resolve("empty"));

        File next = FileResolver.resolveNextMigrationFile(directory.toFile());

        assertEquals(directory.resolve("v1__jpa2ddl.sql").toFile(), next);
    }

    @Test
    public void listsClassesInAnExistingPackage() throws Exception {
        List<String> classNames = FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl");

        assertTrue(classNames.contains("com.devskiller.jpa2ddl.FileResolver"));
        assertTrue(classNames.contains("com.devskiller.jpa2ddl.FileResolver_ArrowTest"));
    }

    @Test
    public void throwsWhenPackageDoesNotExist() {
        try {
            FileResolver.listClassNamesInPackage("package.that.does.not.exist");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // Expected.
        } catch (Exception unexpected) {
            fail("Expected IllegalStateException but got " + unexpected);
        }
    }
}
