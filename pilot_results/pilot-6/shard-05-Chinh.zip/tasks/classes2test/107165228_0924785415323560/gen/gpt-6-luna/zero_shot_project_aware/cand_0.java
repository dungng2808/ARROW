package com.devskiller.jpa2ddl;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class FileResolver_ArrowTest {

	@Rule
	public TemporaryFolder temporaryFolder = new TemporaryFolder();

	@Test
	public void resolvesNextMigrationAsOneWhenDirectoryIsEmpty() throws Exception {
		File directory = temporaryFolder.newFolder("empty");

		File next = FileResolver.resolveNextMigrationFile(directory);

		assertEquals(new File(directory, "v1__jpa2ddl.sql"), next);
	}

	@Test
	public void resolvesNextMigrationUsingHighestVersionRegardlessOfFilenameCase() throws Exception {
		File directory = temporaryFolder.newFolder("migrations");
		touch(directory, "v2__first.sql");
		touch(directory, "V12__latest.SQL");
		touch(directory, "v7__middle.sql");
		touch(directory, "not-a-migration.sql");

		assertEquals(new File(directory, "v13__jpa2ddl.sql"),
				FileResolver.resolveNextMigrationFile(directory));
	}

	@Test
	public void createsMissingDirectoryWhenResolvingNextMigration() throws Exception {
		File directory = new File(temporaryFolder.getRoot(), "created-later");

		File next = FileResolver.resolveNextMigrationFile(directory);

		assertTrue(directory.isDirectory());
		assertEquals(new File(directory, "v1__jpa2ddl.sql"), next);
	}

	@Test
	public void resolvesExistingMigrationsInAscendingVersionOrder() throws Exception {
		File directory = temporaryFolder.newFolder("ascending");
		touch(directory, "v10__ten.sql");
		touch(directory, "v2__two.sql");
		touch(directory, "v1__one.sql");
		touch(directory, "notes.txt");

		List<Path> paths = FileResolver.resolveExistingMigrations(directory, false, false);

		assertEquals(Arrays.asList(
				new File(directory, "notes.txt").toPath(),
				new File(directory, "v1__one.sql").toPath(),
				new File(directory, "v2__two.sql").toPath(),
				new File(directory, "v10__ten.sql").toPath()), paths);
	}

	@Test
	public void resolvesExistingMigrationsInDescendingVersionOrder() throws Exception {
		File directory = temporaryFolder.newFolder("descending");
		touch(directory, "v1__one.sql");
		touch(directory, "v10__ten.sql");
		touch(directory, "v3__three.sql");

		List<Path> paths = FileResolver.resolveExistingMigrations(directory, true, false);

		assertEquals(Arrays.asList(
				new File(directory, "v10__ten.sql").toPath(),
				new File(directory, "v3__three.sql").toPath(),
				new File(directory, "v1__one.sql").toPath()), paths);
	}

	@Test
	public void filtersSchemaMigrationsAndSortsThemByVersion() throws Exception {
		File directory = temporaryFolder.newFolder("schema");
		touch(directory, "v8__jpa2ddl.sql");
		touch(directory, "V2__JPA2DDL_schema.SQL");
		touch(directory, "v4__application.sql");
		touch(directory, "v3__jpa2ddl.txt");
		touch(directory, "unversioned.sql");

		List<Path> paths = FileResolver.resolveExistingMigrations(directory, false, true);

		assertEquals(Arrays.asList(
				new File(directory, "V2__JPA2DDL_schema.SQL").toPath(),
				new File(directory, "v8__jpa2ddl.sql").toPath()), paths);
	}

	@Test
	public void returnsEmptyListForAnExistingEmptyDirectory() throws Exception {
		File directory = temporaryFolder.newFolder("empty-existing");

		assertTrue(FileResolver.resolveExistingMigrations(directory, false, false).isEmpty());
	}

	@Test
	public void returnsEmptyListWhenTheArgumentIsAFile() throws Exception {
		File file = temporaryFolder.newFile("not-a-directory");

		assertTrue(FileResolver.resolveExistingMigrations(file, false, false).isEmpty());
	}

	@Test
	public void listsClassNamesInPackage() throws Exception {
		List<String> classNames = FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl");

		assertTrue(classNames.contains("com.devskiller.jpa2ddl.FileResolver"));
		assertTrue(classNames.contains("com.devskiller.jpa2ddl.FileResolver_ArrowTest"));
	}

	@Test
	public void throwsWhenPackageCannotBeFound() throws Exception {
		try {
			FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl.package_that_does_not_exist");
		} catch (IllegalStateException expected) {
			assertTrue(expected.getMessage().contains("No package found"));
			return;
		}
		assertFalse("Expected an exception for a package with no resources", true);
	}

	private static void touch(File directory, String name) throws Exception {
		File file = new File(directory, name);
		assertTrue(file.createNewFile());
	}
}
