package org.zalando.stups.oauth2.spring.client;

import org.junit.Test;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.zalando.stups.tokens.AccessToken;
import org.zalando.stups.tokens.AccessTokenUnavailableException;
import org.zalando.stups.tokens.AccessTokens;

import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class StupsTokensAccessTokenProvider_ArrowTest {

    @Test
    public void obtainsBearerTokenAndExpiration() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(accessToken.getToken()).thenReturn("access-token");
        when(accessToken.getValidUntil()).thenReturn(
                new Date(System.currentTimeMillis() + 120000));
        when(tokens.getAccessToken("my-token")).thenReturn(accessToken);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("my-token", tokens);

        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("access-token", result.getValue());
        assertEquals(OAuth2AccessToken.BEARER_TYPE, result.getTokenType());
        assertNotNull(result.getExpiration());
        assertTrue(result.getExpiresIn() > 0 && result.getExpiresIn() <= 120);
        verify(tokens).getAccessToken("my-token");
    }

    @Test
    public void obtainsTokenWithoutExpiration() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(accessToken.getToken()).thenReturn("access-token");
        when(accessToken.getValidUntil()).thenReturn(null);
        when(tokens.getAccessToken("my-token")).thenReturn(accessToken);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("my-token", tokens);

        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("access-token", result.getValue());
        assertNull(result.getExpiration());
    }

    @Test
    public void wrapsUnavailableTokenException() {
        final AccessTokens tokens = mock(AccessTokens.class);
        final AccessTokenUnavailableException unavailable =
                mock(AccessTokenUnavailableException.class);
        when(tokens.getAccessToken("my-token")).thenThrow(unavailable);

        final StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("my-token", tokens);

        try {
            provider.obtainAccessToken(
                    mock(OAuth2ProtectedResourceDetails.class),
                    mock(AccessTokenRequest.class));
            throw new AssertionError("Expected OAuth2Exception");
        } catch (OAuth2Exception exception) {
            assertEquals("Could not obtain access token.", exception.getMessage());
            assertSame(unavailable, exception.getCause());
        }
    }

    @Test
    public void rejectsBlankTokenId() {
        final AccessTokens tokens = mock(AccessTokens.class);
        try {
            new StupsTokensAccessTokenProvider("  ", tokens);
            throw new AssertionError("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }

    @Test
    public void rejectsNullTokens() {
        try {
            new StupsTokensAccessTokenProvider("my-token", null);
            throw new AssertionError("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }
}
