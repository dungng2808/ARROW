package org.zalando.stups.oauth2.spring.client;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.zalando.stups.tokens.AccessToken;
import org.zalando.stups.tokens.AccessTokenUnavailableException;
import org.zalando.stups.tokens.AccessTokens;

import java.util.Date;
import static org.mockito.Mockito.*;
import org.junit.Test;
import static org.junit.Assert.*;

class StupsTokensAccessTokenProvider_ArrowTest {

    @Test
    void obtainsBearerTokenAndExpiration() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(accessToken.getToken()).thenReturn("access-token");
        when(accessToken.getValidUntil()).thenReturn(new Date(System.currentTimeMillis() + 120_000));
        when(tokens.getAccessToken("my-token")).thenReturn(accessToken);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("my-token", tokens);

        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("access-token", result.getValue());
        assertEquals(OAuth2AccessToken.BEARER_TYPE, result.getTokenType());
        assertNotNull(result.getExpiration());
        assertTrue(result.getExpiresIn() > 0 && result.getExpiresIn() <= 120);
        verify(tokens).getAccessToken("my-token");
    }

    @Test
    void obtainsTokenWithoutExpiration() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(accessToken.getToken()).thenReturn("access-token");
        when(accessToken.getValidUntil()).thenReturn(null);
        when(tokens.getAccessToken("my-token")).thenReturn(accessToken);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("my-token", tokens);

        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("access-token", result.getValue());
        assertNull(result.getExpiration());
    }

    @Test
    void wrapsUnavailableTokenException() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessTokenUnavailableException unavailable =
                mock(AccessTokenUnavailableException.class);
        when(tokens.getAccessToken("my-token")).thenThrow(unavailable);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("my-token", tokens);

        OAuth2Exception exception = assertThrows(OAuth2Exception.class,
                () -> provider.obtainAccessToken(
                        mock(OAuth2ProtectedResourceDetails.class),
                        mock(AccessTokenRequest.class)));

        assertEquals("Could not obtain access token.", exception.getMessage());
        assertSame(unavailable, exception.getCause());
    }

    @Test
    void rejectsBlankTokenId() {
        AccessTokens tokens = mock(AccessTokens.class);
        assertThrows(IllegalArgumentException.class,
                () -> new StupsTokensAccessTokenProvider("  ", tokens));
    }

    @Test
    void rejectsNullTokens() {
        assertThrows(IllegalArgumentException.class,
                () -> new StupsTokensAccessTokenProvider("my-token", null));
    }
}
