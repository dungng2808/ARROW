package org.zalando.stups.oauth2.spring.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.Test;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.zalando.stups.tokens.AccessToken;
import org.zalando.stups.tokens.AccessTokenUnavailableException;
import org.zalando.stups.tokens.AccessTokens;

public class StupsTokensAccessTokenProvider_ArrowTest {

    @Test
    public void obtainsBearerTokenAndExpiration() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(tokens.getAccessToken("service")).thenReturn(accessToken);
        when(accessToken.getToken()).thenReturn("token-value");
        when(accessToken.getValidUntil()).thenReturn(new Date(System.currentTimeMillis() + 120_000L));

        StupsTokensAccessTokenProvider provider = new StupsTokensAccessTokenProvider("service", tokens);
        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("token-value", result.getValue());
        assertEquals(OAuth2AccessToken.BEARER_TYPE, result.getTokenType());
        assertNotNull(result.getExpiration());
        assertTrue(result.getExpiresIn() >= 119);
        assertTrue(result.getExpiresIn() <= 120);
        verify(tokens).getAccessToken("service");
    }

    @Test
    public void omitsExpirationWhenTokenHasNoValidityDate() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(tokens.getAccessToken("service")).thenReturn(accessToken);
        when(accessToken.getToken()).thenReturn("token-value");
        when(accessToken.getValidUntil()).thenReturn(null);

        StupsTokensAccessTokenProvider provider = new StupsTokensAccessTokenProvider("service", tokens);
        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("token-value", result.getValue());
        assertEquals(OAuth2AccessToken.BEARER_TYPE, result.getTokenType());
        assertNull(result.getExpiration());
    }

    @Test
    public void wrapsUnavailableTokenException() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessTokenUnavailableException cause = mock(AccessTokenUnavailableException.class);
        when(tokens.getAccessToken("service")).thenThrow(cause);

        StupsTokensAccessTokenProvider provider = new StupsTokensAccessTokenProvider("service", tokens);
        try {
            provider.obtainAccessToken(mock(OAuth2ProtectedResourceDetails.class),
                    mock(AccessTokenRequest.class));
        } catch (OAuth2Exception exception) {
            assertEquals("Could not obtain access token.", exception.getMessage());
            assertEquals(cause, exception.getCause());
            return;
        }
        throw new AssertionError("Expected OAuth2Exception");
    }

    @Test
    public void rejectsBlankTokenId() {
        try {
            new StupsTokensAccessTokenProvider("  ", mock(AccessTokens.class));
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    @Test
    public void rejectsNullTokens() {
        try {
            new StupsTokensAccessTokenProvider("service", null);
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }
}
