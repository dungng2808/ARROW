package org.zalando.stups.oauth2.spring.client;

import org.junit.Test;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.zalando.stups.tokens.AccessToken;
import org.zalando.stups.tokens.AccessTokenUnavailableException;
import org.zalando.stups.tokens.AccessTokens;

import java.util.Date;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class StupsTokensAccessTokenProvider_ArrowTest {

    @Test
    public void obtainsBearerTokenAndExpirationFromTokens() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(accessToken.getToken()).thenReturn("sample-token");
        when(accessToken.getValidUntil()).thenReturn(new Date(System.currentTimeMillis() + 120_000L));
        when(tokens.getAccessToken("my-token")).thenReturn(accessToken);

        StupsTokensAccessTokenProvider provider = new StupsTokensAccessTokenProvider("my-token", tokens);
        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("sample-token", result.getValue());
        assertEquals(OAuth2AccessToken.BEARER_TYPE, result.getTokenType());
        assertNotNull(result.getExpiration());
        assertTrue(result.getExpiresIn() >= 0);
        assertTrue(result.getExpiresIn() <= 120);
        verify(tokens).getAccessToken("my-token");
    }

    @Test
    public void obtainsTokenWithoutExpirationWhenValidityIsNull() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(accessToken.getToken()).thenReturn("non-expiring-token");
        when(accessToken.getValidUntil()).thenReturn(null);
        when(tokens.getAccessToken("token-id")).thenReturn(accessToken);

        StupsTokensAccessTokenProvider provider = new StupsTokensAccessTokenProvider("token-id", tokens);
        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("non-expiring-token", result.getValue());
        assertEquals(OAuth2AccessToken.BEARER_TYPE, result.getTokenType());
        assertNull(result.getExpiration());
    }

    @Test
    public void wrapsUnavailableTokenException() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessTokenUnavailableException unavailable = mock(AccessTokenUnavailableException.class);
        when(tokens.getAccessToken("missing")).thenThrow(unavailable);

        StupsTokensAccessTokenProvider provider = new StupsTokensAccessTokenProvider("missing", tokens);
        OAuth2Exception thrown = assertThrows(OAuth2Exception.class, () ->
                provider.obtainAccessToken(mock(OAuth2ProtectedResourceDetails.class),
                        mock(AccessTokenRequest.class)));

        assertEquals("Could not obtain access token.", thrown.getMessage());
        assertSame(unavailable, thrown.getCause());
    }

    @Test
    public void rejectsBlankTokenId() {
        AccessTokens tokens = mock(AccessTokens.class);
        try {
            new StupsTokensAccessTokenProvider("  ", tokens);
            fail("Expected blank token id to be rejected");
        } catch (IllegalArgumentException expected) {
            assertEquals("tokenId cannot be left blank", expected.getMessage());
        }
    }

    @Test
    public void rejectsNullTokens() {
        try {
            new StupsTokensAccessTokenProvider("token-id", null);
            fail("Expected null tokens to be rejected");
        } catch (IllegalArgumentException expected) {
            assertEquals("tokens must not be null", expected.getMessage());
        }
    }
}
