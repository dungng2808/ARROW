package com.microsoft.azure.common.function.utils;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CommandUtils_ArrowTest {

    @Test
    public void isWindowsMatchesSystemProperty() {
        assertEquals(System.getProperty("os.name", "").toLowerCase().startsWith("windows"),
                CommandUtils.isWindows());
    }

    @Test
    public void defaultValidReturnCodesContainsOnlyZero() {
        assertEquals(Collections.singletonList(0L), CommandUtils.getDefaultValidReturnCodes());
    }

    @Test
    public void validReturnCodesContainsZeroAndPlatformSpecificInterruptCode() {
        assertEquals(CommandUtils.isWindows()
                        ? Arrays.asList(0L, 3221225786L)
                        : Arrays.asList(0L, 130L),
                CommandUtils.getValidReturnCodes());
    }

    @Test
    public void returnedListsHaveExpectedContents() {
        assertTrue(CommandUtils.getDefaultValidReturnCodes().contains(0L));
        assertTrue(CommandUtils.getValidReturnCodes().contains(0L));
    }
}
