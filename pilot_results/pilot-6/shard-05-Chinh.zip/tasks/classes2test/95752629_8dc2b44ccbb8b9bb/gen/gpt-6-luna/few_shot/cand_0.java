package com.microsoft.azure.common.function.utils;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CommandUtils_ArrowTest {

    @Test
    public void isWindowsMatchesSystemPlatform() {
        assertEquals(org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS, CommandUtils.isWindows());
    }

    @Test
    public void defaultValidReturnCodesContainsOnlyZero() {
        List<Long> codes = CommandUtils.getDefaultValidReturnCodes();

        assertNotNull(codes);
        assertEquals(Arrays.asList(0L), codes);
    }

    @Test
    public void validReturnCodesIncludePlatformSpecificInterruptCode() {
        List<Long> expected = CommandUtils.isWindows()
                ? Arrays.asList(0L, 3221225786L)
                : Arrays.asList(0L, 130L);

        assertEquals(expected, CommandUtils.getValidReturnCodes());
    }
}
