package site.ycsb.generator;

import org.junit.Test;

import static org.junit.Assert.*;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void generatesValuesWithinConfiguredInclusiveRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10, 25);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      assertTrue("value below configured minimum: " + value, value >= 10);
      assertTrue("value above configured maximum: " + value, value <= 25);
    }
  }

  @Test
  public void itemCountConstructorGeneratesValuesFromZeroToCountMinusOne() {
    ZipfianGenerator generator = new ZipfianGenerator(20);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 0);
      assertTrue(value < 20);
    }
  }

  @Test
  public void singletonRangeAlwaysGeneratesItsOnlyItem() {
    ZipfianGenerator generator = new ZipfianGenerator(7, 7);

    for (int i = 0; i < 100; i++) {
      assertEquals(Long.valueOf(7), generator.nextValue());
    }
  }

  @Test
  public void supportsCustomZipfianConstantAndPrecomputedZeta() {
    double theta = 0.5;
    double zeta = ZipfianGenerator.zetastatic(5, theta);
    ZipfianGenerator generator = new ZipfianGenerator(3, 7, theta, zeta);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 3);
      assertTrue(value <= 7);
    }
  }

  @Test
  public void zetaCalculationsSupportFullAndIncrementalSums() {
    double full = ZipfianGenerator.zetastatic(4, 1.0);
    assertEquals(1.0 + 0.5 + 1.0 / 3.0 + 0.25, full, 1e-12);

    double partial = ZipfianGenerator.zetastatic(0, 2, 1.0, 0.0);
    double extended = ZipfianGenerator.zetastatic(2, 4, 1.0, partial);
    assertEquals(full, extended, 1e-12);
  }

  @Test
  public void nextLongCanExpandItemCountAndKeepsResultsInRange() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextLong(12);
      assertTrue(value >= 0);
      assertTrue(value < 12);
    }
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    try {
      generator.mean();
      fail("mean should be unsupported");
    } catch (UnsupportedOperationException expected) {
      assertEquals("@todo implement ZipfianGenerator.mean()", expected.getMessage());
    }
  }
}
