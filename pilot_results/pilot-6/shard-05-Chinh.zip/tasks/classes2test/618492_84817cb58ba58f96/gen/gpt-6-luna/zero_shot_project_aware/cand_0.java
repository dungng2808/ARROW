package site.ycsb.generator;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void generatesValuesWithinConfiguredRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10L, 30L);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      Assert.assertTrue(value >= 10L && value <= 30L,
          "Generated value must be within the configured inclusive range: " + value);
    }
  }

  @Test
  public void itemCountConstructorGeneratesZeroBasedValues() {
    ZipfianGenerator generator = new ZipfianGenerator(25L);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      Assert.assertTrue(value >= 0L && value < 25L,
          "Generated value must be within the configured item count: " + value);
    }
  }

  @Test
  public void supportsIncrementallyIncreasingItemCount() {
    ZipfianGenerator generator = new ZipfianGenerator(10L);

    for (int i = 0; i < 100; i++) {
      long value = generator.nextLong(20L);
      Assert.assertTrue(value >= 0L && value < 20L,
          "Generated value must be within the increased item count: " + value);
    }
  }

  @Test
  public void zetaMatchesFiniteSum() {
    ZipfianGenerator generator = new ZipfianGenerator(5L);
    double expected = 0.0;
    for (int i = 1; i <= 5; i++) {
      expected += 1.0 / Math.pow(i, ZipfianGenerator.ZIPFIAN_CONSTANT);
    }

    Assert.assertEquals(generator.zeta(5L, ZipfianGenerator.ZIPFIAN_CONSTANT),
        expected, 1.0e-12);
  }

  @Test
  public void staticZetaSupportsIncrementalSums() {
    double firstPart = ZipfianGenerator.zetastatic(0L, 3L, 0.5, 0.0);
    double complete = ZipfianGenerator.zetastatic(3L, 5L, 0.5, firstPart);
    double expected = 0.0;
    for (int i = 1; i <= 5; i++) {
      expected += 1.0 / Math.sqrt(i);
    }

    Assert.assertEquals(complete, expected, 1.0e-12);
  }

  @Test
  public void meanIsExplicitlyUnsupported() {
    ZipfianGenerator generator = new ZipfianGenerator(5L);

    try {
      generator.mean();
      Assert.fail("mean() should be unsupported");
    } catch (UnsupportedOperationException expected) {
      Assert.assertTrue(expected.getMessage().contains("implement"));
    }
  }
}
