package site.ycsb.generator;

import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void generatesValuesWithinConfiguredRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10, 30);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      assertTrue("value outside configured range: " + value, value >= 10 && value <= 30);
    }
  }

  @Test
  public void itemCountConstructorGeneratesValuesFromZeroToCountMinusOne() {
    ZipfianGenerator generator = new ZipfianGenerator(25);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      assertTrue("value outside expected range: " + value, value >= 0 && value < 25);
    }
  }

  @Test
  public void seededThreadRandomProducesRepeatableSequences() {
    Random first = ZipfianGenerator.threadRandom(12345L).get();
    Random second = ZipfianGenerator.threadRandom(12345L).get();

    for (int i = 0; i < 20; i++) {
      assertEquals("seeded random sequences differ", first.nextLong(), second.nextLong());
    }
  }

  @Test
  public void zetaCalculationsMatchExpectedSums() {
    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        ZipfianGenerator.zetastatic(3, 0.5), 1e-12);
    assertApproximatelyEquals(
        1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        ZipfianGenerator.zetastatic(1, 3, 0.5, 0.0), 1e-12);
  }

  @Test
  public void zetaInstanceMethodsUpdateTheRememberedCount() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        generator.zeta(3, 0.5), 1e-12);
    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        generator.zeta(0, 3, 0.5, 0.0), 1e-12);
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(10);

    try {
      generator.mean();
      fail("mean should not be implemented");
    } catch (UnsupportedOperationException expected) {
      assertNotNull("exception message should not be null", expected.getMessage());
    }
  }

  @Test
  public void generatedValuesAreLongNumbers() {
    ZipfianGenerator generator = new ZipfianGenerator(10);
    Long value = generator.nextValue();

    assertNotNull("generated value should not be null", value);
    assertEquals(Long.class, value.getClass());
  }

  private static void assertApproximatelyEquals(double expected, double actual, double delta) {
    assertTrue(
        "expected " + expected + " but was " + actual + " (delta " + delta + ")",
        !Double.isNaN(actual) && Math.abs(expected - actual) <= delta);
  }
}
