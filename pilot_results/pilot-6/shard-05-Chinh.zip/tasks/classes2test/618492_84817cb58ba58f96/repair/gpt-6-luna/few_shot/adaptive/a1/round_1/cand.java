package site.ycsb.generator;

import java.util.Random;
import org.junit.Test;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void generatesValuesWithinConfiguredRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10, 30);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      if (value < 10 || value > 30) {
        throw new AssertionError("value outside configured range: " + value);
      }
    }
  }

  @Test
  public void itemCountConstructorGeneratesValuesFromZeroToCountMinusOne() {
    ZipfianGenerator generator = new ZipfianGenerator(25);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      if (value < 0 || value >= 25) {
        throw new AssertionError("value outside expected range: " + value);
      }
    }
  }

  @Test
  public void seededThreadRandomProducesRepeatableSequences() {
    Random first = ZipfianGenerator.threadRandom(12345L).get();
    Random second = ZipfianGenerator.threadRandom(12345L).get();

    for (int i = 0; i < 20; i++) {
      if (first.nextLong() != second.nextLong()) {
        throw new AssertionError("seeded random sequences differ");
      }
    }
  }

  @Test
  public void zetaCalculationsMatchExpectedSums() {
    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        ZipfianGenerator.zetastatic(3, 0.5), 1e-12);
    assertApproximatelyEquals(
        1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        ZipfianGenerator.zetastatic(1, 3, 0.5, 0.0), 1e-12);
  }

  @Test
  public void zetaInstanceMethodsUpdateTheRememberedCount() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        generator.zeta(3, 0.5), 1e-12);
    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        generator.zeta(0, 3, 0.5, 0.0), 1e-12);
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(10);

    try {
      generator.mean();
      throw new AssertionError("mean should not be implemented");
    } catch (UnsupportedOperationException expected) {
      if (expected.getMessage() == null) {
        throw new AssertionError("exception message should not be null");
      }
    }
  }

  @Test
  public void generatedValuesAreLongNumbers() {
    ZipfianGenerator generator = new ZipfianGenerator(10);
    Long value = generator.nextValue();

    if (value == null) {
      throw new AssertionError("generated value should not be null");
    }
    if (value.getClass().isPrimitive()) {
      throw new AssertionError("generated value should be a boxed number");
    }
  }

  private static void assertApproximatelyEquals(double expected, double actual, double delta) {
    if (Double.isNaN(actual) || Math.abs(expected - actual) > delta) {
      throw new AssertionError(
          "expected " + expected + " but was " + actual + " (delta " + delta + ")");
    }
  }
}
