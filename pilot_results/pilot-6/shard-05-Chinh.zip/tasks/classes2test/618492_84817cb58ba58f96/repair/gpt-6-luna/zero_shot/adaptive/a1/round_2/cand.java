package site.ycsb.generator;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void generatesValuesWithinConfiguredInclusiveRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10, 25);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 10, "value below configured minimum: " + value);
      assertTrue(value <= 25, "value above configured maximum: " + value);
    }
  }

  @Test
  public void itemCountConstructorGeneratesValuesFromZeroToCountMinusOne() {
    ZipfianGenerator generator = new ZipfianGenerator(20);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 0);
      assertTrue(value < 20);
    }
  }

  @Test
  public void singletonRangeAlwaysGeneratesItsOnlyItem() {
    ZipfianGenerator generator = new ZipfianGenerator(7, 7);

    for (int i = 0; i < 100; i++) {
      assertEquals(generator.nextValue().longValue(), 7L);
    }
  }

  @Test
  public void supportsCustomZipfianConstantAndPrecomputedZeta() {
    double theta = 0.5;
    double zeta = ZipfianGenerator.zetastatic(5, theta);
    ZipfianGenerator generator = new ZipfianGenerator(3, 7, theta, zeta);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 3);
      assertTrue(value <= 7);
    }
  }

  @Test
  public void zetaCalculationsSupportFullAndIncrementalSums() {
    double full = ZipfianGenerator.zetastatic(4, 1.0);
    assertEquals(full, 1.0 + 0.5 + 1.0 / 3.0 + 0.25, 1e-12);

    double partial = ZipfianGenerator.zetastatic(0, 2, 1.0, 0.0);
    double extended = ZipfianGenerator.zetastatic(2, 4, 1.0, partial);
    assertEquals(extended, full, 1e-12);
  }

  @Test
  public void nextLongCanExpandItemCountAndKeepsResultsInRange() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextLong(12);
      assertTrue(value >= 0);
      assertTrue(value < 12);
    }
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    try {
      generator.mean();
      fail("mean should be unsupported");
    } catch (UnsupportedOperationException expected) {
      assertEquals(expected.getMessage(), "@todo implement ZipfianGenerator.mean()");
    }
  }
}
