package site.ycsb.generator;

import java.util.Random;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void generatesValuesWithinConfiguredRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10, 30);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      Assert.assertTrue(value >= 10, "value below configured minimum: " + value);
      Assert.assertTrue(value <= 30, "value above configured maximum: " + value);
    }
  }

  @Test
  public void itemCountConstructorGeneratesValuesFromZeroToCountMinusOne() {
    ZipfianGenerator generator = new ZipfianGenerator(25);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      Assert.assertTrue(value >= 0);
      Assert.assertTrue(value < 25);
    }
  }

  @Test
  public void seededThreadRandomProducesRepeatableSequences() {
    Random first = ZipfianGenerator.threadRandom(12345L).get();
    Random second = ZipfianGenerator.threadRandom(12345L).get();

    for (int i = 0; i < 20; i++) {
      Assert.assertEquals(first.nextLong(), second.nextLong());
    }
  }

  @Test
  public void zetaCalculationsMatchExpectedSums() {
    Assert.assertEquals(ZipfianGenerator.zetastatic(3, 0.5),
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0), 1e-12);
    Assert.assertEquals(ZipfianGenerator.zetastatic(1, 3, 0.5, 0.0),
        1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0), 1e-12);
  }

  @Test
  public void zetaInstanceMethodsUpdateTheRememberedCount() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    Assert.assertEquals(generator.zeta(3, 0.5),
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0), 1e-12);
    Assert.assertEquals(generator.zeta(0, 3, 0.5, 0.0),
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0), 1e-12);
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(10);

    try {
      generator.mean();
      Assert.fail("mean should not be implemented");
    } catch (UnsupportedOperationException expected) {
      Assert.assertNotNull(expected.getMessage());
    }
  }

  @Test
  public void generatedValuesAreLongNumbers() {
    ZipfianGenerator generator = new ZipfianGenerator(10);

    Assert.assertNotNull(generator.nextValue());
    Assert.assertFalse(generator.nextValue().getClass().isPrimitive());
  }
}
