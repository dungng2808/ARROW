package site.ycsb.generator;

import java.util.Random;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void generatesValuesWithinConfiguredRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10, 30);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 10 && value <= 30, "value outside configured range: " + value);
    }
  }

  @Test
  public void itemCountConstructorGeneratesValuesFromZeroToCountMinusOne() {
    ZipfianGenerator generator = new ZipfianGenerator(25);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 0 && value < 25, "value outside expected range: " + value);
    }
  }

  @Test
  public void seededThreadRandomProducesRepeatableSequences() {
    Random first = ZipfianGenerator.threadRandom(12345L).get();
    Random second = ZipfianGenerator.threadRandom(12345L).get();

    for (int i = 0; i < 20; i++) {
      assertEquals(first.nextLong(), second.nextLong(), "seeded random sequences differ");
    }
  }

  @Test
  public void zetaCalculationsMatchExpectedSums() {
    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        ZipfianGenerator.zetastatic(3, 0.5), 1e-12);
    assertApproximatelyEquals(
        1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        ZipfianGenerator.zetastatic(1, 3, 0.5, 0.0), 1e-12);
  }

  @Test
  public void zetaInstanceMethodsUpdateTheRememberedCount() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        generator.zeta(3, 0.5), 1e-12);
    assertApproximatelyEquals(
        1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        generator.zeta(0, 3, 0.5, 0.0), 1e-12);
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(10);

    try {
      generator.mean();
      fail("mean should not be implemented");
    } catch (UnsupportedOperationException expected) {
      assertNotNull(expected.getMessage(), "exception message should not be null");
    }
  }

  @Test
  public void generatedValuesAreLongNumbers() {
    ZipfianGenerator generator = new ZipfianGenerator(10);
    Long value = generator.nextValue();

    assertNotNull(value, "generated value should not be null");
    assertEquals(Long.class, value.getClass());
  }

  private static void assertApproximatelyEquals(double expected, double actual, double delta) {
    assertTrue(
        !Double.isNaN(actual) && Math.abs(expected - actual) <= delta,
        "expected " + expected + " but was " + actual + " (delta " + delta + ")");
  }
}
