package site.ycsb.generator;

import java.util.Random;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void generatesValuesWithinConfiguredRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10, 30);

    for (int i = 0; i < 1000; i++) {
      long value = generator.nextValue();
      assertTrue("value below configured minimum: " + value, value >= 10);
      assertTrue("value above configured maximum: " + value, value <= 30);
    }
  }

  @Test
  public void itemCountConstructorGeneratesValuesFromZeroToCountMinusOne() {
    ZipfianGenerator generator = new ZipfianGenerator(25);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 0);
      assertTrue(value < 25);
    }
  }

  @Test
  public void seededThreadRandomProducesRepeatableSequences() {
    Random first = ZipfianGenerator.threadRandom(12345L).get();
    Random second = ZipfianGenerator.threadRandom(12345L).get();

    for (int i = 0; i < 20; i++) {
      assertEquals(first.nextLong(), second.nextLong());
    }
  }

  @Test
  public void zetaCalculationsMatchExpectedSums() {
    assertEquals(1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        ZipfianGenerator.zetastatic(3, 0.5), 1e-12);
    assertEquals(1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        ZipfianGenerator.zetastatic(1, 3, 0.5, 0.0), 1e-12);
  }

  @Test
  public void zetaInstanceMethodsUpdateTheRememberedCount() {
    ZipfianGenerator generator = new ZipfianGenerator(5);

    assertEquals(1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        generator.zeta(3, 0.5), 1e-12);
    assertEquals(1.0 + 1.0 / Math.sqrt(2.0) + 1.0 / Math.sqrt(3.0),
        generator.zeta(0, 3, 0.5, 0.0), 1e-12);
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(10);

    try {
      generator.mean();
      fail("mean should not be implemented");
    } catch (UnsupportedOperationException expected) {
      assertNotNull(expected.getMessage());
    }
  }

  @Test
  public void generatedValuesAreLongNumbers() {
    ZipfianGenerator generator = new ZipfianGenerator(10);

    assertNotNull(generator.nextValue());
    assertFalse(generator.nextValue().getClass().isPrimitive());
  }
}
