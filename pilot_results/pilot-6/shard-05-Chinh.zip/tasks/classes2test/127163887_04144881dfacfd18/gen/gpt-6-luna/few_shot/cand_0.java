package com.batalov.RL;

import java.awt.geom.Point2D;
import org.junit.Test;
import static org.junit.Assert.*;

class RocketLander_ArrowTest {

    @Test
    void startsAtRestWithEnginesOff() {
        RocketLander lander = new RocketLander();

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertTrue(lander.isOnGround());
        assertFalse(lander.crashed());
    }

    @Test
    void bothEnginesCounterGravityAndLiftTheLander() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getX(), 1e-6);
        assertEquals(9.1875, lander.getPosition().getY(), 1e-5);
        assertEquals(0.0, lander.getVelocity().getX(), 1e-6);
        assertEquals(18.375, lander.getVelocity().getY(), 1e-5);
        assertEquals(0.0f, lander.getRotation(), 1e-6f);
        assertFalse(lander.crashed());
    }

    @Test
    void singleEngineRotatesAndLanderFalls() {
        RocketLander lander = new RocketLander();
        lander.setBurnRight(true);

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getX(), 1e-6);
        assertEquals(-0.8125, lander.getPosition().getY(), 1e-5);
        assertEquals(0.0, lander.getVelocity().getX(), 1e-6);
        assertEquals(0.0, lander.getVelocity().getY(), 1e-6);
        assertEquals(0.0f, lander.getRotation(), 1e-6f);
        assertTrue(lander.isOnGround());
        assertFalse(lander.crashed());
        assertFalse(lander.getBurnRight());
    }

    @Test
    void landingResetsVelocityRotationAndEngines() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(1.0f);

        lander.setBurnLeft(false);
        lander.setBurnRight(false);
        lander.tick(4.0f);

        assertTrue(lander.isOnGround());
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertFalse(lander.crashed());
    }

    @Test
    void crashStopsLanderAndSubsequentTicksDoNotChangeState() {
        RocketLander lander = new RocketLander();
        lander.tick(2.0f);

        assertTrue(lander.crashed());
        assertEquals(-1.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);

        Point2D positionBefore = (Point2D) lander.getPosition().clone();
        Point2D velocityBefore = (Point2D) lander.getVelocity().clone();
        lander.setBurnLeft(true);
        lander.tick(1.0f);

        assertEquals(positionBefore, lander.getPosition());
        assertEquals(velocityBefore, lander.getVelocity());
        assertFalse(lander.getBurnLeft());
    }

    @Test
    void staticPhysicsHelpersComputeExpectedVectors() {
        Point2D position = RocketLander.positionAfter(
                2.0f, new Point2D.Float(1.0f, 2.0f),
                new Point2D.Float(3.0f, 4.0f), new Point2D.Float(5.0f, 6.0f));
        assertEquals(17.0, position.getX(), 1e-6);
        assertEquals(22.0, position.getY(), 1e-6);

        Point2D velocity = RocketLander.velocityAfter(
                2.0f, new Point2D.Float(3.0f, 4.0f),
                new Point2D.Float(5.0f, 6.0f));
        assertEquals(13.0, velocity.getX(), 1e-6);
        assertEquals(16.0, velocity.getY(), 1e-6);

        Point2D sum = RocketLander.add(
                new Point2D.Float(1.0f, 2.0f), new Point2D.Float(3.0f, 4.0f));
        assertEquals(4.0, sum.getX(), 1e-6);
        assertEquals(6.0, sum.getY(), 1e-6);

        Point2D thrust = RocketLander.thrustVector((float) (Math.PI / 2), 10.0f);
        assertEquals(-10.0, thrust.getX(), 1e-5);
        assertEquals(0.0, thrust.getY(), 1e-5);
    }

    @Test
    void stringRepresentationIncludesEngineAndStateInformation() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(false);

        assertEquals("< * -- . >, p = [0.000000, 0.000000], v = [0.000000, 0.000000], r = 0.000000",
                lander.toString());
    }
}
