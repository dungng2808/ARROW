package com.batalov.RL;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.awt.geom.Point2D;

import org.junit.Test;

public class RocketLander_ArrowTest {

    private static final float EPSILON = 0.0001f;

    @Test
    public void newLanderStartsAtRestWithEnginesOff() {
        RocketLander lander = new RocketLander();

        assertEquals(0.0, lander.getPosition().getX(), EPSILON);
        assertEquals(0.0, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getX(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);
        assertEquals(0.0f, lander.getRotation(), EPSILON);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertTrue(lander.isOnGround());
    }

    @Test
    public void gravityMovesLanderDownwardWhenEnginesAreOff() {
        RocketLander lander = new RocketLander();

        // Lift off first; a tick on the ground with both engines burning
        // accelerates upward.
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(0.5f);
        lander.setBurnLeft(false);
        lander.setBurnRight(false);

        double startingY = lander.getPosition().getY();
        double startingVelocityY = lander.getVelocity().getY();
        lander.tick(0.5f);

        assertEquals(startingY + startingVelocityY * 0.5 - 1.625 * 0.5 * 0.5 / 2,
                lander.getPosition().getY(), EPSILON);
        assertEquals(startingVelocityY - 1.625 * 0.5,
                lander.getVelocity().getY(), EPSILON);
        assertFalse(lander.isOnGround());
    }

    @Test
    public void bothEnginesCancelGravityAndProduceUpwardAcceleration() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(0.5f);

        // The first tick starts on the ground, where gravity is compensated.
        assertEquals(0.0, lander.getPosition().getX(), EPSILON);
        assertEquals(2.296875, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getX(), EPSILON);
        assertEquals(9.1875, lander.getVelocity().getY(), EPSILON);
        assertEquals(0.0f, lander.getRotation(), EPSILON);
    }

    @Test
    public void engineControlsRotateInOppositeDirections() {
        RocketLander left = new RocketLander();
        left.setBurnLeft(true);
        left.setBurnRight(true);
        left.tick(0.5f);
        left.setBurnRight(false);
        left.tick(0.5f);

        RocketLander right = new RocketLander();
        right.setBurnLeft(true);
        right.setBurnRight(true);
        right.tick(0.5f);
        right.setBurnLeft(false);
        right.tick(0.5f);

        assertEquals(-Math.toRadians(5), left.getRotation(), EPSILON);
        assertEquals(Math.toRadians(5), right.getRotation(), EPSILON);
    }

    @Test
    public void staticVectorHelpersComputeExpectedResults() {
        Point2D position = RocketLander.positionAfter(
                2.0f, new Point2D.Float(1.0f, 2.0f),
                new Point2D.Float(3.0f, 4.0f), new Point2D.Float(2.0f, -2.0f));
        assertEquals(11.0, position.getX(), EPSILON);
        assertEquals(6.0, position.getY(), EPSILON);

        Point2D velocity = RocketLander.velocityAfter(
                2.0f, new Point2D.Float(3.0f, 4.0f), new Point2D.Float(2.0f, -2.0f));
        assertEquals(7.0, velocity.getX(), EPSILON);
        assertEquals(0.0, velocity.getY(), EPSILON);

        Point2D sum = RocketLander.add(
                new Point2D.Float(1.0f, 2.0f), new Point2D.Float(3.0f, -4.0f));
        assertEquals(4.0, sum.getX(), EPSILON);
        assertEquals(-2.0, sum.getY(), EPSILON);

        Point2D thrust = RocketLander.thrustVector((float) (Math.PI / 2), 10.0f);
        assertEquals(-10.0, thrust.getX(), EPSILON);
        assertEquals(0.0, thrust.getY(), EPSILON);
    }

    @Test
    public void landingResetsVelocityRotationAndEngineState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        // A one-second powered tick gives the lander an upward velocity of
        // 18.375 m/s. With engines off, it returns to the ground after about
        // 22.6 seconds. Use small steps so the landing speed stays safe.
        lander.tick(1.0f);
        lander.setBurnLeft(false);
        lander.setBurnRight(false);

        // The safe-landing threshold is 3 m/s downward. Stop just before
        // crossing it, then use a final step that lands below that threshold.
        for (int i = 0; i < 95; i++) {
            lander.tick(0.1f);
        }
        assertFalse(lander.isOnGround());

        lander.tick(0.1f);

        assertTrue(lander.isOnGround());
        assertFalse(lander.crashed());
        assertEquals(0.0, lander.getVelocity().getX(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);
        assertEquals(0.0f, lander.getRotation(), EPSILON);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
    }

    @Test
    public void crashStopsLanderAndSubsequentTicksDoNotChangeState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(1.0f);
        lander.setBurnLeft(false);
        lander.setBurnRight(false);

        // Advance in steps so the lander crosses the ground while descending
        // faster than the safe-landing threshold.
        for (int i = 0; i < 20 && !lander.crashed(); i++) {
            lander.tick(1.0f);
        }

        assertTrue(lander.crashed());
        assertEquals(-1.0, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getX(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);

        Point2D position = (Point2D) lander.getPosition().clone();
        Point2D velocity = (Point2D) lander.getVelocity().clone();
        float rotation = lander.getRotation();
        lander.tick(1.0f);

        assertEquals(position.getX(), lander.getPosition().getX(), EPSILON);
        assertEquals(position.getY(), lander.getPosition().getY(), EPSILON);
        assertEquals(velocity.getX(), lander.getVelocity().getX(), EPSILON);
        assertEquals(velocity.getY(), lander.getVelocity().getY(), EPSILON);
        assertEquals(rotation, lander.getRotation(), EPSILON);
    }
}
