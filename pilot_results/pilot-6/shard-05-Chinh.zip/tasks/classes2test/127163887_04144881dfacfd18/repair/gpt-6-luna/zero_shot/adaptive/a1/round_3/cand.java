package com.batalov.RL;

import java.awt.geom.Point2D;
import org.junit.Test;
import static org.junit.Assert.*;

public class RocketLander_ArrowTest {

    private static final float EPSILON = 1.0e-5f;

    @Test
    public void startsAtRestOnTheGroundWithEnginesOff() {
        RocketLander lander = new RocketLander();

        assertEquals(0.0, lander.getPosition().getX(), EPSILON);
        assertEquals(0.0, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getX(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);
        assertEquals(0.0f, lander.getRotation(), EPSILON);
        assertTrue(lander.isOnGround());
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertFalse(lander.crashed());
    }

    @Test
    public void settersAndStringRepresentationReflectEngineState() {
        RocketLander lander = new RocketLander();

        lander.setBurnLeft(true);
        lander.setBurnRight(false);

        assertTrue(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertTrue(lander.toString().startsWith("< * -- . >"));

        lander.setBurnLeft(false);
        lander.setBurnRight(true);
        assertTrue(lander.toString().startsWith("< . -- * >"));
    }

    @Test
    public void bothEnginesProduceUpwardThrustAndRotateTheLander() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(0.1f);

        // Both engines provide 20 m/s² of thrust; gravity reduces the net
        // acceleration to 18.375 m/s².
        assertEquals(0.0, lander.getPosition().getX(), EPSILON);
        assertEquals(0.091875, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getX(), EPSILON);
        assertEquals(1.8375, lander.getVelocity().getY(), EPSILON);
        assertEquals(0.0f, lander.getRotation(), EPSILON);
        assertFalse(lander.isOnGround());
    }

    @Test
    public void singleEngineOnGroundDoesNotLiftOff() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);

        lander.tick(0.1f);

        assertTrue(lander.isOnGround());
        assertEquals(0.0, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);
        // A single engine rotates the lander, but does not provide thrust.
        assertEquals(0.0f, lander.getRotation(), EPSILON);
    }

    @Test
    public void enginesOffApplyGravityAndLandingResetsVelocityAndRotation() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(0.1f);
        lander.setBurnLeft(false);
        lander.setBurnRight(false);

        // Gravity brings the lander back to the ground during this interval.
        lander.tick(1.0f);

        assertTrue(lander.isOnGround());
        assertEquals(0.0, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);
        assertEquals(0.0f, lander.getRotation(), EPSILON);
        assertFalse(lander.crashed());
    }

    @Test
    public void crashStopsTheRocketAndSubsequentTicksDoNotChangeItsState() {
        RocketLander lander = new RocketLander();
        lander.getPosition().setLocation(0.0, 0.1);
        lander.getVelocity().setLocation(0.0, -4.0);

        lander.tick(0.1f);

        // The tick advances the rocket to y = -0.308125. The crash check
        // stops it there; the one-meter clamp applies only below y = -1.
        assertTrue(lander.crashed());
        assertEquals(-0.308125, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getX(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());

        Point2D position = (Point2D) lander.getPosition().clone();
        Point2D velocity = (Point2D) lander.getVelocity().clone();
        float rotation = lander.getRotation();

        lander.tick(1.0f);

        assertEquals(position, lander.getPosition());
        assertEquals(velocity, lander.getVelocity());
        assertEquals(rotation, lander.getRotation(), EPSILON);
    }

    @Test
    public void staticPhysicsHelpersComputeExpectedVectors() {
        Point2D position = new Point2D.Float(1.0f, 2.0f);
        Point2D velocity = new Point2D.Float(3.0f, 4.0f);
        Point2D acceleration = new Point2D.Float(2.0f, -2.0f);

        assertEquals(new Point2D.Float(4.0f, 4.0f),
                RocketLander.positionAfter(1.0f, position, velocity, acceleration));
        assertEquals(new Point2D.Float(5.0f, 2.0f),
                RocketLander.velocityAfter(1.0f, velocity, acceleration));
        assertEquals(new Point2D.Float(4.0f, 2.0f),
                RocketLander.add(position, velocity));
        assertEquals(new Point2D.Float(0.0f, 10.0f),
                RocketLander.thrustVector(0.0f, 10.0f));
    }

    @Test
    public void checkLandedResetsStateWhenAtOrBelowGround() {
        RocketLander lander = new RocketLander();
        lander.getPosition().setLocation(7.0, -0.1);
        lander.getVelocity().setLocation(2.0, -1.0);
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        assertTrue(lander.checkLanded());

        assertEquals(7.0, lander.getPosition().getX(), EPSILON);
        assertEquals(0.0, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getX(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);
        assertEquals(0.0f, lander.getRotation(), EPSILON);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
    }

    @Test
    public void safeDescentCanLandWithoutCrashing() {
        RocketLander lander = new RocketLander();
        lander.getPosition().setLocation(0.0, 0.1);
        lander.getVelocity().setLocation(0.0, -0.1);

        lander.tick(1.0f);

        assertTrue(lander.isOnGround());
        assertFalse(lander.crashed());
        assertEquals(0.0, lander.getPosition().getY(), EPSILON);
        assertEquals(0.0, lander.getVelocity().getY(), EPSILON);
    }
}
