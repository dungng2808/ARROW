package com.thealgorithms.others;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class StackPostfixNotation_ArrowTest {

    @Test
    void evaluatesIntegerOperands() {
        assertEquals(42, StackPostfixNotation.postfixEvaluate("6 7 *"));
    }

    @Test
    void evaluatesAdditionSubtractionMultiplicationAndDivision() {
        assertEquals(5, StackPostfixNotation.postfixEvaluate("20 3 - 2 /"));
        assertEquals(14, StackPostfixNotation.postfixEvaluate("2 3 4 * +"));
        assertEquals(2, StackPostfixNotation.postfixEvaluate("8 3 - 5 + 3 /"));
    }

    @Test
    void divisionUsesIntegerArithmetic() {
        assertEquals(2, StackPostfixNotation.postfixEvaluate("7 3 /"));
    }

    @Test
    void rejectsOperatorWithTooFewOperands() {
        assertThrows(
                IllegalArgumentException.class,
                () -> StackPostfixNotation.postfixEvaluate("1 +"));
    }

    @Test
    void rejectsExpressionWithExtraOperands() {
        assertThrows(
                IllegalArgumentException.class,
                () -> StackPostfixNotation.postfixEvaluate("1 2"));
    }

    @Test
    void rejectsUnknownOperation() {
        assertThrows(
                IllegalArgumentException.class,
                () -> StackPostfixNotation.postfixEvaluate("1 2 %"));
    }

    @Test
    void propagatesDivisionByZero() {
        assertThrows(
                ArithmeticException.class,
                () -> StackPostfixNotation.postfixEvaluate("1 0 /"));
    }
}
