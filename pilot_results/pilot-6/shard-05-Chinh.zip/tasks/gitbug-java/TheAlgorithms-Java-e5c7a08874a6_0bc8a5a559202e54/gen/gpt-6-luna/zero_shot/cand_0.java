package com.thealgorithms.others;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class StackPostfixNotation_ArrowTest {

    @Test
    void evaluatesSingleInteger() {
        assertEquals(42, StackPostfixNotation.postfixEvaluate("42"));
    }

    @Test
    void evaluatesAddition() {
        assertEquals(7, StackPostfixNotation.postfixEvaluate("3 4 +"));
    }

    @Test
    void evaluatesSubtractionInOperandOrder() {
        assertEquals(5, StackPostfixNotation.postfixEvaluate("9 4 -"));
    }

    @Test
    void evaluatesMultiplication() {
        assertEquals(42, StackPostfixNotation.postfixEvaluate("6 7 *"));
    }

    @Test
    void evaluatesIntegerDivision() {
        assertEquals(3, StackPostfixNotation.postfixEvaluate("7 2 /"));
    }

    @Test
    void evaluatesCompoundExpression() {
        assertEquals(14, StackPostfixNotation.postfixEvaluate("2 3 4 * +"));
    }

    @Test
    void rejectsOperatorWithTooFewArguments() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("1 +"));
    }

    @Test
    void rejectsExpressionWithExtraOperands() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("1 2"));
    }

    @Test
    void rejectsUnknownOperator() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("1 2 %"));
    }

    @Test
    void rejectsEmptyExpression() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate(""));
    }
}
