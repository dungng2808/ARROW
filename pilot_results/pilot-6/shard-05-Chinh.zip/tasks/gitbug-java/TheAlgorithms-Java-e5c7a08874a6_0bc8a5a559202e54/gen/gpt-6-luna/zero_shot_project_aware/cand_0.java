package com.thealgorithms.others;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class StackPostfixNotation_ArrowTest {

    @Test
    void evaluatesSingleInteger() {
        assertEquals(42, StackPostfixNotation.postfixEvaluate("42"));
    }

    @Test
    void evaluatesAdditionSubtractionMultiplicationAndDivision() {
        assertEquals(14, StackPostfixNotation.postfixEvaluate("2 3 + 4 * 2 /"));
        assertEquals(5, StackPostfixNotation.postfixEvaluate("9 4 -"));
        assertEquals(24, StackPostfixNotation.postfixEvaluate("6 4 *"));
        assertEquals(3, StackPostfixNotation.postfixEvaluate("7 2 /"));
    }

    @Test
    void evaluatesNegativeOperands() {
        assertEquals(-5, StackPostfixNotation.postfixEvaluate("-2 3 -"));
    }

    @Test
    void rejectsAnOperatorWithTooFewArguments() {
        IllegalArgumentException exception =
            assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("1 +"));
        assertEquals("exp is not a proper postfix expression (too few arguments).", exception.getMessage());
    }

    @Test
    void rejectsUnknownOperations() {
        IllegalArgumentException exception =
            assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("1 2 %"));
        assertEquals("exp contains an unknown operation.", exception.getMessage());
    }

    @Test
    void rejectsExpressionsWithExtraValues() {
        IllegalArgumentException exception =
            assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("1 2"));
        assertEquals("exp is not a proper postfix expression.", exception.getMessage());
    }

    @Test
    void rejectsEmptyExpression() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate(""));
    }
}
