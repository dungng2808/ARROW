package com.intuit.karate.core;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Tags_ArrowTest {

    private Tags tags(String... expressions) {
        return new Tags(Tag.toTags(Arrays.asList(expressions)));
    }

    @Test
    public void parsesTagNamesAndValuesAndSupportsPrefixLookup() {
        Tags tags = tags("@smoke", "@env=dev,qa");

        assertEquals(Arrays.asList("smoke", "env=dev,qa"), tags.getTags());
        assertTrue(tags.contains("@smoke"));
        assertTrue(tags.contains("smoke"));
        assertEquals(Arrays.asList("dev", "qa"), tags.valuesFor("env").values);
        assertTrue(tags.valuesFor("@env").isAnyOf("qa"));
        assertTrue(tags.valuesFor("env").isAllOf("dev", "qa"));
        assertTrue(tags.valuesFor("env").isOnly("dev", "qa"));
        assertFalse(tags.valuesFor("env").isOnly("dev"));
    }

    @Test
    public void evaluatesSelectorsAndEnvironmentRestrictions() {
        Tags tags = tags("@smoke", "@env=dev,qa", "@region=west");

        assertTrue(tags.evaluate("anyOf('@smoke') && allOf('@region')", null));
        assertTrue(tags.evaluate("valuesFor('env').isAnyOf('qa')", null));
        assertTrue(tags.evaluate(null, "dev"));
        assertFalse(tags.evaluate(null, "prod"));
        assertFalse(tags.evaluate(null, null));
    }

    @Test
    public void excludesIgnoredSetupAndDisallowedEnvironmentTags() {
        assertFalse(tags("@smoke", Tag.IGNORE).evaluate(null, null));
        assertFalse(tags("@smoke", Tag.SETUP).evaluate(null, null));
        assertFalse(tags("@smoke", "@envnot=dev").evaluate(null, "dev"));
        assertTrue(tags("@smoke", "@envnot=dev").evaluate(null, "qa"));
    }

    @Test
    public void combinesTagCollectionsWithoutDuplicates() {
        List<Tag> first = Tag.toTags(Arrays.asList("@one", "@two"));
        List<Tag> second = Tag.toTags(Arrays.asList("@two", "@three"));

        Tags merged = Tags.merge(first, null, second);

        assertEquals(3, merged.getTags().size());
        assertTrue(merged.contains("@one"));
        assertTrue(merged.contains("@two"));
        assertTrue(merged.contains("@three"));
    }

    @Test
    public void convertsLegacyTagOptionsToExpressions() {
        assertNull(Tags.fromKarateOptionsTags((String[]) null));
        assertNull(Tags.fromKarateOptionsTags(Collections.<String>emptyList()));
        assertEquals("anyOf('a','b') && not('c')",
                Tags.fromKarateOptionsTags("a, b", "~c"));
        assertEquals("tag('new')", Tags.fromKarateOptionsTags("tag('new')"));
    }

    @Test
    public void nullInputCreatesEmptyTags() {
        Tags tags = new Tags(null);

        assertTrue(tags.getTags().isEmpty());
        assertTrue(tags.getOriginal().isEmpty());
        assertFalse(tags.valuesFor("missing").isPresent());
        assertFalse(tags.contains("@missing"));
        assertEquals("[]", tags.toString());
    }
}
