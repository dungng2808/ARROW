package com.thealgorithms.others;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

public class StackPostfixNotation_ArrowTest {

    @Test
    public void evaluatesPostfixExpressionWithMultipleOperators() {
        // Arrange
        String expression = "12 3 4 * + 2 /";

        // Act
        int result = StackPostfixNotation.postfixEvaluate(expression);

        // Assert
        assertThat(result).isEqualTo(12);
    }

    @Test
    public void evaluatesSubtractionInOperandOrder() {
        // Arrange
        String expression = "10 3 -";

        // Act
        int result = StackPostfixNotation.postfixEvaluate(expression);

        // Assert
        assertThat(result).isEqualTo(7);
    }

    @Test
    public void evaluatesIntegerDivision() {
        // Arrange
        String expression = "7 2 /";

        // Act
        int result = StackPostfixNotation.postfixEvaluate(expression);

        // Assert
        assertThat(result).isEqualTo(3);
    }

    @Test
    public void rejectsOperatorWithTooFewOperands() {
        assertThatThrownBy(() -> StackPostfixNotation.postfixEvaluate("5 +"))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("exp is not a proper postfix expression (too few arguments).");
    }

    @Test
    public void rejectsUnknownOperator() {
        assertThatThrownBy(() -> StackPostfixNotation.postfixEvaluate("2 3 %"))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("exp contains an unknown operation.");
    }

    @Test
    public void rejectsExpressionWithMultipleRemainingOperands() {
        assertThatThrownBy(() -> StackPostfixNotation.postfixEvaluate("2 3"))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("exp is not a proper postfix expression.");
    }

    @Test
    public void rejectsEmptyExpression() {
        assertThatThrownBy(() -> StackPostfixNotation.postfixEvaluate(""))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("exp is not a proper postfix expression.");
    }
}
