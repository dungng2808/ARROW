package com.intuit.karate.core;

import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Tags_ArrowTest {

    private Tag tag(int line, String text) {
        return new Tag(line, text);
    }

    @Test
    public void emptyTagsHaveNoValuesAndDoNotMatch() {
        Tags tags = new Tags(Collections.<Tag>emptyList());

        assertTrue(tags.getTags().isEmpty());
        assertFalse(tags.contains("@smoke"));
        assertFalse(tags.anyOf("@smoke"));
        assertTrue(tags.allOf());
        assertTrue(tags.not("@smoke"));
        assertTrue(tags.evaluate(null, null));
        assertFalse(tags.valuesFor("smoke").isPresent());
    }

    @Test
    public void tagQueriesAcceptNamesWithOrWithoutPrefix() {
        Tags tags = new Tags(Arrays.asList(
                tag(1, "@smoke"),
                tag(2, "@team=qa,dev")));

        assertTrue(tags.contains("@smoke"));
        assertTrue(tags.contains("smoke"));
        assertTrue(tags.anyOf("@missing", "smoke"));
        assertTrue(tags.allOf("@smoke", "team=qa,dev"));
        assertFalse(tags.anyOf("@missing"));
        assertFalse(tags.allOf("smoke", "missing"));
        assertEquals(Arrays.asList("qa", "dev"), tags.valuesFor("@team").values);
        assertTrue(tags.valuesFor("team").isAnyOf("dev"));
        assertTrue(tags.valuesFor("team").isAllOf("qa", "dev"));
        assertTrue(tags.valuesFor("team").isOnly("qa", "dev"));
        assertFalse(tags.valuesFor("team").isOnly("qa"));
    }

    @Test
    public void evaluateHonorsEnvironmentAndSpecialTags() {
        Tags envTags = new Tags(Arrays.asList(
                tag(1, "@env=dev,qa"),
                tag(2, "@envnot=prod")));

        assertTrue(envTags.evaluate(null, "dev"));
        assertFalse(envTags.evaluate(null, "prod"));
        assertFalse(envTags.evaluate(null, null));
        assertFalse(envTags.evaluate(null, "test"));

        assertFalse(new Tags(Arrays.asList(tag(3, "@ignore"))).evaluate(null, null));
        assertFalse(new Tags(Arrays.asList(tag(4, "@setup"))).evaluate(null, null));
    }

    @Test
    public void optionTagsAreConvertedToExpressions() {
        assertNull(Tags.fromKarateOptionsTags((String[]) null));
        assertNull(Tags.fromKarateOptionsTags(Collections.<String>emptyList()));
        assertEquals("anyOf('smoke, fast') && not('slow')",
                Tags.fromKarateOptionsTags("smoke, fast", "~slow"));
        assertEquals("anyOf('smoke')", Tags.fromKarateOptionsTags(Arrays.asList("smoke")));
        assertEquals("anyOf('smoke') || anyOf('fast')",
                Tags.fromKarateOptionsTags("anyOf('smoke') || anyOf('fast')"));
    }

    @Test
    public void mergeCombinesTagsWithoutDuplicates() {
        Tag smoke = tag(1, "@smoke");
        Tags merged = Tags.merge(Arrays.asList(smoke, tag(2, "@fast")),
                null, Arrays.asList(smoke, tag(3, "@api")));

        assertEquals(3, merged.getTags().size());
        assertTrue(merged.contains("smoke"));
        assertTrue(merged.contains("fast"));
        assertTrue(merged.contains("api"));
    }
}
