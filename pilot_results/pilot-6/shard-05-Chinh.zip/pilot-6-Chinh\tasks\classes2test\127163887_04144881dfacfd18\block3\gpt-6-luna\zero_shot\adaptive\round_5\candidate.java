package com.batalov.RL;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class RocketLander_ArrowTest {

    @Test
    public void newLanderStartsAtRestOnGround() {
        RocketLander lander = new RocketLander();

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.isOnGround());
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertFalse(lander.crashed());
    }

    @Test
    public void unpoweredLanderRemainsAtRestOnGround() {
        RocketLander lander = new RocketLander();

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertTrue(lander.isOnGround());
        assertFalse(lander.crashed());
    }

    @Test
    public void dualEnginesLiftLanderAndUpdateVelocity() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(0.5f);

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(2.296875, lander.getPosition().getY(), 0.000001);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(9.1875, lander.getVelocity().getY(), 0.000001);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.getBurnLeft());
        assertTrue(lander.getBurnRight());
        assertFalse(lander.isOnGround());
    }

    @Test
    public void singleEngineRotatesWithoutProvidingThrust() {
        RocketLander lander = new RocketLander();
        lander.setBurnRight(true);

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals((float) Math.toRadians(10), lander.getRotation(), 0.000001f);
        assertTrue(lander.getBurnRight());
        assertFalse(lander.getBurnLeft());
    }

    @Test
    public void crashStopsRocketAndSubsequentTicksDoNotChangeState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(1.0f);
        lander.setBurnLeft(false);
        lander.setBurnRight(false);
        lander.tick(2.0f);

        assertTrue(lander.crashed());
        assertEquals(-1.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());

        double xBefore = lander.getPosition().getX();
        double yBefore = lander.getPosition().getY();
        double velocityXBefore = lander.getVelocity().getX();
        double velocityYBefore = lander.getVelocity().getY();
        float rotationBefore = lander.getRotation();

        lander.tick(1.0f);

        assertEquals(xBefore, lander.getPosition().getX(), 0.0);
        assertEquals(yBefore, lander.getPosition().getY(), 0.0);
        assertEquals(velocityXBefore, lander.getVelocity().getX(), 0.0);
        assertEquals(velocityYBefore, lander.getVelocity().getY(), 0.0);
        assertEquals(rotationBefore, lander.getRotation(), 0.0f);
    }

    @Test
    public void toStringIncludesEngineStateAndFlightState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.tick(0.5f);

        assertEquals("< . -- . >, p = [0.000000, 0.000000], v = [0.000000, 0.000000], r = 0.000000",
                lander.toString());
    }
}
