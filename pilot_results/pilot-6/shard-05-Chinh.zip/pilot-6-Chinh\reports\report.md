# Báo cáo ARROW: pilot-v1

## Thông tin run

- Run `pilot-6-Chinh`: experiment sha256 `45189e747717`, máy `Chinh` (win-x64), tool 0.1.0 commit `3976205273471ed39766d5bba4ebd917a3c7a457`, tạo lúc 2026-10-15 14:29
- Model id trả về: gpt-6-luna → gpt-6-luna

## Khối 1: task dùng được và bị loại

- classes2test: 9 dùng được, 0 bị loại, 0 INFRA
- gitbug-java: 1 dùng được, 0 bị loại, 0 INFRA

## RQ1: tính hợp lệ của candidate ban đầu (6.1)

Classes2Test (content-matched) và GitBug-Java (upstream-pinned) báo cáo tách riêng. Mẫu số gồm cả output không hợp lệ, không gồm INFRA.

| dataset | model | strategy | candidates | compile | discovery | execution | target_pass | valid | invalid_output | infra |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | few_shot | 9 | 4 | 4 | 4 | 4 | 4 | 0 | 0 |
| classes2test | gpt-6-luna | zero_shot | 9 | 7 | 7 | 7 | 5 | 5 | 0 | 0 |
| classes2test | gpt-6-luna | zero_shot_project_aware | 9 | 8 | 8 | 8 | 4 | 4 | 0 | 0 |
| gitbug-java | gpt-6-luna | few_shot | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| gitbug-java | gpt-6-luna | zero_shot | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| gitbug-java | gpt-6-luna | zero_shot_project_aware | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 |

## RQ2: hiệu quả sửa (6.2)

Chỉ tính candidate mà mọi cơ chế đều chạy xong. Chain không thành công tính bằng N.

| dataset | model | mechanism | chains | success | success_rate | attempts_mean | attempts_median | time_mean_s | time_median_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | adaptive | 14 | 12 | 0.8571 | 4 | 3.5 | 125.7 | 103.4 |
| classes2test | gpt-6-luna | fixed | 14 | 10 | 0.7143 | 4.5 | 2.5 | 166.9 | 71.4 |

## RQ2: số lần kích hoạt các cơ chế (mô tả, không chứng minh nhân quả)

| dataset | model | mechanism | rollback | duplicate_code | invalid_output | repeated_signature | level_up | state_change | level3_rounds | dropped_methods |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | adaptive | 5 | 8 | 0 | 8 | 19 | 17 | 7 | 4 |
| classes2test | gpt-6-luna | fixed | 0 | 0 | 0 | 0 | 0 | 15 | 0 | 6 |

## Chọn N (pilot, 6.3): N = 9

S(k) gộp chain của cả hai cơ chế trên Classes2Test; pilot không xem kết quả so sánh hai cơ chế.

| round | successes_cumulative | share_of_round_n |
| --- | --- | --- |
| 1 | 9 | 0.4091 |
| 2 | 13 | 0.5909 |
| 3 | 15 | 0.6818 |
| 4 | 17 | 0.7727 |
| 5 | 20 | 0.9091 |
| 6 | 21 | 0.9545 |
| 7 | 22 | 1 |
| 8 | 22 | 1 |
| 9 | 22 | 1 |
| 10 | 22 | 1 |

## Độ nhạy P của dừng sớm (6.4)

Tính lại từ decision.json, không gọi thêm model.

| dataset | model | p | chains | success | success_rate | rounds_mean | time_mean_s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | 1 | 14 | 7 | 0.5 | 1.64 | 47.1 |
| classes2test | gpt-6-luna | 2 | 14 | 7 | 0.5 | 2.29 | 63.6 |
| classes2test | gpt-6-luna | 3 | 14 | 8 | 0.5714 | 3 | 88.4 |
| classes2test | gpt-6-luna | none | 14 | 12 | 0.8571 | 4 | 125.7 |

## RQ3: chất lượng bộ test VALID (6.5)

Ghép cặp theo từng chỉ số; n_pairs riêng cho mỗi chỉ số.

| dataset | model | metric | n_pairs | arrow_mean | evosuite_mean | arrow_median | evosuite_median | mean_diff | arrow_sd | evosuite_sd |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | line | 3 | 0.7605 | 0 | 0.8182 | 0 | 0.7605 | 0.1715 | 0 |
| classes2test | gpt-6-luna | branch | 3 | 0.7119 | 0 | 0.7069 | 0 | 0.7119 | 0.1356 | 0 |
| classes2test | gpt-6-luna | method | 3 | 0.8253 | 0 | 0.9 | 0 | 0.8253 | 0.1374 | 0 |
| classes2test | gpt-6-luna | mutation_score | 0 |  |  |  |  |  |  |  |
| classes2test | gpt-6-luna | smell_density | 3 | 7.0556 | 4.2771 | 4.1667 | 3.6429 | 2.7785 | 5.1487 | 1.5518 |
| gitbug-java | gpt-6-luna | line | 0 |  |  |  |  |  |  |  |
| gitbug-java | gpt-6-luna | branch | 0 |  |  |  |  |  |  |  |
| gitbug-java | gpt-6-luna | method | 0 |  |  |  |  |  |  |  |
| gitbug-java | gpt-6-luna | mutation_score | 0 |  |  |  |  |  |  |  |
| gitbug-java | gpt-6-luna | smell_density | 0 |  |  |  |  |  |  |  |

## RQ3: tập so sánh

| dataset | model | both | only_arrow | only_evosuite | dropped_line | dropped_branch | dropped_method | dropped_mutation_score | dropped_smell_density |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | 3 | 5 | 0 | 0 | 0 | 0 | 3 | 0 |
| gitbug-java | gpt-6-luna | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |

## Chi phí (6.6)

| dataset | block | llm_calls | tokens_in | tokens_out | cost_usd | finish_length |
| --- | --- | --- | --- | --- | --- | --- |
| classes2test | 2 | 27 | 70183 | 18318 | 0.0081 | 0 |
| classes2test | 3 | 119 | 501378 | 114265 | 0.0536 | 0 |
| gitbug-java | 2 | 3 | 4900 | 1191 | 0.0005 | 0 |
| gitbug-java | 3 | 0 | 0 | 0 | 0 | 0 |

## Thời gian từng bước (6.6)

| step | count | median_s | p90_s | max_s |
| --- | --- | --- | --- | --- |
| llm | 149 | 8.3 | 24.1 | 167 |
| verify_build | 141 | 16.6 | 36.5 | 82.1 |
| evosuite | 10 | 133.7 | 306.4 | 1213.1 |
| jacoco | 39 | 22.4 | 35 | 47.5 |
| pit | 39 | 16 | 25.8 | 46.8 |
| tsdetect | 39 | 2.4 | 6.5 | 18.9 |

## Task bị loại

(không có dữ liệu)

## Cần chạy lại riêng

Danh sách rỗng: run hoàn chỉnh.

(không có dữ liệu)
## Ngoại lệ đã khai báo

- Cờ build chung tắt checkstyle, spotless, enforcer, JaCoCo của dự án…; JVM chạy với `-Dfile.encoding=UTF-8 -Duser.language=en -Duser.country=US -Duser.timezone=UTC`.
- Bộ EvoSuite cần `evosuite-standalone-runtime` trong classpath test (Maven: dependency scope `system` chỉ trong bản sao; Gradle: init script).
- JaCoCo gắn qua `JAVA_TOOL_OPTIONS` với `includes=<FQN>:<FQN>$*`; PIT dùng `--targetClasses <FQN>,<FQN>$*`.

## Hạn chế

- Thực nghiệm chạy một lần cho mỗi cấu hình; các con số cơ chế là thống kê mô tả.
- Commit của Classes2Test là content-matched: tái lập được nhưng không bảo đảm là commit tác giả dataset đã dùng.
