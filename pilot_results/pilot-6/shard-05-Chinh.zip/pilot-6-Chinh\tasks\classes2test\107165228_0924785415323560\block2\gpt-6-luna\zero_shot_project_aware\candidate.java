package com.devskiller.jpa2ddl;

import org.junit.Test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class FileResolver_ArrowTest {

    @Test
    public void resolveNextMigrationFileUsesHighestExistingVersion() throws Exception {
        Path directory = Files.createTempDirectory("file-resolver");
        try {
            Files.createFile(directory.resolve("v2__initial.sql"));
            Files.createFile(directory.resolve("v10__update.sql"));
            Files.createFile(directory.resolve("notes.txt"));

            File next = FileResolver.resolveNextMigrationFile(directory.toFile());

            assertThat(next).isEqualTo(directory.resolve("v11__jpa2ddl.sql").toFile());
        } finally {
            deleteRecursively(directory);
        }
    }

    @Test
    public void resolveNextMigrationFileStartsAtOneWhenDirectoryIsEmpty() throws Exception {
        Path directory = Files.createTempDirectory("file-resolver");
        try {
            File next = FileResolver.resolveNextMigrationFile(directory.toFile());

            assertThat(next).isEqualTo(directory.resolve("v1__jpa2ddl.sql").toFile());
        } finally {
            deleteRecursively(directory);
        }
    }

    @Test
    public void resolveExistingMigrationsSortsByVersionAndCanFilterSchemaMigrations() throws Exception {
        Path directory = Files.createTempDirectory("file-resolver");
        try {
            Files.createFile(directory.resolve("v3__jpa2ddl.sql"));
            Files.createFile(directory.resolve("v1__jpa2ddl-init.sql"));
            Files.createFile(directory.resolve("v2__feature.sql"));
            Files.createFile(directory.resolve("readme.txt"));

            List<Path> allAscending = FileResolver.resolveExistingMigrations(directory.toFile(), false, false);
            assertThat(allAscending)
                    .containsExactly(
                            directory.resolve("readme.txt"),
                            directory.resolve("v1__jpa2ddl-init.sql"),
                            directory.resolve("v2__feature.sql"),
                            directory.resolve("v3__jpa2ddl.sql"));

            List<Path> schemaDescending = FileResolver.resolveExistingMigrations(directory.toFile(), true, true);
            assertThat(schemaDescending)
                    .containsExactly(
                            directory.resolve("v3__jpa2ddl.sql"),
                            directory.resolve("v1__jpa2ddl-init.sql"));
        } finally {
            deleteRecursively(directory);
        }
    }

    @Test
    public void resolveExistingMigrationsCreatesMissingDirectory() throws Exception {
        Path parent = Files.createTempDirectory("file-resolver");
        Path missing = parent.resolve("new-migrations");
        try {
            List<Path> migrations = FileResolver.resolveExistingMigrations(missing.toFile(), false, false);

            assertThat(migrations).isEmpty();
            assertThat(Files.isDirectory(missing)).isTrue();
        } finally {
            deleteRecursively(parent);
        }
    }

    @Test
    public void listClassNamesInPackageFindsClassesInCurrentPackage() throws Exception {
        List<String> classNames = FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl");

        assertThat(classNames).contains("com.devskiller.jpa2ddl.FileResolver");
    }

    @Test(expected = IllegalStateException.class)
    public void listClassNamesInPackageRejectsMissingPackage() throws Exception {
        FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl.package_that_does_not_exist");
    }

    private static void deleteRecursively(Path path) throws Exception {
        if (!Files.exists(path)) {
            return;
        }
        try (java.util.stream.Stream<Path> paths = Files.walk(path)) {
            paths.sorted((left, right) -> right.getNameCount() - left.getNameCount())
                    .forEach(item -> {
                        try {
                            Files.deleteIfExists(item);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
        }
    }
}
