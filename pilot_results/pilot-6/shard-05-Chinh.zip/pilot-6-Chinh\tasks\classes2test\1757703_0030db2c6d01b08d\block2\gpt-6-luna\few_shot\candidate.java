package net.ontopia.presto.spi.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

public class Utils_ArrowTest {

    @Test
    public void equalsAndDifferentHandleNullAndEqualValues() {
        assertTrue(Utils.equals(null, null));
        assertFalse(Utils.different(null, null));
        assertFalse(Utils.equals(null, "value"));
        assertTrue(Utils.different(null, "value"));
        assertTrue(Utils.equals("value", new String("value")));
        assertFalse(Utils.different("value", new String("value")));
        assertFalse(Utils.equals("value", "other"));
        assertTrue(Utils.different("value", "other"));
    }

    @Test
    public void compareComparablesHandlesOrderingNullsAndDirection() {
        assertTrue(Utils.compareComparables("a", "b") < 0);
        assertTrue(Utils.compareComparables("b", "a") > 0);
        assertEquals(0, Utils.compareComparables("same", "same"));
        assertTrue(Utils.compareComparables(null, "a") < 0);
        assertTrue(Utils.compareComparables("a", null) > 0);
        assertEquals(0, Utils.compareComparables(null, null));

        assertTrue(Utils.compareComparables("a", "b", false) > 0);
        assertTrue(Utils.compareComparables("b", "a", false) < 0);
        assertEquals(0, Utils.compareComparables(null, null, false));

        assertTrue(Utils.compareComparables("a", "b", (left, right) -> right.compareTo(left)) > 0);
        assertTrue(Utils.compareComparables(null, "a", (left, right) -> left.compareTo(right)) < 0);
    }

    @Test
    public void validateNotNullAcceptsValuesAndRejectsNull() {
        Utils.validateNotNull("present");
        NullPointerException exception =
                assertThrows(NullPointerException.class, () -> Utils.validateNotNull(null));
        assertEquals("Object cannot be null", exception.getMessage());
    }

    @Test
    public void getNameUsesStringRepresentationForNonTopicsAndNull() {
        assertEquals("value", Utils.getName("value"));
        assertEquals("null", Utils.getName((Object) null));
        assertEquals("null", Utils.getName(null, null));
        assertEquals("42", Utils.getName(null, 42));
    }

    @Test
    public void moveValuesToIndexMovesExistingValuesAndLeavesInputUnchanged() {
        List<String> values = Arrays.asList("a", "b", "c", "d");
        List<String> moved = Arrays.asList("b", "d");

        List<String> result = Utils.moveValuesToIndex(values, moved, 3, false);

        assertEquals(Arrays.asList("a", "c", "b", "d"), result);
        assertEquals(Arrays.asList("a", "b", "c", "d"), values);
        assertNotSame(values, result);
    }

    @Test
    public void moveValuesToIndexAllowsAddingAndHandlesEmptyMoves() {
        List<String> values = Arrays.asList("a", "b");
        assertEquals(Arrays.asList("a", "x", "b"),
                Utils.moveValuesToIndex(values, Collections.singletonList("x"), 1, true));
        assertEquals(values, Utils.moveValuesToIndex(values, Collections.<String>emptyList(), 1, false));
    }

    @Test
    public void moveValuesToIndexRejectsInvalidIndexAndDisallowedNewValues() {
        List<String> values = Arrays.asList("a", "b");

        assertThrows(ArrayIndexOutOfBoundsException.class,
                () -> Utils.moveValuesToIndex(values, Collections.singletonList("a"), 3, false));
        assertThrows(RuntimeException.class,
                () -> Utils.moveValuesToIndex(values, Collections.singletonList("x"), 1, false));
    }

    @Test
    public void newInstanceOfCreatesAssignableClassAndRejectsInvalidClasses() {
        StringBuilder instance = Utils.newInstanceOf(StringBuilder.class.getName(), StringBuilder.class);
        assertEquals("", instance.toString());

        RuntimeException missing =
                assertThrows(RuntimeException.class,
                        () -> Utils.newInstanceOf("no.such.TestClass", Object.class));
        assertEquals("Class no.such.TestClass not found.", missing.getMessage());

        RuntimeException incompatible =
                assertThrows(RuntimeException.class,
                        () -> Utils.newInstanceOf(String.class.getName(), Number.class));
        assertTrue(incompatible.getMessage().contains("not assignable"));
    }
}
