package com.batalov.RL;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.awt.geom.Point2D;

import org.junit.Test;

public class RocketLander_ArrowTest {

    @Test
    public void startsAtRestWithEnginesOff() {
        RocketLander lander = new RocketLander();

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertTrue(lander.isOnGround());
    }

    @Test
    public void dualEngineBurnAcceleratesUpwardWithoutRotating() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(0.5f);

        assertEquals(0.0, lander.getPosition().getX(), 0.0001);
        assertEquals(2.296875, lander.getPosition().getY(), 0.0001);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0001);
        assertEquals(9.1875, lander.getVelocity().getY(), 0.0001);
        assertEquals(0.0f, lander.getRotation(), 0.0001f);
        assertFalse(lander.isOnGround());
    }

    @Test
    public void singleEngineBurnOnGroundRotatesWithoutLiftingOff() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);

        lander.tick(1.0f);

        assertTrue(lander.isOnGround());
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(-Math.toRadians(10.0), lander.getRotation(), 0.0001);
        assertTrue(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
    }

    @Test
    public void landingResetsVelocityRotationAndEngineState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(0.5f);
        lander.setBurnLeft(false);
        lander.setBurnRight(false);

        lander.tick(4.0f);

        assertTrue(lander.isOnGround());
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
    }

    @Test
    public void crashStopsRocketAndKeepsItAtMostOneMeterBelowGround() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(0.5f);
        lander.setBurnLeft(false);
        lander.setBurnRight(false);

        lander.tick(5.0f);

        assertTrue(lander.crashed());
        assertEquals(-1.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());

        Point2D positionAfterCrash = lander.getPosition();
        lander.tick(1.0f);
        assertEquals(positionAfterCrash, lander.getPosition());
    }

    @Test
    public void vectorHelpersComputeExpectedResults() {
        Point2D position = RocketLander.positionAfter(
                2.0f, new Point2D.Float(1.0f, 2.0f),
                new Point2D.Float(3.0f, 4.0f), new Point2D.Float(2.0f, -2.0f));
        Point2D velocity = RocketLander.velocityAfter(
                2.0f, new Point2D.Float(3.0f, 4.0f), new Point2D.Float(2.0f, -2.0f));
        Point2D sum = RocketLander.add(
                new Point2D.Float(1.0f, 2.0f), new Point2D.Float(3.0f, 4.0f));
        Point2D thrust = RocketLander.thrustVector((float) (Math.PI / 2.0), 10.0f);

        assertEquals(11.0, position.getX(), 0.0001);
        assertEquals(6.0, position.getY(), 0.0001);
        assertEquals(7.0, velocity.getX(), 0.0001);
        assertEquals(0.0, velocity.getY(), 0.0001);
        assertEquals(4.0, sum.getX(), 0.0001);
        assertEquals(6.0, sum.getY(), 0.0001);
        assertEquals(-10.0, thrust.getX(), 0.0001);
        assertEquals(0.0, thrust.getY(), 0.0001);
    }

    @Test
    public void stringRepresentationShowsEngineStates() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);

        String representation = lander.toString();

        assertTrue(representation.startsWith("< * -- ."));
        assertNotEquals("", representation);
    }
}
