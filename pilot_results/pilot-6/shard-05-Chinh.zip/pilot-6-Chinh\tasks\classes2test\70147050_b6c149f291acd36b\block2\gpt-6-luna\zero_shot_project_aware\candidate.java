package org.openape.api.databaseObjectBase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class Property_ArrowTest {

    @Test
    public void constructorsAndSettersPreserveNameAndTypedValues() {
        Property empty = new Property();
        assertNull(empty.getName());
        assertNull(empty.getValue());

        Property text = new Property("label", "hello");
        assertEquals("label", text.getName());
        assertEquals("hello", text.getValue());
        assertEquals("hello", text.getValueAsString());

        Property bool = new Property("enabled", true);
        assertEquals("enabled", bool.getName());
        assertEquals(Boolean.TRUE, bool.getValue());

        Property integer = new Property("count", 7);
        assertEquals("count", integer.getName());
        assertEquals(Integer.valueOf(7), integer.getValue());

        Property decimal = new Property("ratio", 2.5);
        assertEquals("ratio", decimal.getName());
        assertEquals(Double.valueOf(2.5), decimal.getValue());

        text.setName("title");
        text.setValueAsString("updated");
        assertEquals("title", text.getName());
        assertEquals("updated", text.getValue());
        assertEquals("updated", text.getValueAsString());
    }

    @Test
    public void descriptorsCanBeAddedAndReplaced() {
        Property property = new Property("item", "value");
        Descriptor descriptor = new Descriptor();
        property.addDescriptor(descriptor);

        assertEquals(1, property.getDescriptors().size());
        assertTrue(property.getDescriptors().contains(descriptor));

        List<Descriptor> replacement = new ArrayList<Descriptor>();
        Descriptor replacementDescriptor = new Descriptor();
        replacement.add(replacementDescriptor);
        property.setDescriptors(replacement);

        assertTrue(property.getDescriptors() == replacement);
        assertEquals(1, property.getDescriptors().size());
        assertTrue(property.getDescriptors().contains(replacementDescriptor));
    }

    @Test
    public void equalsComparesNameValueAndDescriptors() {
        Property first = new Property("color", "blue");
        Property same = new Property("color", "blue");
        Property differentName = new Property("shade", "blue");
        Property differentValue = new Property("color", "red");

        assertTrue(first.equals(same));
        assertFalse(first.equals(differentName));
        assertFalse(first.equals(differentValue));
        assertFalse(first.equals(null));
        assertFalse(first.equals("color"));

        Descriptor descriptor = new Descriptor();
        first.addDescriptor(descriptor);
        assertFalse(first.equals(same));

        same.addDescriptor(descriptor);
        assertTrue(first.equals(same));
    }

    @Test
    public void equalsHandlesNullAttributesAndEmptyDescriptors() {
        Property uninitialized = new Property();
        assertFalse(uninitialized.equals(new Property()));

        Property withNullName = new Property(null, "value");
        assertFalse(withNullName.equals(new Property(null, "value")));

        Property withNullValue = new Property("name", (String) null);
        assertFalse(withNullValue.equals(new Property("name", (String) null)));

        Property emptyDescriptors = new Property("name", "value");
        Property anotherEmptyDescriptors = new Property("name", "value");
        assertTrue(emptyDescriptors.equals(anotherEmptyDescriptors));
    }

    @Test
    public void getValueAsStringReflectsCurrentValueAndRejectsNull() {
        Property property = new Property("number", 12);
        assertEquals("12", property.getValueAsString());

        property.setValue(3.5);
        assertEquals("3.5", property.getValueAsString());

        property.setValueAsString(null);
        assertNull(property.getValue());
        try {
            property.getValueAsString();
        } catch (NullPointerException expected) {
            assertNotNull(expected);
            return;
        }
        throw new AssertionError("Expected getValueAsString to throw for a null value");
    }

    @Test
    public void equalsRequiresMatchingDescriptorContents() {
        Property first = new Property("item", "value");
        Property second = new Property("item", "value");

        Descriptor firstDescriptor = new Descriptor("key", "one");
        Descriptor secondDescriptor = new Descriptor("key", "two");
        first.addDescriptor(firstDescriptor);
        second.addDescriptor(secondDescriptor);

        assertFalse(first.equals(second));
        second.getDescriptors().set(0, new Descriptor("other", "one"));
        assertFalse(first.equals(second));
        second.getDescriptors().set(0, new Descriptor("key", "one"));
        assertTrue(first.equals(second));
    }
}
