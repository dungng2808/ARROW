package site.ycsb.generator;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void nextValueStaysWithinConfiguredInclusiveRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10L, 20L);

    for (int i = 0; i < 100; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 10L, "generated value should be at least the configured minimum");
      assertTrue(value <= 20L, "generated value should be at most the configured maximum");
    }
  }

  @Test
  public void singleItemRangeAlwaysReturnsThatItem() {
    ZipfianGenerator generator = new ZipfianGenerator(42L, 42L);

    for (int i = 0; i < 20; i++) {
      assertEquals(generator.nextValue().longValue(), 42L);
    }
  }

  @Test
  public void nextLongSupportsIncreasingItemCount() {
    ZipfianGenerator generator = new ZipfianGenerator(0L, 9L);

    for (int i = 0; i < 50; i++) {
      long value = generator.nextLong(15L);
      assertTrue(value >= 0L && value < 15L,
          "value should be within the expanded item count");
    }
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(10L);

    try {
      generator.mean();
      fail("mean should report that it is not implemented");
    } catch (UnsupportedOperationException expected) {
      assertEquals(expected.getMessage(), "@todo implement ZipfianGenerator.mean()");
    }
  }
}
