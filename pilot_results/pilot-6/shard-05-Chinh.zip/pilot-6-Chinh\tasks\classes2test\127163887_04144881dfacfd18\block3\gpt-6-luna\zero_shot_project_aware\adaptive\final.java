package com.batalov.RL;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.awt.geom.Point2D;

import org.junit.Test;

public class RocketLander_ArrowTest {

    @Test
    public void newLanderStartsAtRestWithEnginesOff() {
        RocketLander lander = new RocketLander();

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.isOnGround());
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertFalse(lander.crashed());
    }

    @Test
    public void tickWithBothEnginesBurningAcceleratesUpwardAndRotates() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getX(), 0.0001);
        assertEquals(9.1875, lander.getPosition().getY(), 0.0001);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0001);
        assertEquals(18.375, lander.getVelocity().getY(), 0.0001);
        assertEquals(0.0f, lander.getRotation(), 0.0001f);
        assertTrue(lander.getBurnLeft());
        assertTrue(lander.getBurnRight());
        assertFalse(lander.crashed());
    }

    @Test
    public void singleEngineBurningOnGroundDoesNotLiftOff() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
    }

    @Test
    public void checkLandedResetsMotionAndEnginesWhenAtOrBelowGround() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(1.0f);

        lander.getPosition().setLocation(4.0, -0.25);
        lander.getVelocity().setLocation(0.5, -1.0);

        assertTrue(lander.checkLanded());

        assertEquals(4.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertFalse(lander.crashed());
    }

    @Test
    public void unsafeDescentCrashesStopsAndKeepsCrashState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(1.0f);

        lander.getPosition().setLocation(2.0, -2.0);
        lander.getVelocity().setLocation(0.0, -4.0);

        assertTrue(lander.crashed());

        assertEquals(2.0, lander.getPosition().getX(), 0.0);
        assertEquals(-1.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());

        lander.tick(1.0f);

        assertEquals(2.0, lander.getPosition().getX(), 0.0);
        assertEquals(-1.0, lander.getPosition().getY(), 0.0);
        assertTrue(lander.crashed());
    }

    @Test
    public void vectorHelpersReturnExpectedValues() {
        Point2D position = new Point2D.Float(1.0f, 2.0f);
        Point2D velocity = new Point2D.Float(3.0f, 4.0f);
        Point2D acceleration = new Point2D.Float(2.0f, -2.0f);

        Point2D nextPosition = RocketLander.positionAfter(2.0f, position, velocity, acceleration);
        Point2D nextVelocity = RocketLander.velocityAfter(2.0f, velocity, acceleration);
        Point2D sum = RocketLander.add(position, velocity);
        Point2D thrust = RocketLander.thrustVector(0.0f, 5.0f);

        assertNotSame(position, nextPosition);
        assertEquals(11.0, nextPosition.getX(), 0.0001);
        assertEquals(6.0, nextPosition.getY(), 0.0001);
        assertEquals(7.0, nextVelocity.getX(), 0.0001);
        assertEquals(0.0, nextVelocity.getY(), 0.0001);
        assertEquals(4.0, sum.getX(), 0.0001);
        assertEquals(6.0, sum.getY(), 0.0001);
        assertEquals(0.0, thrust.getX(), 0.0001);
        assertEquals(5.0, thrust.getY(), 0.0001);
    }
}
