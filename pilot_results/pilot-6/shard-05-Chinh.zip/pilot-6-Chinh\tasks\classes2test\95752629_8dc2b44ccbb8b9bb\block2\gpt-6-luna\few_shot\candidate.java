package com.microsoft.azure.common.function.utils;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CommandUtils_ArrowTest {

    @Test
    public void defaultValidReturnCodesContainsOnlySuccessCode() {
        List<Long> returnCodes = CommandUtils.getDefaultValidReturnCodes();

        assertNotNull(returnCodes);
        assertEquals(Arrays.asList(0L), returnCodes);
    }

    @Test
    public void validReturnCodesContainsSuccessAndPlatformInterruptCode() {
        List<Long> returnCodes = CommandUtils.getValidReturnCodes();

        assertNotNull(returnCodes);
        if (CommandUtils.isWindows()) {
            assertEquals(Arrays.asList(0L, 3221225786L), returnCodes);
        } else {
            assertEquals(Arrays.asList(0L, 130L), returnCodes);
        }
    }

    @Test
    public void isWindowsMatchesSystemPlatformProperty() {
        assertEquals(System.getProperty("os.name", "").toLowerCase().startsWith("windows"),
                CommandUtils.isWindows());
    }
}
