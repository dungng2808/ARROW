package com.devskiller.jpa2ddl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

public class FileResolver_ArrowTest {

    @TempDir
    Path temporaryDirectory;

    @Test
    public void resolvesNextMigrationAfterHighestVersion() throws IOException {
        Path migrations = Files.createDirectory(temporaryDirectory.resolve("migrations"));
        Files.createFile(migrations.resolve("v2__initial.sql"));
        Files.createFile(migrations.resolve("v10__update.sql"));
        Files.createFile(migrations.resolve("notes.txt"));

        File next = FileResolver.resolveNextMigrationFile(migrations.toFile());

        assertEquals(migrations.resolve("v11__jpa2ddl.sql").toFile(), next);
    }

    @Test
    public void resolvesNextMigrationAsVersionOneForEmptyDirectory() throws IOException {
        Path migrations = Files.createDirectory(temporaryDirectory.resolve("empty"));

        File next = FileResolver.resolveNextMigrationFile(migrations.toFile());

        assertEquals(migrations.resolve("v1__jpa2ddl.sql").toFile(), next);
    }

    @Test
    public void sortsMigrationsByVersionAndCanFilterSchemaMigrations() throws IOException {
        Path migrations = Files.createDirectory(temporaryDirectory.resolve("sorted"));
        Files.createFile(migrations.resolve("v2__jpa2ddl.sql"));
        Files.createFile(migrations.resolve("v10__change.sql"));
        Files.createFile(migrations.resolve("v1__jpa2ddl-extra.sql"));
        Files.createFile(migrations.resolve("readme.txt"));

        List<Path> descending = FileResolver.resolveExistingMigrations(migrations.toFile(), true, false);
        assertEquals(Arrays.asList(
                migrations.resolve("v10__change.sql"),
                migrations.resolve("v2__jpa2ddl.sql"),
                migrations.resolve("v1__jpa2ddl-extra.sql"),
                migrations.resolve("readme.txt")), descending);

        List<Path> schemaOnly = FileResolver.resolveExistingMigrations(migrations.toFile(), false, true);
        assertEquals(Arrays.asList(
                migrations.resolve("v1__jpa2ddl-extra.sql"),
                migrations.resolve("v2__jpa2ddl.sql")), schemaOnly);
    }

    @Test
    public void createsMissingMigrationDirectoryAndReturnsEmptyResults() {
        File missing = temporaryDirectory.resolve("created").toFile();

        List<Path> results = FileResolver.resolveExistingMigrations(missing, false, false);

        assertTrue(missing.isDirectory());
        assertTrue(results.isEmpty());
    }

    @Test
    public void throwsWhenPackageCannotBeFound() {
        assertThrows(IllegalStateException.class,
                () -> FileResolver.listClassNamesInPackage("no.such.package.for.file.resolver.test"));
    }

    @Test
    public void listsClassesInExistingPackage() throws Exception {
        List<String> classNames = FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl");

        assertFalse(classNames.isEmpty());
        assertTrue(classNames.contains("com.devskiller.jpa2ddl.FileResolver"));
    }
}
