package net.ontopia.presto.spi.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.junit.Test;

public class Utils_ArrowTest {

    @Test
    public void equalsAndDifferentHandleNullAndEqualValues() {
        assertTrue(Utils.equals(null, null));
        assertFalse(Utils.different(null, null));
        assertFalse(Utils.equals(null, "value"));
        assertTrue(Utils.different(null, "value"));
        assertTrue(Utils.equals("value", new String("value")));
        assertFalse(Utils.different("value", new String("value")));
        assertFalse(Utils.equals("value", "other"));
        assertTrue(Utils.different("value", "other"));
    }

    @Test
    public void compareComparablesHandlesOrderingNullsAndDirection() {
        assertTrue(Utils.compareComparables("a", "b") < 0);
        assertTrue(Utils.compareComparables("b", "a") > 0);
        assertEquals(0, Utils.compareComparables("same", "same"));
        assertTrue(Utils.compareComparables(null, "a") < 0);
        assertTrue(Utils.compareComparables("a", null) > 0);
        assertEquals(0, Utils.compareComparables(null, null));

        assertTrue(Utils.compareComparables("a", "b", false) > 0);
        assertTrue(Utils.compareComparables("b", "a", false) < 0);
        assertEquals(0, Utils.compareComparables(null, null, false));

        Comparator<String> reverse = new Comparator<String>() {
            public int compare(String left, String right) {
                return right.compareTo(left);
            }
        };
        assertTrue(Utils.compareComparables("a", "b", reverse) > 0);
        assertTrue(Utils.compareComparables(null, "a", reverse) < 0);
    }

    @Test
    public void validateNotNullAcceptsValuesAndRejectsNull() {
        Utils.validateNotNull("present");
        try {
            Utils.validateNotNull(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException exception) {
            assertEquals("Object cannot be null", exception.getMessage());
        }
    }

    @Test
    public void getNameUsesStringRepresentationForNonTopicsAndNull() {
        assertEquals("value", Utils.getName("value"));
        assertEquals("null", Utils.getName((Object) null));
        assertEquals("null", Utils.getName(null, null));
        assertEquals("42", Utils.getName(null, 42));
    }

    @Test
    public void moveValuesToIndexMovesExistingValuesAndLeavesInputUnchanged() {
        List<String> values = Arrays.asList("a", "b", "c", "d");
        List<String> moved = Arrays.asList("b", "d");

        List<String> result = Utils.moveValuesToIndex(values, moved, 3, false);

        assertEquals(Arrays.asList("a", "b", "d", "c"), result);
        assertEquals(Arrays.asList("a", "b", "c", "d"), values);
        assertNotSame(values, result);
    }

    @Test
    public void moveValuesToIndexAllowsAddingAndHandlesEmptyMoves() {
        List<String> values = Arrays.asList("a", "b");
        assertEquals(Arrays.asList("a", "x", "b"),
                Utils.moveValuesToIndex(values, Collections.singletonList("x"), 1, true));
        assertEquals(values, Utils.moveValuesToIndex(values, Collections.<String>emptyList(), 1, false));
    }

    @Test
    public void moveValuesToIndexRejectsInvalidIndexAndDisallowedNewValues() {
        List<String> values = Arrays.asList("a", "b");

        try {
            Utils.moveValuesToIndex(values, Collections.singletonList("a"), 3, false);
            fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException expected) {
            assertEquals("Index: 3, Size: 2", expected.getMessage());
        }

        try {
            Utils.moveValuesToIndex(values, Collections.singletonList("x"), 1, false);
            fail("Expected RuntimeException");
        } catch (RuntimeException expected) {
            assertEquals("Not allowed to add new values: x", expected.getMessage());
        }
    }

    @Test
    public void newInstanceOfCreatesAssignableClassAndRejectsInvalidClasses() {
        StringBuilder instance = Utils.newInstanceOf(StringBuilder.class.getName(), StringBuilder.class);
        assertEquals("", instance.toString());

        try {
            Utils.newInstanceOf("no.such.TestClass", Object.class);
            fail("Expected RuntimeException");
        } catch (RuntimeException missing) {
            assertEquals("Class no.such.TestClass not found.", missing.getMessage());
        }

        try {
            Utils.newInstanceOf(String.class.getName(), Number.class);
            fail("Expected RuntimeException");
        } catch (RuntimeException incompatible) {
            assertTrue(incompatible.getMessage().contains("not assignable"));
        }
    }
}
