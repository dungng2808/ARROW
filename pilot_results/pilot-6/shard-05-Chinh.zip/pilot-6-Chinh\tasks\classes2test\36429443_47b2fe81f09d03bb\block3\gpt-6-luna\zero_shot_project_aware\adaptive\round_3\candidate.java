package org.zalando.stups.oauth2.spring.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.security.oauth2.common.OAuth2AccessToken.ACCESS_TOKEN;
import static org.springframework.security.oauth2.common.OAuth2AccessToken.BEARER_TYPE;
import static org.springframework.security.oauth2.common.OAuth2AccessToken.EXPIRES_IN;
import static org.springframework.security.oauth2.common.OAuth2AccessToken.TOKEN_TYPE;

import java.util.Date;

import org.junit.Test;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.zalando.stups.tokens.AccessToken;
import org.zalando.stups.tokens.AccessTokenUnavailableException;
import org.zalando.stups.tokens.AccessTokens;

public class StupsTokensAccessTokenProvider_ArrowTest {

    @Test
    public void obtainsBearerTokenWithoutExpiryWhenTokenHasNoValidityDate() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(accessToken.getToken()).thenReturn("access-value");
        when(accessToken.getValidUntil()).thenReturn(null);
        when(tokens.getAccessToken("service")).thenReturn(accessToken);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("service", tokens);

        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertNull(result.getValue());
        assertEquals(BEARER_TYPE, result.getTokenType());
        assertNull(result.getExpiration());
        assertEquals("access-value", result.getAdditionalInformation().get(ACCESS_TOKEN));
        assertEquals(BEARER_TYPE, result.getAdditionalInformation().get(TOKEN_TYPE));
        assertTrue(!result.getAdditionalInformation().containsKey(EXPIRES_IN));
    }

    @Test
    public void obtainsTokenWithRemainingLifetimeWhenValidityDateIsPresent() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(accessToken.getToken()).thenReturn("expiring-value");
        when(accessToken.getValidUntil()).thenReturn(new Date(System.currentTimeMillis() + 120000L));
        when(tokens.getAccessToken("service")).thenReturn(accessToken);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("service", tokens);

        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("expiring-value", result.getValue());
        assertEquals(BEARER_TYPE, result.getTokenType());
        assertNotNull(result.getExpiration());
        assertTrue(result.getExpiration().after(new Date()));
    }

    @Test
    public void wrapsUnavailableTokenExceptionAsOAuth2Exception() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessTokenUnavailableException unavailable =
                mock(AccessTokenUnavailableException.class);
        when(tokens.getAccessToken("service")).thenThrow(unavailable);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("service", tokens);

        try {
            provider.obtainAccessToken(
                    mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));
        } catch (OAuth2Exception expected) {
            assertEquals("Could not obtain access token.", expected.getMessage());
            assertEquals(unavailable, expected.getCause());
            return;
        }
        throw new AssertionError("Expected OAuth2Exception");
    }

    @Test
    public void rejectsBlankTokenId() {
        try {
            new StupsTokensAccessTokenProvider("  ", mock(AccessTokens.class));
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    @Test
    public void rejectsNullTokenSource() {
        try {
            new StupsTokensAccessTokenProvider("service", null);
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }
}
