package org.openape.api.databaseObjectBase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Property_ArrowTest {

    @Test
    public void constructorsAndSettersPreservePropertyValues() {
        Property textProperty = new Property("label", "initial");
        assertEquals("label", textProperty.getName());
        assertEquals("initial", textProperty.getValue());
        assertEquals("initial", textProperty.getValueAsString());

        textProperty.setName("updated");
        textProperty.setValueAsString("replacement");
        assertEquals("updated", textProperty.getName());
        assertEquals("replacement", textProperty.getValue());

        Property booleanProperty = new Property("enabled", true);
        assertEquals(Boolean.TRUE, booleanProperty.getValue());

        Property integerProperty = new Property("count", 7);
        assertEquals(Integer.valueOf(7), integerProperty.getValue());

        Property doubleProperty = new Property("ratio", 2.5);
        assertEquals(Double.valueOf(2.5), doubleProperty.getValue());
    }

    @Test
    public void descriptorsAreExposedAndCanBeReplaced() {
        Property property = new Property();
        Descriptor descriptor = new Descriptor();
        property.addDescriptor(descriptor);
        assertEquals(1, property.getDescriptors().size());
        assertTrue(property.getDescriptors().contains(descriptor));

        property.setDescriptors(new java.util.ArrayList<Descriptor>());
        assertTrue(property.getDescriptors().isEmpty());
    }

    @Test
    public void equalsComparesNameValueAndDescriptors() {
        Property first = new Property("color", "blue");
        Property matching = new Property("color", "blue");
        assertTrue(first.equals(matching));
        assertTrue(matching.equals(first));

        assertFalse(first.equals(new Property("size", "blue")));
        assertFalse(first.equals(new Property("color", "red")));
        assertFalse(first.equals(null));
        assertFalse(first.equals("color"));

        Property empty = new Property();
        assertFalse(empty.equals(new Property()));

        Property withDescriptor = new Property("mode", "safe");
        Property sameDescriptor = new Property("mode", "safe");
        withDescriptor.addDescriptor(new Descriptor("level", "high"));
        sameDescriptor.addDescriptor(new Descriptor("level", "high"));
        assertTrue(withDescriptor.equals(sameDescriptor));

        Property differentDescriptor = new Property("mode", "safe");
        differentDescriptor.addDescriptor(new Descriptor("level", "low"));
        assertFalse(withDescriptor.equals(differentDescriptor));
    }

    @Test
    public void descriptorComparisonRequiresMatchingCountsAndEntries() {
        Property base = new Property("setting", "value");
        Property compare = new Property("setting", "value");
        assertTrue(base.equals(compare));

        base.addDescriptor(new Descriptor("first", "one"));
        assertFalse(base.equals(compare));

        compare.addDescriptor(new Descriptor("first", "one"));
        assertTrue(base.equals(compare));

        compare.addDescriptor(new Descriptor("extra", "two"));
        assertFalse(base.equals(compare));
    }
}
