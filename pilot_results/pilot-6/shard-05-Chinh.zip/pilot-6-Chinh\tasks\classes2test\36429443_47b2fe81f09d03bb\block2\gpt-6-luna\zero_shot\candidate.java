package org.zalando.stups.oauth2.spring.client;

import org.junit.Test;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.zalando.stups.tokens.AccessToken;
import org.zalando.stups.tokens.AccessTokenUnavailableException;
import org.zalando.stups.tokens.AccessTokens;

import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class StupsTokensAccessTokenProvider_ArrowTest {

    @Test
    public void obtainsBearerTokenWithoutExpirationWhenTokenHasNoValidityDate() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        when(tokens.getAccessToken("service")).thenReturn(accessToken);
        when(accessToken.getToken()).thenReturn("access-value");
        when(accessToken.getValidUntil()).thenReturn(null);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("service", tokens);

        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertEquals("access-value", result.getValue());
        assertEquals(OAuth2AccessToken.BEARER_TYPE, result.getTokenType());
        assertNull(result.getExpiration());
    }

    @Test
    public void includesExpirationForTokenWithValidityDate() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessToken accessToken = mock(AccessToken.class);
        Date validUntil = new Date(System.currentTimeMillis() + 120_000L);
        when(tokens.getAccessToken("service")).thenReturn(accessToken);
        when(accessToken.getToken()).thenReturn("access-value");
        when(accessToken.getValidUntil()).thenReturn(validUntil);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("service", tokens);

        OAuth2AccessToken result = provider.obtainAccessToken(
                mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));

        assertNotNull(result.getExpiration());
        assertTrue(result.getExpiration().getTime() <= validUntil.getTime());
        assertTrue(result.getExpiration().getTime() > validUntil.getTime() - 120_000L);
    }

    @Test
    public void wrapsUnavailableTokenException() {
        AccessTokens tokens = mock(AccessTokens.class);
        AccessTokenUnavailableException unavailable =
                mock(AccessTokenUnavailableException.class);
        when(tokens.getAccessToken("service")).thenThrow(unavailable);

        StupsTokensAccessTokenProvider provider =
                new StupsTokensAccessTokenProvider("service", tokens);

        try {
            provider.obtainAccessToken(
                    mock(OAuth2ProtectedResourceDetails.class), mock(AccessTokenRequest.class));
            fail("Expected OAuth2Exception");
        } catch (OAuth2Exception exception) {
            assertEquals("Could not obtain access token.", exception.getMessage());
            assertEquals(unavailable, exception.getCause());
        }
    }

    @Test
    public void rejectsBlankTokenId() {
        try {
            new StupsTokensAccessTokenProvider("  ", mock(AccessTokens.class));
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            assertEquals("tokenId cannot be left blank", expected.getMessage());
        }
    }

    @Test
    public void rejectsNullTokens() {
        try {
            new StupsTokensAccessTokenProvider("service", null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            assertEquals("tokens must not be null", expected.getMessage());
        }
    }
}
