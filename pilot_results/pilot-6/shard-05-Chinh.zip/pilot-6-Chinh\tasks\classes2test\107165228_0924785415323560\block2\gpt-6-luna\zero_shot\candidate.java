package com.devskiller.jpa2ddl;

import org.junit.Test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class FileResolver_ArrowTest {

    @Test
    public void resolveExistingMigrationsSortsByVersionAndCanFilterSchemaMigrations() throws Exception {
        Path directory = Files.createTempDirectory("file-resolver-migrations");
        try {
            Files.createFile(directory.resolve("v10__later.sql"));
            Files.createFile(directory.resolve("v2__earlier.sql"));
            Files.createFile(directory.resolve("v3__jpa2ddl.sql"));
            Files.createFile(directory.resolve("notes.txt"));

            List<Path> allMigrations = FileResolver.resolveExistingMigrations(directory.toFile(), false, false);
            assertEquals(Arrays.asList(
                    directory.resolve("notes.txt"),
                    directory.resolve("v2__earlier.sql"),
                    directory.resolve("v3__jpa2ddl.sql"),
                    directory.resolve("v10__later.sql")
            ), allMigrations);

            List<Path> schemaMigrations = FileResolver.resolveExistingMigrations(directory.toFile(), true, true);
            assertEquals(Arrays.asList(directory.resolve("v3__jpa2ddl.sql")), schemaMigrations);
        } finally {
            deleteRecursively(directory);
        }
    }

    @Test
    public void resolveNextMigrationFileUsesHighestVersionAndCreatesDirectoryWhenMissing() throws Exception {
        Path directory = Files.createTempDirectory("file-resolver-next");
        try {
            Files.createFile(directory.resolve("v4__initial.sql"));
            Files.createFile(directory.resolve("v12__later.sql"));

            File next = FileResolver.resolveNextMigrationFile(directory.toFile());
            assertEquals(directory.resolve("v13__jpa2ddl.sql").toFile(), next);

            Path missingDirectory = directory.resolve("new-migrations");
            File first = FileResolver.resolveNextMigrationFile(missingDirectory.toFile());
            assertTrue(Files.isDirectory(missingDirectory));
            assertEquals(missingDirectory.resolve("v1__jpa2ddl.sql").toFile(), first);
            assertFalse(first.exists());
        } finally {
            deleteRecursively(directory);
        }
    }

    @Test
    public void listClassNamesInPackageFindsClassesInCurrentPackage() throws Exception {
        List<String> classNames = FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl");

        assertTrue(classNames.contains("com.devskiller.jpa2ddl.FileResolver"));
        assertTrue(classNames.contains("com.devskiller.jpa2ddl.FileResolver_ArrowTest"));
    }

    @Test(expected = IllegalStateException.class)
    public void listClassNamesInPackageRejectsMissingPackage() throws Exception {
        FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl.package_that_does_not_exist");
    }

    private static void deleteRecursively(Path root) throws Exception {
        if (!Files.exists(root)) {
            return;
        }
        try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
            paths.sorted((left, right) -> right.compareTo(left))
                    .forEach(path -> {
                        try {
                            Files.deleteIfExists(path);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
        }
    }
}
