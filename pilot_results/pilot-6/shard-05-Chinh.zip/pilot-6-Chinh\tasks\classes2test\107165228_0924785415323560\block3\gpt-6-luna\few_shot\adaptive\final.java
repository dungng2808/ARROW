package com.devskiller.jpa2ddl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class FileResolver_ArrowTest {

    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void resolvesNextMigrationAfterHighestVersion() throws IOException {
        Path migrations = Files.createDirectory(temporaryFolder.getRoot().toPath().resolve("migrations"));
        Files.createFile(migrations.resolve("v2__initial.sql"));
        Files.createFile(migrations.resolve("v10__update.sql"));
        Files.createFile(migrations.resolve("notes.txt"));

        File next = FileResolver.resolveNextMigrationFile(migrations.toFile());

        assertEquals(migrations.resolve("v11__jpa2ddl.sql").toFile(), next);
    }

    @Test
    public void resolvesNextMigrationAsVersionOneForEmptyDirectory() throws IOException {
        Path migrations = Files.createDirectory(temporaryFolder.getRoot().toPath().resolve("empty"));

        File next = FileResolver.resolveNextMigrationFile(migrations.toFile());

        assertEquals(migrations.resolve("v1__jpa2ddl.sql").toFile(), next);
    }

    @Test
    public void sortsMigrationsByVersionAndCanFilterSchemaMigrations() throws IOException {
        Path migrations = Files.createDirectory(temporaryFolder.getRoot().toPath().resolve("sorted"));
        Files.createFile(migrations.resolve("v2__jpa2ddl.sql"));
        Files.createFile(migrations.resolve("v10__change.sql"));
        Files.createFile(migrations.resolve("v1__jpa2ddl-extra.sql"));
        Files.createFile(migrations.resolve("readme.txt"));

        List<Path> descending = FileResolver.resolveExistingMigrations(migrations.toFile(), true, false);
        assertEquals(Arrays.asList(
                migrations.resolve("v10__change.sql"),
                migrations.resolve("v2__jpa2ddl.sql"),
                migrations.resolve("v1__jpa2ddl-extra.sql"),
                migrations.resolve("readme.txt")), descending);

        List<Path> schemaOnly = FileResolver.resolveExistingMigrations(migrations.toFile(), false, true);
        assertEquals(Arrays.asList(
                migrations.resolve("v1__jpa2ddl-extra.sql"),
                migrations.resolve("v2__jpa2ddl.sql")), schemaOnly);
    }

    @Test
    public void createsMissingMigrationDirectoryAndReturnsEmptyResults() {
        File missing = new File(temporaryFolder.getRoot(), "created");

        List<Path> results = FileResolver.resolveExistingMigrations(missing, false, false);

        assertTrue(missing.isDirectory());
        assertTrue(results.isEmpty());
    }

    @Test
    public void throwsWhenPackageCannotBeFound() {
        boolean thrown = false;
        try {
            FileResolver.listClassNamesInPackage("no.such.package.for.file.resolver.test");
        } catch (IllegalStateException expected) {
            thrown = true;
        } catch (Exception unexpected) {
            throw new AssertionError(unexpected);
        }
        assertTrue(thrown);
    }

    @Test
    public void listsClassesInExistingPackage() throws Exception {
        List<String> classNames = FileResolver.listClassNamesInPackage("com.devskiller.jpa2ddl");

        assertFalse(classNames.isEmpty());
        assertTrue(classNames.contains("com.devskiller.jpa2ddl.FileResolver"));
    }
}
