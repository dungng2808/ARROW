package com.batalov.RL;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.awt.geom.Point2D;

import org.junit.Test;

public class RocketLander_ArrowTest {

    @Test
    public void newLanderStartsAtRestOnGround() {
        RocketLander lander = new RocketLander();

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.isOnGround());
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertFalse(lander.crashed());
    }

    @Test
    public void unpoweredLanderFallsAndLandsAtGroundLevel() {
        RocketLander lander = new RocketLander();

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.isOnGround());
        assertFalse(lander.crashed());
    }

    @Test
    public void dualEnginesLiftLanderAndUpdateVelocity() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(0.5f);

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(2.296875, lander.getPosition().getY(), 0.000001);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(9.1875, lander.getVelocity().getY(), 0.000001);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.getBurnLeft());
        assertTrue(lander.getBurnRight());
        assertFalse(lander.isOnGround());
    }

    @Test
    public void singleEngineRotatesWithoutProvidingThrust() {
        RocketLander lander = new RocketLander();
        lander.setBurnRight(true);

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.getBurnRight());
        assertFalse(lander.getBurnLeft());
    }

    @Test
    public void crashStopsRocketAndSubsequentTicksDoNotChangeState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(2.0f);

        assertFalse(lander.crashed());
        assertEquals(36.75, lander.getPosition().getY(), 0.000001);
        assertEquals(36.75, lander.getVelocity().getY(), 0.000001);
        assertTrue(lander.getBurnLeft());
        assertTrue(lander.getBurnRight());

        lander.setBurnLeft(false);
        lander.setBurnRight(false);
        lander.tick(5.0f);

        assertTrue(lander.crashed());
        assertEquals(-1.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());

        Point2D positionBefore = (Point2D) lander.getPosition().clone();
        Point2D velocityBefore = (Point2D) lander.getVelocity().clone();
        float rotationBefore = lander.getRotation();

        lander.tick(1.0f);

        assertEquals(positionBefore, lander.getPosition());
        assertEquals(velocityBefore, lander.getVelocity());
        assertEquals(rotationBefore, lander.getRotation(), 0.0f);
    }

    @Test
    public void toStringIncludesEngineStateAndFlightState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.tick(0.5f);

        assertEquals("< * -- . >, p = [0.000000, 0.000000], v = [0.000000, 0.000000], r = 0.000000",
                lander.toString());
    }
}
