package com.thealgorithms.others;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;

public class StackPostfixNotation_ArrowTest {

    @Test
    public void evaluatesAdditionAndMultiplicationWithPostfixPrecedence() {
        // Arrange
        String expression = "2 3 + 4 *";

        // Act
        int result = StackPostfixNotation.postfixEvaluate(expression);

        // Assert
        assertEquals(20, result);
    }

    @Test
    public void evaluatesSubtractionAndDivisionInOperandOrder() {
        // Arrange
        String expression = "20 5 / 3 -";

        // Act
        int result = StackPostfixNotation.postfixEvaluate(expression);

        // Assert
        assertEquals(1, result);
    }

    @Test
    public void evaluatesNegativeIntegerOperands() {
        // Arrange
        String expression = "-8 3 *";

        // Act
        int result = StackPostfixNotation.postfixEvaluate(expression);

        // Assert
        assertEquals(-24, result);
    }

    @Test
    public void rejectsOperatorWithTooFewOperands() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("7 +"));
    }

    @Test
    public void rejectsExpressionWithExtraOperands() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("2 3"));
    }

    @Test
    public void rejectsUnknownOperator() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate("2 3 %"));
    }

    @Test
    public void rejectsEmptyExpression() {
        assertThrows(IllegalArgumentException.class, () -> StackPostfixNotation.postfixEvaluate(""));
    }
}
