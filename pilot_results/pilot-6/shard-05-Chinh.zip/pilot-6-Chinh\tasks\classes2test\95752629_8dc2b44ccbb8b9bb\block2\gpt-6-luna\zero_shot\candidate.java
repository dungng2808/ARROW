package com.microsoft.azure.common.function.utils;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CommandUtils_ArrowTest {

    @Test
    public void getDefaultValidReturnCodesReturnsOnlyZero() {
        assertEquals(Collections.singletonList(0L), CommandUtils.getDefaultValidReturnCodes());
    }

    @Test
    public void getValidReturnCodesIncludesZeroAndPlatformSpecificInterruptCode() {
        assertNotNull(CommandUtils.getValidReturnCodes());

        if (CommandUtils.isWindows()) {
            assertEquals(Arrays.asList(0L, 3221225786L), CommandUtils.getValidReturnCodes());
        } else {
            assertEquals(Arrays.asList(0L, 130L), CommandUtils.getValidReturnCodes());
        }
    }

    @Test
    public void isWindowsMatchesSystemPlatformProperty() {
        assertEquals(org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS, CommandUtils.isWindows());
    }
}
