# Báo cáo pilot: pilot-6-shard-05-Chinh-winfix

Pilot kiểm tra môi trường, công cụ, chi phí (phần 1) và chọn số vòng sửa tối đa N (phần 2). Pilot **không** trả lời câu hỏi nghiên cứu và không gộp vào kết quả chính.

## Thông tin run

- Cấu hình thực nghiệm: `pilot-v1` (sha256 `d5567edc789801809a9b2dc43e94ea6ef4ffd9cce12182fb5df771dddd991950`), `n_max` = 10, quy tắc N = `share95`
- Model id trả về: `gpt-6-luna`
- Thời điểm tạo báo cáo: 2026-10-13 09:10 UTC

| Máy | Hệ điều hành | CPU | RAM (GB) | Endpoint | Commit tool | Shard |
| --- | --- | --- | --- | --- | --- | --- |
| Chinh | win-x64 | 12 | 16 | api.teamorouter.com | `976fc02c` (dirty) | shard-05 |

## Phần 1: môi trường, công cụ, chi phí

### 1.1. Thời gian và chi phí theo bước (`part1_cost.csv`)

| Bước | Dataset | Số lần | Trung vị (s) | p90 (s) | Max (s) | Tổng (s) | Token vào | Token ra | Chi phí (USD) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| clone | classes2test | 9 | 3.0 | 6.0 | 7.7 | 31 | 0 | 0 | 0.0000 |
| clone | gitbug-java | 1 | 3.3 | 3.3 | 3.3 | 3 | 0 | 0 | 0.0000 |
| baseline | classes2test | 9 | 9.4 | 27.5 | 35.3 | 121 | 0 | 0 | 0.0000 |
| baseline | gitbug-java | 1 | 74.9 | 74.9 | 74.9 | 75 | 0 | 0 | 0.0000 |
| llm_generate | classes2test | 27 | 9.0 | 45.2 | 116.5 | 489 | 50459 | 23477 | 0.0084 |
| llm_generate | gitbug-java | 3 | 3.1 | 3.4 | 3.4 | 9 | 2789 | 1173 | 0.0004 |
| build_verify | classes2test | 22 | 5.7 | 20.6 | 22.6 | 183 | 0 | 0 | 0.0000 |
| build_verify | gitbug-java | 3 | 17.8 | 49.8 | 57.8 | 93 | 0 | 0 | 0.0000 |
| llm_repair | classes2test | 119 | 4.8 | 10.1 | 91.6 | 767 | 303378 | 94784 | 0.0389 |
| build_repair | classes2test | 106 | 3.9 | 11.7 | 29.1 | 657 | 0 | 0 | 0.0000 |
| evosuite | classes2test | 9 | 124.9 | 384.0 | 1200.1 | 2054 | 0 | 0 | 0.0000 |
| evosuite | gitbug-java | 1 | 7.2 | 7.2 | 7.2 | 7 | 0 | 0 | 0.0000 |
| jacoco | classes2test | 31 | 4.6 | 5.8 | 12.5 | 150 | 0 | 0 | 0.0000 |
| jacoco | gitbug-java | 1 | 12.8 | 12.8 | 12.8 | 13 | 0 | 0 | 0.0000 |
| pit | classes2test | 31 | 4.6 | 8.1 | 117.4 | 299 | 0 | 0 | 0.0000 |
| pit | gitbug-java | 1 | 9.0 | 9.0 | 9.0 | 9 | 0 | 0 | 0.0000 |
| tsdetect | classes2test | 31 | 0.6 | 0.6 | 0.8 | 18 | 0 | 0 | 0.0000 |
| tsdetect | gitbug-java | 1 | 0.2 | 0.2 | 0.2 | 0 | 0 | 0 | 0.0000 |

### 1.2. Lỗi hạ tầng (`part1_infra_errors.csv`)

Không có job lỗi hạ tầng.

### 1.3. Kết quả bước sinh test (chỉ để kiểm tra pipeline, không phải kết quả RQ1)

| Dataset | Quy trình | COMPILE | UNKNOWN | DISCOVERY | RUNTIME | ASSERTION | REGRESSION | VALID | INFRA | Output không hợp lệ |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| classes2test | few_shot | 3 | 2 | 0 | 3 | 0 | 0 | 1 | 0 | 3 |
| classes2test | zero_shot | 0 | 4 | 0 | 3 | 0 | 0 | 2 | 0 | 0 |
| classes2test | zero_shot_project_aware | 2 | 1 | 0 | 0 | 1 | 0 | 5 | 0 | 2 |
| gitbug-java | few_shot | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| gitbug-java | zero_shot | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 |
| gitbug-java | zero_shot_project_aware | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 |

Bước kiểm tra và chuẩn hóa output (specs/04 Mục 3) là một phần của pipeline, áp dụng giống nhau cho mọi quy trình prompting.

### 1.4. Ước tính cho phần GPT-6 Luna của thực nghiệm chính

| Hạng mục | Số lượng | Thời gian ước tính (giờ, một máy) | Chi phí ước tính (USD) |
| --- | --- | ---: | ---: |
| RQ1 | 200 × 3 + 32 × 3 = 696 ứng viên | 5.2 | 0.20 |
| RQ2 | 120 ứng viên Classes2Test + ứng viên GitBug-Java thất bại, × 2 cơ chế × tối đa N = 4 vòng (cận trên, chưa gồm GitBug-Java) | 2.3 | 0.31 |
| RQ3 | EvoSuite, JaCoCo, PIT, tsDetect cho 232 CUT | 9.5 | 0 |

Ước tính dựa trên thời gian trung vị và chi phí trung bình mỗi lượt của pilot (chỉ GPT-6 Luna). Phần Qwen3-Coder-30B **không** ước tính được từ pilot.

## Phần 2: chọn N (chỉ Classes2Test)

- Chuỗi sửa (ứng viên × cơ chế) dùng để tính: 28; loại vì lỗi hạ tầng chưa giải quyết: 0; chưa chạy xong: 0.
- Ứng viên không vào bước sửa: 5 (INVALID_OUTPUT: 5).
- Số liệu chung hai cơ chế; báo cáo pilot không tách Fixed và Adaptive.

| Vòng k | S(k) cộng dồn | S(k) / S(n_max) |
| ---: | ---: | ---: |
| 1 | 8 | 0.40 |
| 2 | 17 | 0.85 |
| 3 | 17 | 0.85 |
| 4 | 19 | 0.95 |
| 5 | 20 | 1.00 |
| 6 | 20 | 1.00 |
| 7 | 20 | 1.00 |
| 8 | 20 | 1.00 |
| 9 | 20 | 1.00 |
| 10 | 20 | 1.00 |

**N theo quy tắc `share95`: 4.**

Phân tích độ nhạy: `report2` → 7, `share90` → 4, `share95` → 4, `share99` → 5.

## Tổng quan để chuẩn bị thực nghiệm chính

Các bảng dưới chỉ để kiểm tra pipeline và ước lượng khối lượng việc; **không phải kết quả RQ1, RQ2, RQ3**. Kết quả sửa gộp chung hai cơ chế; không so chất lượng giữa ARROW và EvoSuite.

### A. Bước sinh test: tỷ lệ qua từng bước xác minh

| Dataset | Quy trình | Ứng viên | Compile | Discovery | Execution | Target pass | Không regression (VALID) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| classes2test | few_shot | 9 | 44% (4/9) | 44% (4/9) | 44% (4/9) | 11% (1/9) | 11% (1/9) |
| classes2test | zero_shot | 9 | 56% (5/9) | 56% (5/9) | 56% (5/9) | 22% (2/9) | 22% (2/9) |
| classes2test | zero_shot_project_aware | 9 | 67% (6/9) | 67% (6/9) | 67% (6/9) | 56% (5/9) | 56% (5/9) |
| gitbug-java | few_shot | 1 | 100% (1/1) | 100% (1/1) | 100% (1/1) | 0% (0/1) | 0% (0/1) |
| gitbug-java | zero_shot | 1 | 100% (1/1) | 100% (1/1) | 100% (1/1) | 100% (1/1) | 100% (1/1) |
| gitbug-java | zero_shot_project_aware | 1 | 100% (1/1) | 100% (1/1) | 100% (1/1) | 0% (0/1) | 0% (0/1) |

Lỗi thường gặp nhất ở bước sinh (theo error signature):

| Error signature | Số ứng viên |
| --- | ---: |
| `UNKNOWN \| maven-compiler-plugin \| -` | 7 |
| `RUNTIME \| Exception \| -` | 6 |
| `COMPILE \| invalid output \| -` | 5 |
| `ASSERTION \| AssertionFailedError \| evaluatesAdditionSubtractionMultiplicationAndDivision` | 2 |
| `ASSERTION \| AssertionError \| bothEnginesCancelGravityAndProduceUpwardAcceleration` | 1 |

### B. Bước sửa (gộp Fixed và Adaptive)

| Chỉ số | Giá trị |
| --- | ---: |
| Chuỗi sửa | 28 |
| Đạt VALID trong 10 vòng | 71% (20/28) |
| Vòng đạt VALID (trung vị) | 2 |
| Thời gian một chuỗi, gồm gọi model và build (trung vị, giây) | 27 |
| Token một chuỗi (trung vị, vào / ra) | 4413 / 1557 |
| Số vòng có rollback / mã trùng / output không hợp lệ / mức 3 (tổng) | 2 / 13 / 0 / 13 |
| Test method bị bỏ ở mức 3 (tổng) | 1 |

Trạng thái ban đầu (c0) của các chuỗi:

| Trạng thái c0 | Chuỗi | Đạt VALID |
| --- | ---: | ---: |
| UNKNOWN | 14 | 79% (11/14) |
| RUNTIME | 12 | 75% (9/12) |
| ASSERTION | 2 | 0% (0/2) |

N theo `share95`: 4 (xem phần 2).

### C. EvoSuite chạy được với bao nhiêu CUT

| Dataset | CUT | Sinh được test | Không hỗ trợ JDK (Java > 11) | Lỗi khác | Bộ test VALID |
| --- | ---: | ---: | ---: | ---: | ---: |
| classes2test | 9 | 67% (6/9) | 0 | 3 | 33% (3/9) |
| gitbug-java | 1 | 0% (0/1) | 1 | 0 | 0% (0/1) |

### D. Bộ đo chất lượng chạy được trên bao nhiêu bộ test VALID

| Công cụ | Bộ test đã đo | Đo được (OK) | Lý do không đo được |
| --- | ---: | ---: | --- |
| JaCoCo | 32 | 100% (32/32) | - |
| PIT | 32 | 91% (29/32) | PIT lỗi (exit 1) (3) |
| tsDetect | 32 | 97% (31/32) | tsDetect không ra kết quả (exit 1) (1) |

## Ngoại lệ đã khai báo

- Cờ build chung bỏ qua plugin định dạng, giấy phép, coverage tối thiểu của repository (specs/02 Mục 4.3), như nhau cho mọi hệ thống; ghi trong `run_config.lock.json`.
- JVM của mọi bước build chạy với locale `en_US` và múi giờ UTC (specs/02 Mục 3 bước 6).
- EvoSuite: `evosuite-standalone-runtime-1.2.0.jar` thêm vào scope test chỉ trong workspace của job EvoSuite và job đo bộ test EvoSuite (specs/06 Mục 1).
- PIT chạy bản dòng lệnh 1.17.4 cho mọi build tool; module JUnit 5 thêm `pitest-junit5-plugin` 1.2.1 và `junit-platform-launcher` cùng phiên bản platform (specs/06 Mục 2.2).
- Mẫu Classes2Test của pilot sàng lọc bằng S0 (tiêu chí B, `evaluation_manifest/pilot/README.md`); revision là content-matched.

## Hạn chế

- Pilot chỉ chạy GPT-6 Luna; N chọn trên GPT-6 Luna được áp dụng cho cả Qwen3-Coder-30B, có thể chưa tối ưu cho Qwen.
- Thực nghiệm chạy một lần cho mỗi cấu hình.
