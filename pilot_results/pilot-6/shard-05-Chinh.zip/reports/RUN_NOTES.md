# Ghi chú chạy shard-05 trên Windows

- Người chạy: Chính, tên trong plan và cấu hình máy là `Chinh`.
- Run: `pilot-6-shard-05-Chinh-winfix`.
- JDK được tái sử dụng từ `D:/Ky9/DoAn/ARROW/Java-version/runtime/`.
- Dùng 1 luồng build và 2 luồng gọi model trong cấu hình máy; model, prompt, tham số và shard của nhóm được giữ theo cấu hình thực nghiệm.
- Phiên chạy đặt biến môi trường `DEBUG=false` vì môi trường sẵn có `DEBUG=release` làm LiteLLM từ chối khởi động. Không đổi biến môi trường hệ thống.

## Bản sửa cục bộ để khởi chạy

Heartbeat và cập nhật từ worker cùng ghi `status.json` khiến Windows ném `UnauthorizedAccessException` ở `File.Move`. Đã tuần tự hóa `StatusTracker.Flush()` bằng khóa hiện có. Test `StatusTrackerTests.ConcurrentHeartbeatAndUpdatesLeaveCompleteStatus` tái hiện lỗi trước sửa và đạt sau sửa. Patch nằm cạnh ghi chú này trong `local_runner_fix.patch`; `run_config.lock.json` ghi `tool_git_dirty=true`.

Chạy bộ test Arrow.Core cho kết quả 117 đạt, 1 lỗi: `PathDiagnosticsTests.SpaceInsideArrowSuggestsRenameAndAlternative` kỳ vọng đường dẫn macOS `/Users/dungng/arrow-repo` khi kiểm tra trên Windows. Test này không liên quan bản sửa ghi trạng thái; chưa sửa trong lượt chạy pilot này.

## Điểm cần kiểm tra khi tổng hợp

Trong S1, ít nhất hai lỗi biên dịch Java có thông báo `cannot find symbol` được phân loại `UNKNOWN | maven-compiler-plugin | -`, với `compile_errors` rỗng. Các log chứa đường dẫn dạng `/D:/...`. Ví dụ: Classes2Test `107165228_0924785415323560`, chiến lược `zero_shot`.

Không diễn giải `UNKNOWN` là không có lỗi biên dịch. Cần đối chiếu `verify_0.json` và log Maven khi đánh giá bộ phân loại lỗi trên Windows; chưa thay đổi bộ phân loại hoặc kết quả ứng viên trong lượt chạy này.

## EvoSuite trên Karate

CUT `81226206_eb60e303b6c03e58` (`com.intuit.karate.core.Tags`) hết timeout sinh test 20 phút lúc 16:00 ngày 13/10/2026 (giờ Việt Nam). Runner tự dừng cây tiến trình EvoSuite, ghi `FAILED` với lý do `timeout 20 phút` và tiếp tục CUT tiếp theo; không dừng toàn bộ pilot.

Trước timeout, hai mẫu CPU của JVM con không tăng. Thread dump cho thấy `TEST_EXECUTION_THREAD_0` đang chờ `FutureTask.get()` trong `ClassGraph.scan()`, qua khởi tạo `ResourceUtils` và `karate.Main.main()`. Bằng chứng nằm tại `tasks/classes2test/81226206_eb60e303b6c03e58/logs/evosuite_hang_threads.txt`, cùng `evosuite__generate.log` và `evosuite/evosuite_stats.json`. Chưa thay đổi timeout hoặc tham số EvoSuite.
