package site.ycsb.generator;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void nextValueStaysWithinConfiguredInclusiveRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10L, 20L);

    for (int i = 0; i < 100; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 10L, "generated value should be at least the configured minimum");
      assertTrue(value <= 20L, "generated value should not exceed the configured maximum");
    }
  }

  @Test
  public void singleItemRangeAlwaysGeneratesThatItem() {
    ZipfianGenerator generator = new ZipfianGenerator(42L, 42L);

    for (int i = 0; i < 20; i++) {
      assertEquals(generator.nextValue().longValue(), 42L);
    }
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(5L);

    try {
      generator.mean();
    } catch (UnsupportedOperationException expected) {
      assertEquals(expected.getMessage(), "@todo implement ZipfianGenerator.mean()");
      return;
    }

    throw new AssertionError("mean should report that it is not implemented");
  }
}
