package site.ycsb.generator;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void nextValueStaysWithinConfiguredInclusiveRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10L, 20L);

    for (int i = 0; i < 100; i++) {
      long value = generator.nextValue();
      assertTrue("generated value should be at least the configured minimum", value >= 10L);
      assertTrue("generated value should not exceed the configured maximum", value <= 20L);
    }
  }

  @Test
  public void singleItemRangeAlwaysGeneratesThatItem() {
    ZipfianGenerator generator = new ZipfianGenerator(42L, 42L);

    for (int i = 0; i < 20; i++) {
      assertEquals(Long.valueOf(42L), generator.nextValue());
    }
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(5L);

    try {
      generator.mean();
      fail("mean should report that it is not implemented");
    } catch (UnsupportedOperationException expected) {
      assertEquals("@todo implement ZipfianGenerator.mean()", expected.getMessage());
    }
  }
}
