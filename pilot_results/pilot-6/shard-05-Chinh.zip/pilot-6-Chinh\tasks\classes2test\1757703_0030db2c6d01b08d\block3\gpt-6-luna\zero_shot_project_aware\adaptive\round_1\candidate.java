package net.ontopia.presto.spi.utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class Utils_ArrowTest {

    @Test
    public void equalsAndDifferentHandleNullAndEqualValues() {
        assertTrue(Utils.equals(null, null));
        assertFalse(Utils.different(null, null));
        assertTrue(Utils.equals("value", new String("value")));
        assertFalse(Utils.different("value", new String("value")));
        assertFalse(Utils.equals(null, "value"));
        assertTrue(Utils.different(null, "value"));
    }

    @Test
    public void compareComparablesHandlesNullsAndOrdering() {
        assertEquals(0, Utils.compareComparables(null, null));
        assertTrue(Utils.compareComparables(null, "a") < 0);
        assertTrue(Utils.compareComparables("a", null) > 0);
        assertTrue(Utils.compareComparables("a", "b") < 0);
        assertTrue(Utils.compareComparables("b", "a", false) < 0);
        assertEquals(0, Utils.compareComparables(null, null, false));
    }

    @Test
    public void compareComparablesUsesProvidedComparatorForNonNullValues() {
        assertEquals(1, Utils.compareComparables("a", "B", String.CASE_INSENSITIVE_ORDER));
        assertTrue(Utils.compareComparables(null, "B", String.CASE_INSENSITIVE_ORDER) < 0);
    }

    @Test
    public void validateNotNullAcceptsValueAndRejectsNull() {
        Utils.validateNotNull("present");
        try {
            Utils.validateNotNull(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            assertEquals("Object cannot be null", e.getMessage());
        }
    }

    @Test
    public void getNameUsesStringRepresentationForNonTopics() {
        assertEquals("null", Utils.getName(null));
        assertEquals("42", Utils.getName(Integer.valueOf(42)));
        assertEquals("42", Utils.getName(null, Integer.valueOf(42)));
        assertEquals("null", Utils.getName(null, null));
    }

    @Test
    public void moveValuesToIndexReordersExistingValues() {
        List<String> result = Utils.moveValuesToIndex(
                Arrays.asList("a", "b", "c", "d"),
                Arrays.asList("b", "d"),
                3,
                false);

        assertEquals(Arrays.asList("a", "b", "d", "c"), result);
    }

    @Test
    public void moveValuesToIndexCanAddValuesAndLeavesInputUnchanged() {
        List<String> original = Arrays.asList("a", "b");
        List<String> result = Utils.moveValuesToIndex(
                original, Collections.singletonList("x"), 1, true);

        assertEquals(Arrays.asList("a", "x", "b"), result);
        assertEquals(Arrays.asList("a", "b"), original);
    }

    @Test
    public void moveValuesToIndexReturnsCopyWhenNoValuesAreMoved() {
        List<String> original = Arrays.asList("a", "b");
        List<String> result = Utils.moveValuesToIndex(
                original, Collections.<String>emptyList(), 2, false);

        assertEquals(original, result);
        assertFalse(original == result);
    }

    @Test
    public void moveValuesToIndexRejectsIndexBeyondSize() {
        try {
            Utils.moveValuesToIndex(Arrays.asList("a"), Collections.<String>emptyList(), 2, false);
            fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException e) {
            assertEquals("Index: 2, Size: 1", e.getMessage());
        }
    }

    @Test
    public void moveValuesToIndexRejectsUnknownValueWhenAddingIsDisabled() {
        try {
            Utils.moveValuesToIndex(Arrays.asList("a"), Collections.singletonList("x"), 0, false);
            fail("Expected RuntimeException");
        } catch (RuntimeException e) {
            assertEquals("Not allowed to add new values: x", e.getMessage());
        }
    }
}
