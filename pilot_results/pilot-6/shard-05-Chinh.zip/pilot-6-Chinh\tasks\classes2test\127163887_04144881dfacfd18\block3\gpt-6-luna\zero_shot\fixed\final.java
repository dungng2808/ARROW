package com.batalov.RL;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class RocketLander_ArrowTest {

    @Test
    public void newLanderStartsAtRestOnGround() {
        RocketLander lander = new RocketLander();

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.isOnGround());
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());
        assertFalse(lander.crashed());
    }

    @Test
    public void unpoweredLanderRemainsAtRestOnGround() {
        RocketLander lander = new RocketLander();

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.isOnGround());
        assertFalse(lander.crashed());
    }

    @Test
    public void dualEnginesLiftLanderAndUpdateVelocity() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);

        lander.tick(0.5f);

        assertEquals(0.0, lander.getPosition().getX(), 0.0);
        assertEquals(2.296875, lander.getPosition().getY(), 0.000001);
        assertEquals(0.0, lander.getVelocity().getX(), 0.0);
        assertEquals(9.1875, lander.getVelocity().getY(), 0.000001);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertTrue(lander.getBurnLeft());
        assertTrue(lander.getBurnRight());
        assertFalse(lander.isOnGround());
    }

    @Test
    public void singleEngineOnGroundRotatesWithoutProvidingThrust() {
        RocketLander lander = new RocketLander();
        lander.setBurnRight(true);

        lander.tick(1.0f);

        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(Math.toRadians(10), lander.getRotation(), 0.000001);
        assertTrue(lander.getBurnRight());
        assertFalse(lander.getBurnLeft());
    }

    @Test
    public void singleEngineRotatesWhileAirborneWithoutProvidingThrust() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(0.5f);
        lander.setBurnLeft(false);
        lander.setBurnRight(true);

        double positionBefore = lander.getPosition().getY();
        double velocityBefore = lander.getVelocity().getY();

        lander.tick(1.0f);

        assertEquals(positionBefore + velocityBefore - 0.8125, lander.getPosition().getY(), 0.000001);
        assertEquals(velocityBefore - 1.625, lander.getVelocity().getY(), 0.000001);
        assertEquals((float) Math.toRadians(10), lander.getRotation(), 0.000001f);
        assertTrue(lander.getBurnRight());
        assertFalse(lander.getBurnLeft());
    }

    @Test
    public void landingResetsPositionVelocityAndEngineState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.setBurnRight(true);
        lander.tick(2.0f);

        assertFalse(lander.crashed());
        assertEquals(36.75, lander.getPosition().getY(), 0.000001);
        assertEquals(36.75, lander.getVelocity().getY(), 0.000001);

        lander.setBurnLeft(false);
        lander.setBurnRight(false);
        lander.tick(10.0f);

        assertFalse(lander.crashed());
        assertEquals(323.0, lander.getPosition().getY(), 0.000001);
        assertEquals(20.5, lander.getVelocity().getY(), 0.000001);
        assertFalse(lander.getBurnLeft());
        assertFalse(lander.getBurnRight());

        lander.tick(2.0f);

        assertTrue(lander.isOnGround());
        assertEquals(0.0, lander.getPosition().getY(), 0.0);
        assertEquals(0.0, lander.getVelocity().getY(), 0.0);
        assertEquals(0.0f, lander.getRotation(), 0.0f);
        assertFalse(lander.crashed());
    }

    @Test
    public void toStringIncludesEngineStateAndFlightState() {
        RocketLander lander = new RocketLander();
        lander.setBurnLeft(true);
        lander.tick(0.5f);

        assertEquals("< * -- . >, p = [0.000000, 2.296875], v = [0.000000, 9.187500], r = 0.000000",
                lander.toString());
    }
}
