package org.openape.api.databaseObjectBase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Property_ArrowTest {

    @Test
    public void constructorsAndSettersPreserveNameAndTypedValues() {
        Property stringProperty = new Property("mode", "automatic");
        assertEquals("mode", stringProperty.getName());
        assertEquals("automatic", stringProperty.getValue());
        assertEquals("automatic", stringProperty.getValueAsString());

        Property booleanProperty = new Property("enabled", true);
        assertEquals("enabled", booleanProperty.getName());
        assertEquals(Boolean.TRUE, booleanProperty.getValue());
        assertEquals("true", booleanProperty.getValueAsString());

        Property integerProperty = new Property("count", 7);
        assertEquals(Integer.valueOf(7), integerProperty.getValue());
        assertEquals("7", integerProperty.getValueAsString());

        Property doubleProperty = new Property("ratio", 2.5);
        assertEquals(Double.valueOf(2.5), doubleProperty.getValue());
        assertEquals("2.5", doubleProperty.getValueAsString());

        integerProperty.setName("total");
        integerProperty.setValue(9);
        assertEquals("total", integerProperty.getName());
        assertEquals(Integer.valueOf(9), integerProperty.getValue());

        booleanProperty.setValue(false);
        assertEquals(Boolean.FALSE, booleanProperty.getValue());

        doubleProperty.setValue(3.5);
        assertEquals(Double.valueOf(3.5), doubleProperty.getValue());

        stringProperty.setValueAsString("manual");
        assertEquals("manual", stringProperty.getValue());
        assertEquals("manual", stringProperty.getValueAsString());
    }

    @Test
    public void descriptorsAreExposedAndCanBeReplaced() {
        Property property = new Property();
        Descriptor descriptor = new Descriptor();
        property.addDescriptor(descriptor);

        assertEquals(1, property.getDescriptors().size());
        assertTrue(property.getDescriptors().contains(descriptor));

        property.setDescriptors(new java.util.ArrayList<Descriptor>());
        assertTrue(property.getDescriptors().isEmpty());
    }

    @Test
    public void equalsComparesNameValueAndDescriptors() {
        Property first = new Property("color", "blue");
        Property same = new Property("color", "blue");
        Property differentName = new Property("shade", "blue");
        Property differentValue = new Property("color", "red");

        assertTrue(first.equals(same));
        assertFalse(first.equals(differentName));
        assertFalse(first.equals(differentValue));
        assertFalse(first.equals(null));
        assertFalse(first.equals("not a property"));

        first.addDescriptor(new Descriptor("unit", "metric"));
        same.addDescriptor(new Descriptor("unit", "metric"));
        assertTrue(first.equals(same));

        same.getDescriptors().clear();
        assertFalse(first.equals(same));

        same.addDescriptor(new Descriptor("unit", "imperial"));
        assertFalse(first.equals(same));
    }

    @Test
    public void equalsReturnsFalseWhenNameOrValueIsNull() {
        Property uninitialized = new Property();
        Property initialized = new Property("name", "value");

        assertFalse(uninitialized.equals(initialized));
        assertFalse(initialized.equals(uninitialized));
    }

    @Test
    public void equalPropertiesCompareAsEqual() {
        Property first = new Property("key", "value");
        Property second = new Property("key", "value");

        assertTrue(first.equals(second));
    }
}
