package com.howtoprogram.repository.feign.auth;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class RequestReponseService_ArrowTest {

    @Test
    public void getAuthenticatedUserReturnsStatus() {
        RequestReponseService service = new RequestReponseService();

        AuthStatus status = service.getAuthenticatedUser();

        assertNotNull(status);
    }
}
