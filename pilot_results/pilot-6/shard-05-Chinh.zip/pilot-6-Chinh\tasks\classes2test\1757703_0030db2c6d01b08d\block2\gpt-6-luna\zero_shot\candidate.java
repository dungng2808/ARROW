package net.ontopia.presto.spi.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

public class Utils_ArrowTest {

    @Test
    public void equalsAndDifferentHandleNullAndEqualValues() {
        assertTrue(Utils.equals(null, null));
        assertFalse(Utils.different(null, null));
        assertTrue(Utils.equals("value", new String("value")));
        assertFalse(Utils.different("value", new String("value")));
        assertFalse(Utils.equals("value", null));
        assertTrue(Utils.different("value", null));
    }

    @Test
    public void compareComparablesHandlesNullsAndOrdering() {
        assertEquals(0, Utils.compareComparables(null, null));
        assertTrue(Utils.compareComparables(null, "a") < 0);
        assertTrue(Utils.compareComparables("a", null) > 0);
        assertTrue(Utils.compareComparables("a", "b") < 0);
        assertTrue(Utils.compareComparables("b", "a", true) > 0);
        assertTrue(Utils.compareComparables("b", "a", false) < 0);
        assertEquals(0, Utils.compareComparables("a", "A", String.CASE_INSENSITIVE_ORDER));
    }

    @Test
    public void validateNotNullAcceptsValueAndRejectsNull() {
        Utils.validateNotNull("present");

        try {
            Utils.validateNotNull(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            assertEquals("Object cannot be null", e.getMessage());
        }
    }

    @Test
    public void getNameUsesStringRepresentationForNonTopics() {
        assertEquals("42", Utils.getName(Integer.valueOf(42)));
        assertEquals("null", Utils.getName((Object) null));
        assertEquals("42", Utils.getName(null, Integer.valueOf(42)));
        assertEquals("null", Utils.getName(null, null));
    }

    @Test
    public void moveValuesToIndexReordersExistingValues() {
        List<String> original = Arrays.asList("a", "b", "c", "d");

        List<String> result = Utils.moveValuesToIndex(
                original, Collections.singletonList("b"), 3, false);

        assertEquals(Arrays.asList("a", "c", "b", "d"), result);
        assertEquals(Arrays.asList("a", "b", "c", "d"), original);
    }

    @Test
    public void moveValuesToIndexAllowsAddingAndHandlesEmptyMoves() {
        List<String> original = Arrays.asList("a", "b");

        List<String> added = Utils.moveValuesToIndex(
                original, Collections.singletonList("x"), 1, true);
        assertEquals(Arrays.asList("a", "x", "b"), added);

        List<String> unchanged = Utils.moveValuesToIndex(
                original, Collections.<String>emptyList(), 2, false);
        assertEquals(original, unchanged);
        assertNotEquals(original, added);
    }

    @Test
    public void moveValuesToIndexRejectsInvalidIndexAndDisallowedAddition() {
        try {
            Utils.moveValuesToIndex(Arrays.asList("a", "b"),
                    Collections.<String>emptyList(), 3, true);
            fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException e) {
            assertEquals("Index: 3, Size: 2", e.getMessage());
        }

        try {
            Utils.moveValuesToIndex(Arrays.asList("a", "b"),
                    Collections.singletonList("x"), 1, false);
            fail("Expected RuntimeException");
        } catch (RuntimeException e) {
            assertEquals("Not allowed to add new values: x", e.getMessage());
        }
    }

    @Test
    public void newInstanceOfCreatesAssignableClass() {
        String value = Utils.newInstanceOf(String.class.getName(), String.class);

        assertEquals("", value);
    }

    @Test
    public void newInstanceOfRejectsMissingOrIncompatibleClass() {
        try {
            Utils.newInstanceOf("no.such.UtilsTestClass", Object.class);
            fail("Expected RuntimeException for missing class");
        } catch (RuntimeException e) {
            assertEquals("Class no.such.UtilsTestClass not found.", e.getMessage());
        }

        try {
            Utils.newInstanceOf(String.class.getName(), Number.class);
            fail("Expected RuntimeException for incompatible class");
        } catch (RuntimeException e) {
            assertEquals("Class " + String.class.getName()
                    + " not assignable to " + Number.class, e.getMessage());
        }
    }
}
