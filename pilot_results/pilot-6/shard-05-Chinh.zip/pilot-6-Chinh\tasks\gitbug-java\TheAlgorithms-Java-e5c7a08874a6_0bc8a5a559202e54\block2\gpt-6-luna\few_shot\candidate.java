package com.thealgorithms.others;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class StackPostfixNotation_ArrowTest {

    @Test
    public void evaluatesPostfixExpressionWithAllSupportedOperators() {
        assertEquals(14, StackPostfixNotation.postfixEvaluate("2 3 + 4 * 2 /"));
    }

    @Test
    public void preservesOperandOrderForSubtractionAndDivision() {
        assertEquals(5, StackPostfixNotation.postfixEvaluate("20 3 - 17 3 / -"));
    }

    @Test
    public void evaluatesNegativeIntegerOperands() {
        assertEquals(-5, StackPostfixNotation.postfixEvaluate("-2 3 -"));
    }

    @Test
    public void rejectsOperatorWithTooFewOperands() {
        assertThrows(
            IllegalArgumentException.class,
            () -> StackPostfixNotation.postfixEvaluate("1 +"));
    }

    @Test
    public void rejectsExpressionWithMultipleRemainingValues() {
        assertThrows(
            IllegalArgumentException.class,
            () -> StackPostfixNotation.postfixEvaluate("1 2"));
    }

    @Test
    public void rejectsUnknownOperation() {
        assertThrows(
            IllegalArgumentException.class,
            () -> StackPostfixNotation.postfixEvaluate("1 2 %"));
    }

    @Test
    public void rejectsEmptyExpression() {
        assertThrows(
            IllegalArgumentException.class,
            () -> StackPostfixNotation.postfixEvaluate(""));
    }
}
