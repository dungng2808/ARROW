package com.intuit.karate.core;

import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Tags_ArrowTest {

    private Tag tag(String text) {
        return new Tag(1, text);
    }

    @Test
    public void tagLookupAndValuesSupportPrefixes() {
        Tag smoke = tag("@smoke");
        Tag color = tag("@color=red,blue");
        Tags tags = new Tags(Arrays.asList(smoke, color));

        assertTrue(tags.contains("@smoke"));
        assertTrue(tags.contains("smoke"));
        assertFalse(tags.contains("@missing"));
        assertTrue(tags.anyOf("@smoke", "@missing"));
        assertTrue(tags.allOf("smoke", "@color=red,blue"));
        assertTrue(tags.not("@missing"));
        assertEquals(Arrays.asList("red", "blue"), tags.valuesFor("@color").values);
        assertTrue(tags.valuesFor("color").isAnyOf("blue"));
        assertTrue(tags.valuesFor("color").isAllOf("red", "blue"));
        assertTrue(tags.valuesFor("color").isOnly("red", "blue"));
        assertEquals(Arrays.asList("smoke", "color=red,blue"), tags.getTags());
    }

    @Test
    public void evaluateHonorsEnvironmentAndTagSelectors() {
        Tags tags = new Tags(Arrays.asList(
                tag("@smoke"),
                tag("@env=dev,qa"),
                tag("@envnot=prod")));

        assertTrue(tags.evaluate(null, "dev"));
        assertFalse(tags.evaluate(null, "prod"));
        assertFalse(tags.evaluate(null, null));
        assertTrue(tags.evaluate("anyOf('@smoke')", "qa"));
        assertFalse(tags.evaluate("anyOf('@missing')", "qa"));
    }

    @Test
    public void evaluateExcludesIgnoreAndSetupTags() {
        Tags ignored = new Tags(Collections.singletonList(tag("@ignore")));
        Tags setup = new Tags(Collections.singletonList(tag("@setup")));

        assertFalse(ignored.evaluate(null, null));
        assertFalse(setup.evaluate(null, null));
    }

    @Test
    public void optionTagsConvertToSelectorExpressions() {
        assertNull(Tags.fromKarateOptionsTags((String[]) null));
        assertNull(Tags.fromKarateOptionsTags(Collections.<String>emptyList()));
        assertEquals("anyOf('@smoke','@fast') && not('@slow')",
                Tags.fromKarateOptionsTags("@smoke, @fast", "~@slow"));
        assertEquals("anyOf('@smoke')", Tags.fromKarateOptionsTags(Arrays.asList("@smoke")));
        assertEquals("someExpression()", Tags.fromKarateOptionsTags("someExpression()"));
    }

    @Test
    public void emptyTagsHaveNoValuesAndMergeDeduplicates() {
        Tags empty = new Tags(Collections.<Tag>emptyList());
        assertTrue(empty.getTags().isEmpty());
        assertFalse(empty.valuesFor("missing").isPresent());

        Tag smoke = tag("@smoke");
        Tags merged = Tags.merge(Arrays.asList(smoke), Arrays.asList(smoke));
        assertEquals(1, merged.getTags().size());
        assertTrue(merged.contains("smoke"));
    }
}
