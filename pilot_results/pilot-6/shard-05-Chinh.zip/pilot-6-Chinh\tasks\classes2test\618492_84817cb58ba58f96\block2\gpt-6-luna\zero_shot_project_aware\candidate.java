package site.ycsb.generator;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class ZipfianGenerator_ArrowTest {

  @Test
  public void nextValueStaysWithinConfiguredInclusiveRange() {
    ZipfianGenerator generator = new ZipfianGenerator(10L, 25L);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 10L && value <= 25L,
          "Generated value must be within the configured inclusive range: " + value);
    }
  }

  @Test
  public void itemCountConstructorGeneratesValuesFromZeroThroughItemCountMinusOne() {
    ZipfianGenerator generator = new ZipfianGenerator(7L);

    for (int i = 0; i < 500; i++) {
      long value = generator.nextValue();
      assertTrue(value >= 0L && value < 7L,
          "Generated value must be within the configured item-count range: " + value);
    }
  }

  @Test
  public void singletonRangeAlwaysGeneratesItsOnlyItem() {
    ZipfianGenerator generator = new ZipfianGenerator(42L, 42L);

    for (int i = 0; i < 20; i++) {
      assertEquals(generator.nextValue().longValue(), 42L);
    }
  }

  @Test
  public void meanIsNotImplemented() {
    ZipfianGenerator generator = new ZipfianGenerator(5L);

    try {
      generator.mean();
      fail("mean() should report that it is not implemented");
    } catch (UnsupportedOperationException expected) {
      assertEquals(expected.getMessage(), "@todo implement ZipfianGenerator.mean()");
    }
  }
}
