package com.microsoft.azure.common.function.utils;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CommandUtils_ArrowTest {

    @Test
    public void getDefaultValidReturnCodesContainsOnlySuccessCode() {
        List<Long> codes = CommandUtils.getDefaultValidReturnCodes();

        assertNotNull(codes);
        assertEquals(Arrays.asList(0L), codes);
    }

    @Test
    public void getValidReturnCodesContainsSuccessAndPlatformInterruptCode() {
        List<Long> codes = CommandUtils.getValidReturnCodes();

        assertNotNull(codes);
        if (CommandUtils.isWindows()) {
            assertEquals(Arrays.asList(0L, 3221225786L), codes);
        } else {
            assertEquals(Arrays.asList(0L, 130L), codes);
        }
    }
}
