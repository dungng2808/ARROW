package de.bytefish.jtinycsvparser.typeconverter;

import java.time.Instant;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class InstantConverter_ArrowTest {

    private final InstantConverter converter = new InstantConverter();

    @Test
    public void convertsIso8601Instant() {
        Instant expected = Instant.parse("2024-03-15T12:34:56.789Z");

        assertEquals(expected, converter.convert("2024-03-15T12:34:56.789Z"));
    }

    @Test
    public void reportsInstantTargetType() {
        assertEquals(Instant.class, converter.getTargetType());
    }

    @Test
    public void hasExpectedStringRepresentation() {
        assertEquals("InstantConverter{}", converter.toString());
    }

    @Test
    public void wrapsInvalidInputInRuntimeException() {
        try {
            converter.convert("not-an-instant");
            fail("Expected a RuntimeException for invalid input");
        } catch (RuntimeException expected) {
            // Expected: InstantConverter wraps parsing failures.
        }
    }
}
