package de.bytefish.jtinycsvparser.typeconverter;

import java.time.Instant;
import org.junit.Test;
import static org.junit.Assert.*;

class InstantConverter_ArrowTest {

    private final InstantConverter converter = new InstantConverter();

    @Test
    void convertsIso8601Instant() {
        Instant expected = Instant.parse("2024-03-15T12:34:56.789Z");

        assertEquals(expected, converter.convert("2024-03-15T12:34:56.789Z"));
    }

    @Test
    void reportsInstantTargetType() {
        assertEquals(Instant.class, converter.getTargetType());
    }

    @Test
    void hasExpectedStringRepresentation() {
        assertEquals("InstantConverter{}", converter.toString());
    }

    @Test
    void wrapsInvalidInputInRuntimeException() {
        assertThrows(RuntimeException.class, () -> converter.convert("not-an-instant"));
    }
}
