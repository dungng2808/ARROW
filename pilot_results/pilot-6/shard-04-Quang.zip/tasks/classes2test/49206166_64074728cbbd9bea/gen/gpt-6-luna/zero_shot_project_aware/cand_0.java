package de.bytefish.jtinycsvparser.typeconverter;

import org.junit.Test;

import java.time.Instant;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThrows;

public class InstantConverter_ArrowTest {

    @Test
    public void convertsIso8601Instant() {
        InstantConverter converter = new InstantConverter();

        assertEquals(Instant.parse("2024-03-15T12:34:56.123456789Z"),
                converter.convert("2024-03-15T12:34:56.123456789Z"));
    }

    @Test
    public void reportsInstantTargetType() {
        InstantConverter converter = new InstantConverter();

        assertSame(Instant.class, converter.getTargetType());
    }

    @Test
    public void hasExpectedStringRepresentation() {
        assertEquals("InstantConverter{}", new InstantConverter().toString());
    }

    @Test
    public void wrapsInvalidInputInRuntimeException() {
        InstantConverter converter = new InstantConverter();

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> converter.convert("not-an-instant"));

        assertNotNull(exception.getCause());
    }
}
