package de.bytefish.jtinycsvparser.typeconverter;

import org.junit.Test;

import java.time.Instant;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

public class InstantConverter_ArrowTest {

    private final InstantConverter converter = new InstantConverter();

    @Test
    public void convertParsesIso8601Instant() {
        Instant expected = Instant.parse("2024-03-15T12:34:56.789Z");

        assertEquals(expected, converter.convert("2024-03-15T12:34:56.789Z"));
    }

    @Test
    public void convertParsesInstantWithOffset() {
        Instant expected = Instant.parse("2024-03-15T12:34:56Z");

        assertEquals(expected, converter.convert("2024-03-15T14:34:56+02:00"));
    }

    @Test
    public void convertWrapsInvalidInputInRuntimeException() {
        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> converter.convert("not-an-instant"));

        assertNotNull(exception.getCause());
    }

    @Test
    public void getTargetTypeReturnsInstantClass() {
        assertEquals(Instant.class, converter.getTargetType());
    }

    @Test
    public void toStringReturnsConverterDescription() {
        assertEquals("InstantConverter{}", converter.toString());
    }
}
