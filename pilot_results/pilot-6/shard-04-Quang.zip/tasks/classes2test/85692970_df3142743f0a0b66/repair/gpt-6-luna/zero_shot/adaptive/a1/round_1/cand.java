package com.github.thorbenkuck.netcom2.network.client;

import java.util.UUID;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;

class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    void produceReturnsHandlerForProvidedClassAndUuid() {
        Sender sender = mock(Sender.class);
        RemoteAccessBlockRegistration registration = mock(RemoteAccessBlockRegistration.class);
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.randomUUID();

        JavaRemoteInformationInvocationHandler<String> handler =
                producer.produce(uuid, String.class);

        assertNotNull(handler);
    }

    @Test
    void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        mock(Sender.class),
                        mock(RemoteAccessBlockRegistration.class));

        try {
            producer.produce(UUID.randomUUID(), null);
            fail("Expected a RuntimeException for a null class");
        } catch (RuntimeException expected) {
            // Expected.
        }
    }

    @Test
    void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        mock(Sender.class),
                        mock(RemoteAccessBlockRegistration.class));

        try {
            producer.produce(null, String.class);
            fail("Expected a RuntimeException for a null UUID");
        } catch (RuntimeException expected) {
            // Expected.
        }
    }
}
