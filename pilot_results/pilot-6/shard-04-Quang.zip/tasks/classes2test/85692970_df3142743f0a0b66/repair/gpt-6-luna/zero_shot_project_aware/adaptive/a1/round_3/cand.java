package com.github.thorbenkuck.netcom2.network.client;

import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

public class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    public void produceReturnsHandlerForRequestedClassAndUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);
        UUID uuid = UUID.randomUUID();

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(uuid, Runnable.class);

        assertNotNull(handler);
        assertEquals(JavaRemoteInformationInvocationHandler.class, handler.getClass());
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        try {
            producer.produce(UUID.randomUUID(), null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        try {
            producer.produce(null, Runnable.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }
}
