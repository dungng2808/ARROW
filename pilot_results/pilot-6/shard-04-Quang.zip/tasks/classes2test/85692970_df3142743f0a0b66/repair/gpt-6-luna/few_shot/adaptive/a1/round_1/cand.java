package com.github.thorbenkuck.netcom2.network.client;

import java.util.UUID;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

public class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    public void produceCreatesHandlerForRequestedClassAndUuid() {
        Sender sender = null;
        RemoteAccessBlockRegistration registration = null;
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.randomUUID();

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(uuid, Runnable.class);

        assertNotNull(handler);
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        try {
            producer.produce(UUID.randomUUID(), null);
            fail("Expected an exception for a null class");
        } catch (RuntimeException expected) {
            // Expected.
        }
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        try {
            producer.produce(null, Runnable.class);
            fail("Expected an exception for a null UUID");
        } catch (RuntimeException expected) {
            // Expected.
        }
    }
}
