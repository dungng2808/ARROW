package com.github.thorbenkuck.netcom2.network.client;

import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

public class JavaInvocationHandlerProducer_ArrowTest {

    private Sender createSender() {
        return new Sender() {
            @Override
            public void reset() {
                // No-op test implementation.
            }

            @Override
            public <T> void unRegistrationToServer(Class<T> clazz, Class remoteAccessBlockClass) {
                // No-op test implementation.
            }
        };
    }

    @Test
    public void produceReturnsHandlerForRequestedClassAndUuid() {
        Sender sender = createSender();
        RemoteAccessBlockRegistration registration =
                org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class);
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.randomUUID();

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(uuid, Runnable.class);

        assertNotNull(handler);
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        createSender(),
                        org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class));

        try {
            producer.produce(UUID.randomUUID(), null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // Expected.
        }
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        createSender(),
                        org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class));

        try {
            producer.produce(null, Runnable.class);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // Expected.
        }
    }
}
