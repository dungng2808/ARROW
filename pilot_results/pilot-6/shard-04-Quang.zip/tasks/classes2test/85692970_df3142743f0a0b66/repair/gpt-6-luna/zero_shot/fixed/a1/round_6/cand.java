package com.github.thorbenkuck.netcom2.network.client;

import java.util.UUID;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

public class JavaInvocationHandlerProducer_ArrowTest {

    private static final class TestSender implements Sender {
        @Override
        public void reset() {
            // The producer only stores the sender; these tests do not invoke it.
        }
    }

    private static final class TestRegistration extends RemoteAccessBlockRegistration {
        // The producer only stores the registration; these tests do not invoke it.
    }

    @Test
    public void produceReturnsHandlerForProvidedClassAndUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(new TestSender(), new TestRegistration());

        JavaRemoteInformationInvocationHandler<String> handler =
                producer.produce(UUID.randomUUID(), String.class);

        assertNotNull(handler);
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(new TestSender(), new TestRegistration());

        try {
            producer.produce(UUID.randomUUID(), null);
            fail("Expected a RuntimeException for a null class");
        } catch (RuntimeException expected) {
            // Expected.
        }
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(new TestSender(), new TestRegistration());

        try {
            producer.produce(null, String.class);
            fail("Expected a RuntimeException for a null UUID");
        } catch (RuntimeException expected) {
            // Expected.
        }
    }
}
