package com.github.thorbenkuck.netcom2.network.client;

import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.assertNotNull;

public class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    public void produceReturnsHandlerForRequestedClassAndUuid() {
        Sender sender = org.mockito.Mockito.mock(Sender.class);
        RemoteAccessBlockRegistration registration =
                org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class);
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(UUID.randomUUID(), Runnable.class);

        assertNotNull(handler);
    }

    @Test(expected = NullPointerException.class)
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        org.mockito.Mockito.mock(Sender.class),
                        org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class));

        producer.produce(UUID.randomUUID(), null);
    }

    @Test(expected = NullPointerException.class)
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        org.mockito.Mockito.mock(Sender.class),
                        org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class));

        producer.produce(null, Runnable.class);
    }
}
