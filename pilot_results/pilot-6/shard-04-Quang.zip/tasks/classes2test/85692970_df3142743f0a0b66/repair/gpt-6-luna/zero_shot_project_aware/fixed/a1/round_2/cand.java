package com.github.thorbenkuck.netcom2.network.client;

import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

public class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    public void produceReturnsHandlerForRequestedClassAndUuid() {
        Sender sender = new Sender() {};
        RemoteAccessBlockRegistration registration =
                org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class);
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.randomUUID();

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(uuid, Runnable.class);

        assertNotNull(handler);
        assertSame(Runnable.class, handler.getClass());
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        new Sender() {},
                        org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class));

        try {
            producer.produce(UUID.randomUUID(), null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // Expected.
        }
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        new Sender() {},
                        org.mockito.Mockito.mock(RemoteAccessBlockRegistration.class));

        try {
            producer.produce(null, Runnable.class);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // Expected.
        }
    }
}
