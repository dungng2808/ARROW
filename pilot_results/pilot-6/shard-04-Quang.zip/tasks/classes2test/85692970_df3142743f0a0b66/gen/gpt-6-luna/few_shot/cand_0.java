package com.github.thorbenkuck.netcom2.network.client;

import java.util.UUID;
import org.junit.Test;
import static org.junit.Assert.*;

class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    void produceCreatesHandlerForRequestedClassAndUuid() {
        Sender sender = null;
        RemoteAccessBlockRegistration registration = null;
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.randomUUID();

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(uuid, Runnable.class);

        assertNotNull(handler);
    }

    @Test
    void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        assertThrows(RuntimeException.class, () -> producer.produce(UUID.randomUUID(), null));
    }

    @Test
    void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        assertThrows(RuntimeException.class, () -> producer.produce(null, Runnable.class));
    }
}
