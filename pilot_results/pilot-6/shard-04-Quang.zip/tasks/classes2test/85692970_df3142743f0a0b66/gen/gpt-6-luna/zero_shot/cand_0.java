package com.github.thorbenkuck.netcom2.network.client;

import java.util.UUID;
import static org.mockito.Mockito.mock;
import org.junit.Test;
import static org.junit.Assert.*;

class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    void produceReturnsHandlerForProvidedClassAndUuid() {
        Sender sender = mock(Sender.class);
        RemoteAccessBlockRegistration registration = mock(RemoteAccessBlockRegistration.class);
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.randomUUID();

        JavaRemoteInformationInvocationHandler<String> handler =
                producer.produce(uuid, String.class);

        assertNotNull(handler);
    }

    @Test
    void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        mock(Sender.class),
                        mock(RemoteAccessBlockRegistration.class));

        assertThrows(RuntimeException.class, () -> producer.produce(UUID.randomUUID(), null));
    }

    @Test
    void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(
                        mock(Sender.class),
                        mock(RemoteAccessBlockRegistration.class));

        assertThrows(RuntimeException.class, () -> producer.produce(null, String.class));
    }
}
