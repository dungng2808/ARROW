package amforeas.client;

import static org.junit.jupiter.api.Assertions.*;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.junit.jupiter.api.Test;

class RequestParams_ArrowTest {

    @Test
    void builderCreatesResourcePathAndDefaults() {
        RequestParams params = RequestParams.builder("users").build();

        assertEquals("users", params.getResource());
        assertEquals("/api/v1/users", params.getPath("/api", "v1"));
        assertNull(params.getPrimaryKey());
        assertNull(params.getPrimaryKeyValue());
        assertNull(params.getPage());
        assertArrayEquals(new NameValuePair[0], params.getParameters());
        assertEquals("", params.getParametersAsQueryParams());
    }

    @Test
    void idSetsDefaultPrimaryKeyAndPath() {
        RequestParams params = RequestParams.builder("users").id("42").build();

        assertEquals("id", params.getPrimaryKey());
        assertEquals("42", params.getPrimaryKeyValue());
        assertEquals("/api/v1/users/42", params.getPath("/api", "v1"));
    }

    @Test
    void explicitKeyIsPreservedWhenIdIsSet() {
        RequestParams params = RequestParams.builder("users").key("userId").id("42").build();

        assertEquals("userId", params.getPrimaryKey());
        assertEquals("42", params.getPrimaryKeyValue());
    }

    @Test
    void columnValueBuildsColumnPath() {
        RequestParams params = RequestParams.builder("users").column("email").value("a@example.com").build();

        assertEquals("email", params.getColumn());
        assertEquals("a@example.com", params.getColumnValue());
        assertEquals("/api/v1/users/email/a@example.com", params.getPath("/api", "v1"));
    }

    @Test
    void dynamicQueryAcceptsUpToTwoArguments() {
        RequestParams params = RequestParams.builder("users")
            .dynamicQuery("findByNameAndAge")
            .addQueryParam("Ada")
            .addQueryParam("37")
            .build();

        assertEquals("findByNameAndAge", params.getQuery());
        assertEquals(Arrays.asList(
            new BasicNameValuePair("args", "Ada"),
            new BasicNameValuePair("args", "37")), params.getQueryArgs());
        assertEquals("/api/v1/users/dynamic/findByNameAndAge", params.getPath("/api", "v1"));
        assertEquals("args=Ada&args=37", params.getParametersAsQueryParams());
    }

    @Test
    void paginationAndSortingAreIncludedInParameters() {
        RequestParams params = RequestParams.builder("users")
            .from(10)
            .to(25)
            .sortBy("name", "asc")
            .build();

        assertEquals(10, params.getOffset());
        assertEquals(25, params.getLimit());
        assertEquals("name", params.getSort());
        assertEquals("ASC", params.getDirection());
        assertEquals("limit=25&offset=10&sort=name&dir=ASC", params.getParametersAsQueryParams());
    }

    @Test
    void pageAndSortingAreIncludedInParameters() {
        RequestParams params = RequestParams.builder("users")
            .page(3)
            .sortBy("name", "DESC")
            .build();

        assertEquals(3, params.getPage());
        assertEquals("page=3&sort=name&dir=DESC", params.getParametersAsQueryParams());
    }

    @Test
    void insertAndUpdateBuildPathsAndBodies() throws Exception {
        RequestParams insert = RequestParams.builder("users")
            .insert("name", "Ada")
            .insert("active", "true")
            .build();

        assertEquals("/api/v1/users", insert.getPath("/api", "v1"));
        assertEquals("{\"name\":\"Ada\",\"active\":\"true\"}", insert.getJSONBody().getContent().toString());

        RequestParams update = RequestParams.builder("users")
            .id("42")
            .update("name", "Ada")
            .build();

        assertEquals("/api/v1/users/42", update.getPath("/api", "v1"));
        assertEquals("{\"name\":\"Ada\"}", update.getJSONBody().getContent().toString());
    }

    @Test
    void formBodyContainsEncodedParameters() throws Exception {
        RequestParams params = RequestParams.builder("users")
            .insert("name", "Ada Lovelace")
            .build();

        assertEquals("name=Ada+Lovelace", new String(params.getFormBody().getContent().readAllBytes()));
    }

    @Test
    void jsonSerializationFormatsNameValuePairs() {
        List<NameValuePair> pairs = Arrays.asList(
            new BasicNameValuePair("name", "Ada"),
            new BasicNameValuePair("age", "37"));

        assertEquals("{\"name\":\"Ada\",\"age\":\"37\"}",
            RequestParams.builder("users").build().toJSON(pairs));
    }

    @Test
    void builderRejectsInvalidCombinations() {
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("users").value("x"));
        assertThrows(IllegalArgumentException.class,
            () -> RequestParams.builder("users").dynamicQuery("searchByName"));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("users").addQueryParam("x"));
        assertThrows(IndexOutOfBoundsException.class,
            () -> RequestParams.builder("users").dynamicQuery("findByName")
                .addQueryParam("a").addQueryParam("b").addQueryParam("c"));
        assertThrows(IllegalArgumentException.class,
            () -> RequestParams.builder("users").sortBy("name", "sideways"));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("users").to(10).build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("users").from(0).build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("users").to(10).page(1));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("users").column("name").value("Ada").id("1").build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("users").update("name", "Ada").build());
    }

    @Test
    void missingBodyThrows() {
        RequestParams params = RequestParams.builder("users").build();

        assertThrows(IllegalStateException.class, params::getFormBody);
        assertThrows(IllegalStateException.class, params::getJSONBody);
    }

    @Test
    void equalityHashCodeAndStringRepresentation() {
        RequestParams first = RequestParams.builder("users").id("42").build();
        RequestParams same = RequestParams.builder("users").id("42").build();
        RequestParams different = RequestParams.builder("users").id("43").build();

        assertEquals(first, first);
        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertNotEquals(first, null);
        assertNotEquals(first, "users");
        assertTrue(first.toString().contains("resource=users"));
        assertTrue(first.toString().contains("primaryKeyValue=42"));
    }
}
