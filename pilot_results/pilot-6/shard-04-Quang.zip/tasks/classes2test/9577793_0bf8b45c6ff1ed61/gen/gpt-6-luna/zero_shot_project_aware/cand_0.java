package amforeas.client;

import static org.junit.jupiter.api.Assertions.*;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.junit.jupiter.api.Test;

class RequestParams_ArrowTest {

    @Test
    void builderCreatesResourcePathAndExposesResource() {
        RequestParams params = RequestParams.builder("widgets").build();

        assertEquals("widgets", params.getResource());
        assertEquals("/api/v1/widgets", params.getPath("/api", "v1"));
        assertNull(params.getPrimaryKey());
        assertNull(params.getPrimaryKeyValue());
    }

    @Test
    void idDefaultsPrimaryKeyAndBuildsItemPath() {
        RequestParams params = RequestParams.builder("widgets").id("42").build();

        assertEquals("id", params.getPrimaryKey());
        assertEquals("42", params.getPrimaryKeyValue());
        assertEquals("/api/v1/widgets/42", params.getPath("/api", "v1"));
    }

    @Test
    void explicitKeyIsPreservedWhenIdIsSet() {
        RequestParams params = RequestParams.builder("widgets").key("slug").id("blue").build();

        assertEquals("slug", params.getPrimaryKey());
        assertEquals("blue", params.getPrimaryKeyValue());
    }

    @Test
    void columnValueBuildsColumnPath() {
        RequestParams params = RequestParams.builder("widgets").column("status").value("active").build();

        assertEquals("status", params.getColumn());
        assertEquals("active", params.getColumnValue());
        assertEquals("/api/v1/widgets/status/active", params.getPath("/api", "v1"));
    }

    @Test
    void dynamicQueryAcceptsArgumentsAndBuildsQueryParameters() {
        RequestParams params = RequestParams.builder("widgets")
            .dynamicQuery("findByStatus")
            .addQueryParam("active")
            .addQueryParam("pending")
            .build();

        assertEquals("findByStatus", params.getQuery());
        assertEquals("/api/v1/widgets/dynamic/findByStatus", params.getPath("/api", "v1"));
        assertEquals(Arrays.asList(
            new BasicNameValuePair("args", "active"),
            new BasicNameValuePair("args", "pending")), params.getQueryArgs());
        assertEquals("args=active&args=pending", params.getParametersAsQueryParams());
    }

    @Test
    void paginationAndSortingAreReturnedAsParameters() {
        RequestParams params = RequestParams.builder("widgets")
            .from(10)
            .to(25)
            .sortBy("createdAt", "desc")
            .build();

        assertEquals(10, params.getOffset());
        assertEquals(25, params.getLimit());
        assertEquals("createdAt", params.getSort());
        assertEquals("DESC", params.getDirection());
        assertEquals("limit=25&offset=10&sort=createdAt&dir=DESC", params.getParametersAsQueryParams());
    }

    @Test
    void pageTakesPrecedenceOverOtherParameterTypes() {
        RequestParams params = RequestParams.builder("widgets")
            .page(3)
            .sortBy("name", "ASC")
            .build();

        assertEquals(3, params.getPage());
        assertEquals("page=3&sort=name&dir=ASC", params.getParametersAsQueryParams());
    }

    @Test
    void insertBuildsCollectionPathAndBodies() throws Exception {
        RequestParams params = RequestParams.builder("widgets")
            .insert("name", "blue widget")
            .insert("enabled", "true")
            .build();

        assertEquals("/api/v1/widgets", params.getPath("/api", "v1"));
        assertEquals("{\"name\":\"blue widget\",\"enabled\":\"true\"}", params.toJSON(params.getInsert()));
        assertEquals("{\"name\":\"blue widget\",\"enabled\":\"true\"}", readBody(params.getJSONBody().getContent().readAllBytes()));
        assertEquals("name=blue+widget&enabled=true", readBody(params.getFormBody().getContent().readAllBytes()));
    }

    @Test
    void updateRequiresAndUsesIdForPathAndBodies() throws Exception {
        RequestParams params = RequestParams.builder("widgets")
            .id("42")
            .update("name", "updated")
            .build();

        assertEquals("/api/v1/widgets/42", params.getPath("/api", "v1"));
        assertEquals("{\"name\":\"updated\"}", readBody(params.getJSONBody().getContent().readAllBytes()));
        assertEquals("name=updated", readBody(params.getFormBody().getContent().readAllBytes()));
    }

    @Test
    void suppliedListsAreRetainedForInsertAndUpdate() {
        List<NameValuePair> insert = Collections.singletonList(new BasicNameValuePair("a", "1"));
        List<NameValuePair> update = Collections.singletonList(new BasicNameValuePair("b", "2"));

        RequestParams inserted = RequestParams.builder("widgets").insert(insert).build();
        RequestParams updated = RequestParams.builder("widgets").id("1").update(update).build();

        assertSame(insert, inserted.getInsert());
        assertSame(update, updated.getUpdate());
    }

    @Test
    void missingBodyThrowsForBothBodyAccessors() {
        RequestParams params = RequestParams.builder("widgets").build();

        assertThrows(IllegalStateException.class, params::getFormBody);
        assertThrows(IllegalStateException.class, params::getJSONBody);
    }

    @Test
    void builderRejectsInvalidCombinations() {
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").value("x"));
        assertThrows(IllegalArgumentException.class,
            () -> RequestParams.builder("widgets").dynamicQuery("search"));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").addQueryParam("x"));
        assertThrows(IndexOutOfBoundsException.class,
            () -> RequestParams.builder("widgets").dynamicQuery("findByName")
                .addQueryParam("a").addQueryParam("b").addQueryParam("c"));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").to(10).build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").from(0).build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").from(0).to(10).page(1));
        assertThrows(IllegalArgumentException.class,
            () -> RequestParams.builder("widgets").sortBy("name", "sideways"));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").update("name", "x").build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").id("1").column("name").value("x").build());
    }

    @Test
    void equalityHashCodeAndStringRepresentationUseCoreFields() {
        RequestParams first = RequestParams.builder("widgets").id("1").page(2).build();
        RequestParams same = RequestParams.builder("widgets").id("1").page(2).build();
        RequestParams different = RequestParams.builder("widgets").id("2").page(2).build();

        assertEquals(first, first);
        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertNotEquals(first, null);
        assertNotEquals(first, "widgets");
        assertTrue(first.toString().contains("resource=widgets"));
        assertTrue(first.toString().contains("primaryKeyValue=1"));
        assertTrue(first.toString().contains("page=2"));
    }

    private static String readBody(byte[] bytes) {
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
