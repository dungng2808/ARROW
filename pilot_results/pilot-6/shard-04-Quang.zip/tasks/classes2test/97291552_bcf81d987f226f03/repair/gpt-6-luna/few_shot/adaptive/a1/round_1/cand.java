package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.*;

public class Template_ArrowTest
{
	@Test
	public void defaultConstructorCreatesNonInstance()
	{
		Template template = new Template();

		assertFalse(template.isInstance());
		assertEquals(0, template.getParameterCount());
	}

	@Test
	public void constructorCanCreateInstance()
	{
		assertTrue(new Template(true).isInstance());
		assertFalse(new Template(false).isInstance());
	}

	@Test
	public void addAndRetrieveParametersByNameAndIndex()
	{
		Template template = new Template();
		TemplateParameter first = new TemplateParameter(1, new Ref<>("first"), null);
		TemplateParameter second = new TemplateParameter(2, new Ref<>("second"), null);

		template.addParameter(first);
		template.addParameter(second);

		assertEquals(2, template.getParameterCount());
		assertSame(first, template.getParameter("first"));
		assertSame(second, template.getParameter("second"));
		assertSame(first, template.getParameter(1));
		assertSame(second, template.getParameter(2));
	}

	@Test
	public void addingParameterWithExistingNameReplacesIt()
	{
		Template template = new Template();
		TemplateParameter original = new TemplateParameter(1, new Ref<>("value"), null);
		TemplateParameter replacement = new TemplateParameter(2, new Ref<>("value"), null);

		template.addParameter(original);
		template.addParameter(replacement);

		assertEquals(1, template.getParameterCount());
		assertSame(replacement, template.getParameter("value"));
		assertSame(replacement, template.getParameter(2));
	}

	@Test
	public void missingNameReturnsNull()
	{
		assertNull(new Template().getParameter("missing"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void missingIndexThrowsIllegalArgumentException()
	{
		new Template().getParameter(42);
	}
}
