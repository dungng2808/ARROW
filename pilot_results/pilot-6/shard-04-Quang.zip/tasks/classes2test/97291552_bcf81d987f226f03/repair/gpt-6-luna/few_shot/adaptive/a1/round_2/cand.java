package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.*;

public class Template_ArrowTest
{
	@Test
	public void defaultConstructorCreatesNonInstance()
	{
		Template template = new Template();

		assertFalse(template.isInstance());
		assertEquals(0, template.getParameterCount());
	}

	@Test
	public void constructorCanCreateInstance()
	{
		assertTrue(new Template(true).isInstance());
		assertFalse(new Template(false).isInstance());
	}

	@Test
	public void missingNameReturnsNull()
	{
		assertNull(new Template().getParameter("missing"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void missingIndexThrowsIllegalArgumentException()
	{
		new Template().getParameter(42);
	}
}
