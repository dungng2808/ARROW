package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.*;

public class Template_ArrowTest
{
	@Test
	public void defaultConstructorCreatesNonInstance()
	{
		Template template = new Template();

		assertFalse( template.isInstance() );
		assertEquals( 0, template.getParameterCount() );
	}

	@Test
	public void booleanConstructorPreservesInstanceFlag()
	{
		assertTrue( new Template( true ).isInstance() );
		assertFalse( new Template( false ).isInstance() );
	}

	@Test
	public void addAndRetrieveParameterByNameAndIndex()
	{
		Template template = new Template();
		TemplateParameter parameter = new TemplateParameter( 3, "parameter", null );

		template.addParameter( parameter );

		assertSame( parameter, template.getParameter( parameter.getName() ) );
		assertSame( parameter, template.getParameter( 3 ) );
		assertEquals( 1, template.getParameterCount() );
	}

	@Test
	public void addingSameNameReplacesExistingParameter()
	{
		Template template = new Template();
		TemplateParameter original = new TemplateParameter( 1, "parameter", null );
		TemplateParameter replacement = new TemplateParameter( 2, "parameter", null );

		template.addParameter( original );
		template.addParameter( replacement );

		assertSame( replacement, template.getParameter( replacement.getName() ) );
		assertSame( replacement, template.getParameter( 2 ) );
		assertEquals( 1, template.getParameterCount() );
	}

	@Test
	public void missingNameReturnsNull()
	{
		assertNull( new Template().getParameter( "missing" ) );
	}

	@Test
	public void missingIndexThrowsIllegalArgumentException()
	{
		try
		{
			new Template().getParameter( 7 );
			fail( "Expected an exception for an unknown parameter index" );
		}
		catch( IllegalArgumentException exception )
		{
			assertEquals( "No parameter with index: 7", exception.getMessage() );
		}
	}
}
