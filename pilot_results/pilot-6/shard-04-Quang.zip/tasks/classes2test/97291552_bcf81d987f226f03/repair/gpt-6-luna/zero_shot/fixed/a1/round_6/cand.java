package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.*;

public class Template_ArrowTest
{
	@Test
	public void defaultConstructorCreatesNonInstanceWithNoParameters()
	{
		Template template = new Template();

		assertFalse(template.isInstance());
		assertEquals(0, template.getParameterCount());
	}

	@Test
	public void booleanConstructorSetsInstanceFlag()
	{
		assertTrue(new Template(true).isInstance());
		assertFalse(new Template(false).isInstance());
	}

	@Test
	public void parametersCanBeAddedAndRetrievedByNameAndIndex()
	{
		Template template = new Template();
		TemplateParameter first = new TemplateParameter(0, new Ref("first")
		{
			@Override
			public Object resolve(Scope scope)
			{
				return null;
			}
		}, null);
		TemplateParameter second = new TemplateParameter(1, new Ref("second")
		{
			@Override
			public Object resolve(Scope scope)
			{
				return null;
			}
		}, null);

		template.addParameter(first);
		template.addParameter(second);

		assertEquals(2, template.getParameterCount());
		assertSame(first, template.getParameter(first.getName()));
		assertSame(second, template.getParameter(second.getName()));
		assertSame(first, template.getParameter(0));
		assertSame(second, template.getParameter(1));
	}

	@Test
	public void addingParameterWithExistingNameReplacesIt()
	{
		Template template = new Template();
		TemplateParameter original = new TemplateParameter(0, new Ref("parameter")
		{
			@Override
			public Object resolve(Scope scope)
			{
				return null;
			}
		}, null);
		TemplateParameter replacement = new TemplateParameter(1, new Ref("parameter")
		{
			@Override
			public Object resolve(Scope scope)
			{
				return null;
			}
		}, null);

		template.addParameter(original);
		template.addParameter(replacement);

		assertEquals(1, template.getParameterCount());
		assertSame(replacement, template.getParameter(original.getName()));
		assertSame(replacement, template.getParameter(1));
	}

	@Test
	public void missingNameReturnsNull()
	{
		assertNull(new Template().getParameter("missing"));
	}

	@Test
	public void missingIndexThrowsIllegalArgumentException()
	{
		try
		{
			new Template().getParameter(7);
			fail("Expected an IllegalArgumentException");
		}
		catch( IllegalArgumentException exception )
		{
			assertEquals("No parameter with index: 7", exception.getMessage());
		}
	}
}
