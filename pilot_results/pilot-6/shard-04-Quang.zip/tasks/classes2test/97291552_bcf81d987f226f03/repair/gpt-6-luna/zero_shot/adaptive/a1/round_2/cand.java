package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.*;

public class Template_ArrowTest
{
	@Test
	public void defaultConstructorCreatesNonInstanceWithNoParameters()
	{
		Template template = new Template();

		assertFalse(template.isInstance());
		assertEquals(0, template.getParameterCount());
	}

	@Test
	public void booleanConstructorSetsInstanceFlag()
	{
		assertTrue(new Template(true).isInstance());
		assertFalse(new Template(false).isInstance());
	}

	@Test
	public void missingNameReturnsNull()
	{
		assertNull(new Template().getParameter("missing"));
	}

	@Test
	public void missingIndexThrowsIllegalArgumentException()
	{
		try
		{
			new Template().getParameter(7);
			fail("Expected an IllegalArgumentException");
		}
		catch( IllegalArgumentException exception )
		{
			assertEquals("No parameter with index: 7", exception.getMessage());
		}
	}
}
