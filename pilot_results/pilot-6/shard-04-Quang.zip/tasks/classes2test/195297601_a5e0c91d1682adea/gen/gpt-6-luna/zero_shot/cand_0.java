package de.hegmanns.tdd.task04;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

class AddMashine_ArrowTest {

    @Test
    void constructorStoresInitialValue() {
        AddMashine machine = new AddMashine(12L);

        assertEquals(12L, machine.getSum());
    }

    @Test
    void addIncreasesSum() {
        AddMashine machine = new AddMashine(10L);

        machine.add(5L);
        machine.add(3L);

        assertEquals(18L, machine.getSum());
    }

    @Test
    void subtractDecreasesSum() {
        AddMashine machine = new AddMashine(10L);

        machine.sub(4L);
        machine.sub(2L);

        assertEquals(4L, machine.getSum());
    }

    @Test
    void averageUsesSumAndNumberOfAddAndSubtractOperations() {
        AddMashine machine = new AddMashine(10L);
        machine.add(6L);
        machine.sub(4L);

        assertEquals(new BigDecimal("6"), machine.getAverage());
    }

    @Test
    void averageCanBeCalculatedAfterASingleOperation() {
        AddMashine machine = new AddMashine(10L);
        machine.add(5L);

        assertEquals(new BigDecimal("15"), machine.getAverage());
    }

    @Test
    void averageBeforeAnyOperationThrowsArithmeticException() {
        AddMashine machine = new AddMashine(10L);

        assertThrows(ArithmeticException.class, machine::getAverage);
    }
}
