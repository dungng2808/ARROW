package de.hegmanns.tdd.task04;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class AddMashine_ArrowTest {

    @Test
    void initialValueIsTheSum() {
        AddMashine machine = new AddMashine(10L);

        assertEquals(10L, machine.getSum());
    }

    @Test
    void addUpdatesSumAndAverage() {
        AddMashine machine = new AddMashine(10L);

        machine.add(4L);
        machine.add(6L);

        assertEquals(20L, machine.getSum());
        assertEquals(new BigDecimal("10"), machine.getAverage());
    }

    @Test
    void subtractUpdatesSumAndCountsAsAnOperation() {
        AddMashine machine = new AddMashine(20L);

        machine.sub(4L);
        machine.sub(6L);

        assertEquals(10L, machine.getSum());
        assertEquals(new BigDecimal("5"), machine.getAverage());
    }

    @Test
    void averageUsesAddedAndSubtractedOperations() {
        AddMashine machine = new AddMashine(10L);

        machine.add(5L);
        machine.sub(3L);

        assertEquals(12L, machine.getSum());
        assertEquals(new BigDecimal("6"), machine.getAverage());
    }

    @Test
    void averageBeforeAnyOperationThrows() {
        AddMashine machine = new AddMashine(10L);

        assertThrows(ArithmeticException.class, machine::getAverage);
    }
}
