package de.hegmanns.tdd.task04;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

class AddMashine_ArrowTest {

    @Test
    void constructorStoresInitialValue() {
        AddMashine machine = new AddMashine(12L);

        assertEquals(Long.valueOf(12L), machine.getSum());
    }

    @Test
    void addUpdatesSum() {
        AddMashine machine = new AddMashine(10L);

        machine.add(5L);
        machine.add(3L);

        assertEquals(Long.valueOf(18L), machine.getSum());
    }

    @Test
    void subtractUpdatesSum() {
        AddMashine machine = new AddMashine(10L);

        machine.sub(4L);
        machine.sub(2L);

        assertEquals(Long.valueOf(4L), machine.getSum());
    }

    @Test
    void averageUsesInitialValueAndEachOperation() {
        AddMashine machine = new AddMashine(10L);

        machine.add(5L);
        machine.sub(3L);

        assertEquals(new BigDecimal("6"), machine.getAverage());
    }

    @Test
    void averageWithNoOperationsThrowsArithmeticException() {
        AddMashine machine = new AddMashine(10L);

        assertThrows(ArithmeticException.class, machine::getAverage);
    }
}
