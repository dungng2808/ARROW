package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Collection;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.owlapi.wrapper.OwlConverter;
import org.semanticweb.elk.reasoner.Reasoner;
import org.semanticweb.elk.reasoner.ReasonerInterrupter;
import org.semanticweb.elk.reasoner.config.ReasonerConfiguration;
import org.semanticweb.elk.reasoner.stages.ReasonerStageExecutor;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

class OwlInternalProof_ArrowTest {

	private Reasoner createReasoner() {
		return new Reasoner(
				org.semanticweb.elk.owlapi.wrapper.ElkObjectFactory.getInstance(),
				new ReasonerInterrupter(),
				new ReasonerStageExecutor(),
				ReasonerConfiguration.getConfiguration());
	}

	@Test
	void goalIsReturnedAsAConversionInference() {
		OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
		OWLClass subClass = dataFactory.getOWLClass(IRI.create("urn:test:Sub"));
		OWLClass superClass = dataFactory.getOWLClass(IRI.create("urn:test:Super"));
		OWLSubClassOfAxiom goal = dataFactory.getOWLSubClassOfAxiom(subClass,
				superClass);

		Reasoner reasoner = createReasoner();
		try {
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			assertSame(goal, proof.getGoal());
			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(goal);
			assertNotNull(inferences);
			assertEquals(1, inferences.size());

			Inference<Object> inference = inferences.iterator().next();
			assertEquals("Converting inference", inference.getName());
			assertEquals(goal, inference.getConclusion());
			assertEquals(1, inference.getPremises().size());
			assertEquals(OwlConverter.getInstance().convert(goal),
					inference.getPremises().get(0));
		} finally {
			reasoner.shutdown();
		}
	}

	@Test
	void nonGoalConclusionIsDelegatedToInternalProof() {
		OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
		OWLClass subClass = dataFactory.getOWLClass(IRI.create("urn:test:Sub2"));
		OWLClass superClass = dataFactory.getOWLClass(IRI.create("urn:test:Super2"));
		OWLAxiom goal = dataFactory.getOWLSubClassOfAxiom(subClass, superClass);
		OWLAxiom otherConclusion = dataFactory.getOWLDeclarationAxiom(
				dataFactory.getOWLClass(IRI.create("urn:test:Other")));

		Reasoner reasoner = createReasoner();
		try {
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			Collection<? extends Inference<Object>> result = proof
					.getInferences(otherConclusion);
			assertNotNull(result);
			assertTrue(result.isEmpty());
			assertFalse(result.contains(null));
		} finally {
			reasoner.shutdown();
		}
	}
}
