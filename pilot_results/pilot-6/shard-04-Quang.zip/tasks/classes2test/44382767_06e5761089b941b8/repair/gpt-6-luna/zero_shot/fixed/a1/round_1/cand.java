package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Collection;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.owlapi.wrapper.OwlConverter;
import org.semanticweb.elk.reasoner.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

public class OwlInternalProof_ArrowTest {

	@Test
	public void goalIsReturnedAsConvertingInference() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass subClass = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test:Sub"));
		OWLClass superClass = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test:Super"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);

		OwlInternalProof proof = new OwlInternalProof(
				(Reasoner) java.lang.reflect.Proxy.newProxyInstance(
						Reasoner.class.getClassLoader(),
						new Class<?>[] { Reasoner.class },
						(proxy, method, args) -> {
							if ("isEntailed".equals(method.getName())) {
								return true;
							}
							if (method.getReturnType() == boolean.class) {
								return false;
							}
							if (method.getReturnType() == int.class) {
								return 0;
							}
							if (method.getReturnType() == long.class) {
								return 0L;
							}
							return null;
						}),
				goal);

		assertSame(goal, proof.getGoal());
		Collection<? extends Inference<Object>> inferences = proof
				.getInferences(goal);
		assertEquals(1, inferences.size());

		Inference<Object> inference = inferences.iterator().next();
		assertEquals("Converting inference", inference.getName());
		assertEquals(goal, inference.getConclusion());
		assertEquals(1, inference.getPremises().size());
		assertNotNull(inference.getPremises().get(0));
	}

	@Test
	public void nonGoalIsDelegatedToInternalProof() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass subClass = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test:Sub2"));
		OWLClass superClass = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test:Super2"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);
		OWLAxiom other = factory.getOWLDeclarationAxiom(factory
				.getOWLClass(org.semanticweb.owlapi.model.IRI
						.create("urn:test:Other")));

		OwlInternalProof proof = new OwlInternalProof(
				(Reasoner) java.lang.reflect.Proxy.newProxyInstance(
						Reasoner.class.getClassLoader(),
						new Class<?>[] { Reasoner.class },
						(proxy, method, args) -> {
							if ("isEntailed".equals(method.getName())) {
								return true;
							}
							if (method.getReturnType() == boolean.class) {
								return false;
							}
							if (method.getReturnType() == int.class) {
								return 0;
							}
							if (method.getReturnType() == long.class) {
								return 0L;
							}
							return null;
						}),
				goal);

		Collection<? extends Inference<Object>> inferences = proof
				.getInferences(other);
		assertNotNull(inferences);
		assertTrue(inferences.isEmpty());
		assertFalse(inferences.contains(null));
	}

	@Test
	public void goalComparisonUsesAxiomEquality() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass subClass = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test:EqualSub"));
		OWLClass superClass = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test:EqualSuper"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);
		OWLAxiom equalGoal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);

		OwlInternalProof proof = new OwlInternalProof(
				(Reasoner) java.lang.reflect.Proxy.newProxyInstance(
						Reasoner.class.getClassLoader(),
						new Class<?>[] { Reasoner.class },
						(proxy, method, args) -> {
							if ("isEntailed".equals(method.getName())) {
								return true;
							}
							if (method.getReturnType() == boolean.class) {
								return false;
							}
							if (method.getReturnType() == int.class) {
								return 0;
							}
							if (method.getReturnType() == long.class) {
								return 0L;
							}
							return null;
						}),
				goal);

		assertEquals(goal, equalGoal);
		assertEquals(1, proof.getInferences(equalGoal).size());
	}

	@Test
	public void convertingInferenceHasConvertedGoalAsPremise() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass subClass = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test:PremiseSub"));
		OWLClass superClass = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test:PremiseSuper"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);

		OwlInternalProof proof = new OwlInternalProof(
				(Reasoner) java.lang.reflect.Proxy.newProxyInstance(
						Reasoner.class.getClassLoader(),
						new Class<?>[] { Reasoner.class },
						(proxy, method, args) -> {
							if ("isEntailed".equals(method.getName())) {
								return true;
							}
							if (method.getReturnType() == boolean.class) {
								return false;
							}
							if (method.getReturnType() == int.class) {
								return 0;
							}
							if (method.getReturnType() == long.class) {
								return 0L;
							}
							return null;
						}),
				goal);
		Inference<Object> inference = proof.getInferences(goal).iterator()
				.next();

		Object expectedPremise = OwlConverter.getInstance().convert(goal);
		assertEquals(expectedPremise, inference.getPremises().get(0));
		assertEquals(goal, inference.getConclusion());
	}
}
