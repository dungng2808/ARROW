package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.owlapi.ElkReasoner;
import org.semanticweb.elk.owlapi.ElkReasonerFactory;
import org.semanticweb.elk.reasoner.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;

public class OwlInternalProof_ArrowTest {

	private ElkReasoner createReasoner()
			throws OWLOntologyCreationException {
		return (ElkReasoner) new ElkReasonerFactory().createReasoner(
				OWLManager.createOWLOntologyManager().createOntology());
	}

	@Test
	public void goalHasConvertingInference()
			throws OWLOntologyCreationException {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass sub = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test#Sub"));
		OWLClass sup = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test#Sup"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(sub, sup);

		ElkReasoner owlReasoner = createReasoner();
		try {
			Reasoner reasoner = owlReasoner.getInternalReasoner();
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			assertSame(goal, proof.getGoal());
			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(goal);
			assertNotNull(inferences);
			assertEquals(1, inferences.size());

			Inference<Object> inference = inferences.iterator().next();
			assertEquals("Converting inference", inference.getName());
			assertEquals(goal, inference.getConclusion());
			assertEquals(List.of(
					org.semanticweb.elk.owlapi.wrapper.OwlConverter
							.getInstance().convert(goal)),
					inference.getPremises());
		} finally {
			owlReasoner.dispose();
		}
	}

	@Test
	public void nonGoalConclusionIsDelegatedToInternalProof()
			throws OWLOntologyCreationException {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass sub = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test#Sub"));
		OWLClass sup = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test#Sup"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(sub, sup);
		OWLAxiom other = factory.getOWLSubClassOfAxiom(sup, sub);

		ElkReasoner owlReasoner = createReasoner();
		try {
			Reasoner reasoner = owlReasoner.getInternalReasoner();
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(other);
			assertNotNull(inferences);
			assertTrue(inferences.isEmpty());
			assertFalse(inferences.contains(null));
		} finally {
			owlReasoner.dispose();
		}
	}
}
