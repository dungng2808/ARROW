package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

import java.util.Collection;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.owlapi.wrapper.OwlConverter;
import org.semanticweb.elk.reasoner.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

public class OwlInternalProof_ArrowTest {

	private static Reasoner createReasoner() {
		return new Reasoner();
	}

	@Test
	public void goalIsReturnedAsConvertingInference() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass subClass = factory
				.getOWLClass(IRI.create("urn:test:Sub"));
		OWLClass superClass = factory
				.getOWLClass(IRI.create("urn:test:Super"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);

		OwlInternalProof proof = new OwlInternalProof(createReasoner(), goal);

		assertSame(goal, proof.getGoal());
		Collection<? extends Inference<Object>> inferences = proof
				.getInferences(goal);
		assertEquals(1, inferences.size());

		Inference<Object> inference = inferences.iterator().next();
		assertEquals("Converting inference", inference.getName());
		assertEquals(goal, inference.getConclusion());
		assertEquals(1, inference.getPremises().size());
		assertNotNull(inference.getPremises().get(0));
	}

	@Test
	public void nonGoalIsDelegatedToInternalProof() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass subClass = factory
				.getOWLClass(IRI.create("urn:test:Sub2"));
		OWLClass superClass = factory
				.getOWLClass(IRI.create("urn:test:Super2"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);
		OWLAxiom other = factory.getOWLDeclarationAxiom(
				factory.getOWLClass(IRI.create("urn:test:Other")));

		OwlInternalProof proof = new OwlInternalProof(createReasoner(), goal);

		Collection<? extends Inference<Object>> inferences = proof
				.getInferences(other);
		assertNotNull(inferences);
	}

	@Test
	public void goalComparisonUsesAxiomEquality() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass subClass = factory
				.getOWLClass(IRI.create("urn:test:EqualSub"));
		OWLClass superClass = factory
				.getOWLClass(IRI.create("urn:test:EqualSuper"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);
		OWLAxiom equalGoal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);

		OwlInternalProof proof = new OwlInternalProof(createReasoner(), goal);

		assertEquals(goal, equalGoal);
		assertEquals(1, proof.getInferences(equalGoal).size());
	}

	@Test
	public void convertingInferenceHasConvertedGoalAsPremise() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass subClass = factory
				.getOWLClass(IRI.create("urn:test:PremiseSub"));
		OWLClass superClass = factory
				.getOWLClass(IRI.create("urn:test:PremiseSuper"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(subClass,
				superClass);

		OwlInternalProof proof = new OwlInternalProof(createReasoner(), goal);
		Inference<Object> inference = proof.getInferences(goal).iterator()
				.next();

		Object expectedPremise = OwlConverter.getInstance().convert(goal);
		assertEquals(expectedPremise, inference.getPremises().get(0));
		assertEquals(goal, inference.getConclusion());
	}
}
