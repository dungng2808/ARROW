package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.owlapi.ElkReasoner;
import org.semanticweb.elk.reasoner.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;

public class OwlInternalProof_ArrowTest {

	@Test
	public void goalHasConvertingInference() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass sub = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test#Sub"));
		OWLClass sup = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test#Sup"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(sub, sup);

		ElkReasoner elkReasoner = (ElkReasoner) new ElkReasoner(
				OWLManager.createOWLOntologyManager().createOntology());
		Reasoner reasoner = elkReasoner.getInternalReasoner();
		try {
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			assertSame(goal, proof.getGoal());
			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(goal);
			assertNotNull(inferences);
			assertEquals(1, inferences.size());

			Inference<Object> inference = inferences.iterator().next();
			assertEquals("Converting inference", inference.getName());
			assertEquals(goal, inference.getConclusion());
			assertEquals(List.of(goal), inference.getPremises());
		} finally {
			elkReasoner.dispose();
		}
	}

	@Test
	public void nonGoalConclusionIsDelegatedToInternalProof() {
		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		OWLClass sub = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test#Sub"));
		OWLClass sup = factory.getOWLClass(
				org.semanticweb.owlapi.model.IRI.create("urn:test#Sup"));
		OWLSubClassOfAxiom goal = factory.getOWLSubClassOfAxiom(sub, sup);
		OWLAxiom other = factory.getOWLSubClassOfAxiom(sup, sub);

		ElkReasoner elkReasoner = (ElkReasoner) new ElkReasoner(
				OWLManager.createOWLOntologyManager().createOntology());
		Reasoner reasoner = elkReasoner.getInternalReasoner();
		try {
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(other);
			assertNotNull(inferences);
			assertTrue(inferences.isEmpty());
			assertFalse(inferences.contains(null));
		} finally {
			elkReasoner.dispose();
		}
	}
}
