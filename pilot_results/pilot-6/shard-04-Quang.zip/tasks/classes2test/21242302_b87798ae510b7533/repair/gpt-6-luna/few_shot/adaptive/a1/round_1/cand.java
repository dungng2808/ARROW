package eu.optique.r2rml.api.model.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.*;

public class TemplateImpl_ArrowTest {

    @Test
    public void parsesSegmentsAndColumnNames() {
        TemplateImpl template = new TemplateImpl("http://example.com/{id}/item/{name}");

        assertEquals(Arrays.asList("http://example.com/", "/item/"), template.getStringSegments());
        assertEquals(Arrays.asList("id", "name"), template.getColumnNames());
        assertEquals("http://example.com/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("http://example.com/{id}/item/{name}", template.toString());
    }

    @Test
    public void parsesTemplateWithoutColumns() {
        TemplateImpl template = new TemplateImpl("plain text");

        assertEquals(Collections.singletonList("plain text"), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("plain text", template.getTemplateStringWithoutColumnNames());
        assertEquals("plain text", template.toString());
    }

    @Test
    public void parsesEscapedBracesAsLiteralText() {
        TemplateImpl template = new TemplateImpl("literal \\{brace\\}");

        assertEquals(Collections.singletonList("literal \\{brace\\}"), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("literal \\{brace\\}", template.toString());
    }

    @Test
    public void rejectsUnmatchedOrNestedBraces() {
        assertIllegalArgumentException("prefix{column");
        assertIllegalArgumentException("prefix}suffix");
        assertIllegalArgumentException("{outer{inner}}");
    }

    @Test
    public void exposesSegmentsAndUnmodifiableColumnNames() {
        TemplateImpl template = new TemplateImpl("a{column}b");

        List<String> segments = template.getStringSegments();
        segments.set(0, "changed");
        assertEquals("changed", template.getStringSegment(0));

        try {
            template.getColumnNames().add("another");
            fail("Expected column names to be unmodifiable");
        } catch (UnsupportedOperationException expected) {
            // Expected.
        }
    }

    @Test
    public void addMethodsReplaceOrInsertAtRequestedIndex() {
        TemplateImpl template = new TemplateImpl("a{column}b");

        template.addStringSegment(0, "updated");
        template.addColumnName(0, "replacement");

        assertEquals("updated", template.getStringSegment(0));
        assertEquals("replacement", template.getColumnName(0));
    }

    @Test
    public void equalityAndHashCodeUseSegmentsAndColumns() {
        TemplateImpl first = new TemplateImpl("a{column}b");
        TemplateImpl same = new TemplateImpl("a{column}b");
        TemplateImpl different = new TemplateImpl("a{other}b");

        assertEquals(first, first);
        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertNotEquals(first, null);
        assertNotEquals(first, "a{column}b");
    }

    private static void assertIllegalArgumentException(String template) {
        try {
            new TemplateImpl(template);
            fail("Expected IllegalArgumentException for template: " + template);
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }
}
