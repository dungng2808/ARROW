package eu.optique.r2rml.api.model.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

public class TemplateImpl_ArrowTest {

    @Test
    public void parsesAlternatingSegmentsAndColumns() {
        TemplateImpl template = new TemplateImpl("http://example/{id}/item/{name}");

        assertEquals(Arrays.asList("http://example/", "/item/"), template.getStringSegments());
        assertEquals(Arrays.asList("id", "name"), template.getColumnNames());
        assertEquals("http://example/{}{}{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("http://example/{id}/item/{name}", template.toString());
    }

    @Test
    public void parsesTemplateWithoutColumns() {
        TemplateImpl template = new TemplateImpl("plain text");

        assertEquals(Collections.singletonList("plain text"), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("plain text", template.getTemplateStringWithoutColumnNames());
        assertEquals("plain text", template.toString());
    }

    @Test
    public void parsesColumnOnlyTemplate() {
        TemplateImpl template = new TemplateImpl("{id}");

        assertEquals(Collections.singletonList(""), template.getStringSegments());
        assertEquals(Collections.singletonList("id"), template.getColumnNames());
        assertEquals("{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("{id}", template.toString());
    }

    @Test
    public void escapedBracesRemainInStringSegments() {
        TemplateImpl template = new TemplateImpl("prefix\\{literal\\}/value/{id}");

        assertEquals(Collections.singletonList("prefix\\{literal\\}/value/"),
                template.getStringSegments());
        assertEquals(Collections.singletonList("id"), template.getColumnNames());
        assertEquals("prefix\\{literal\\}/value/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("prefix\\{literal\\}/value/{id}", template.toString());
    }

    @Test
    public void rejectsUnmatchedAndNestedBraces() {
        assertInvalid("{id");
        assertInvalid("id}");
        assertInvalid("{id{other}");
        assertInvalid("{{id}");
    }

    @Test
    public void exposesMutableSegmentsAndReadOnlyColumns() {
        TemplateImpl template = new TemplateImpl("a/{id}");

        template.addStringSegment(0, "changed/");
        assertEquals("changed/", template.getStringSegment(0));
        assertEquals(Collections.singletonList("changed/"), template.getStringSegments());

        template.addColumnName(0, "key");
        assertEquals("key", template.getColumnName(0));
        assertEquals(Collections.singletonList("key"), template.getColumnNames());

        try {
            template.getColumnNames().add("other");
            fail("Column names should be unmodifiable");
        } catch (UnsupportedOperationException expected) {
            // Expected.
        }
    }

    @Test
    public void equalityAndHashCodeUseSegmentsAndColumns() {
        TemplateImpl first = new TemplateImpl("a/{id}/b");
        TemplateImpl same = new TemplateImpl("a/{id}/b");
        TemplateImpl different = new TemplateImpl("a/{key}/b");

        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertFalse(first.equals(null));
        assertFalse(first.equals("a/{id}/b"));
        assertTrue(first.equals(first));
    }

    private static void assertInvalid(String value) {
        try {
            new TemplateImpl(value);
            fail("Expected invalid template: " + value);
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }
}
