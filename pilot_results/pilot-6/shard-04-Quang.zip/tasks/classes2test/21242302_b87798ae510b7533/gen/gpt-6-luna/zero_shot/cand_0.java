package eu.optique.r2rml.api.model.impl;

import eu.optique.r2rml.api.model.Template;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

public class TemplateImpl_ArrowTest {

    private TemplateImpl template(String value) {
        return new TemplateImpl(value);
    }

    @Test
    public void parsesSegmentsAndColumnNames() {
        TemplateImpl template = template("http://example.com/{id}/item/{name}");

        assertEquals(Arrays.asList("http://example.com/", "/item/"), template.getStringSegments());
        assertEquals(Arrays.asList("id", "name"), template.getColumnNames());
        assertEquals("http://example.com/{} /item/{}", template.getTemplateStringWithoutColumnNames()
                .replace("{}", "{}"));
        assertEquals("http://example.com/{id}/item/{name}", template.toString());
    }

    @Test
    public void parsesTemplatesWithoutColumnsAndWithAdjacentColumns() {
        TemplateImpl plain = template("plain text");
        assertEquals(Collections.singletonList("plain text"), plain.getStringSegments());
        assertTrue(plain.getColumnNames().isEmpty());
        assertEquals("plain text", plain.getTemplateStringWithoutColumnNames());

        TemplateImpl adjacent = template("{first}{second}");
        assertEquals(Arrays.asList("", ""), adjacent.getStringSegments());
        assertEquals(Arrays.asList("first", "second"), adjacent.getColumnNames());
        assertEquals("{}{}", adjacent.getTemplateStringWithoutColumnNames());
        assertEquals("{first}{second}", adjacent.toString());
    }

    @Test
    public void escapedBracesRemainInStringSegments() {
        TemplateImpl template = template("prefix\\{literal\\}/{}");
        assertEquals(Arrays.asList("prefix\\{literal\\}/", ""), template.getStringSegments());
        assertEquals(Collections.singletonList(""), template.getColumnNames());
        assertEquals("prefix\\{literal\\}/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("prefix\\{literal\\}/{}", template.toString());
    }

    @Test
    public void rejectsUnmatchedOrNestedUnescapedBraces() {
        for (String invalid : Arrays.asList("{", "}", "a{b", "a}b", "{{x}", "{x}}")) {
            try {
                template(invalid);
                fail("Expected invalid template: " + invalid);
            } catch (IllegalArgumentException expected) {
                // Expected.
            }
        }
    }

    @Test
    public void segmentAndColumnAccessorsAndMutatorsWork() {
        TemplateImpl template = template("a{x}b");

        assertEquals("a", template.getStringSegment(0));
        assertEquals("x", template.getColumnName(0));

        template.addStringSegment(0, "start");
        template.addColumnName(0, "key");
        assertEquals("start", template.getStringSegment(0));
        assertEquals("key", template.getColumnName(0));

        template.addStringSegment(1, "tail");
        template.addColumnName(1, "value");
        assertEquals(Arrays.asList("start", "tail"), template.getStringSegments());
        assertEquals(Arrays.asList("key", "value"), template.getColumnNames());

        try {
            template.getColumnNames().add("not allowed");
            fail("Column names should be unmodifiable");
        } catch (UnsupportedOperationException expected) {
            // Expected.
        }
    }

    @Test
    public void equalityAndHashCodeUseSegmentsAndColumns() {
        TemplateImpl first = template("a{x}b");
        TemplateImpl same = template("a{x}b");
        TemplateImpl differentColumn = template("a{y}b");
        TemplateImpl differentSegment = template("z{x}b");

        assertEquals(first, first);
        assertEquals(first, same);
        assertEquals(same, first);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, differentColumn);
        assertNotEquals(first, differentSegment);
        assertNotEquals(first, null);
        assertNotEquals(first, "a{x}b");
    }

    @Test
    public void emptyTemplateIsSupported() {
        TemplateImpl template = template("");
        assertEquals(Collections.singletonList(""), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("", template.getTemplateStringWithoutColumnNames());
        assertEquals("", template.toString());
    }
}
