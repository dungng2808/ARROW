package eu.optique.r2rml.api.model.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

class TemplateImpl_ArrowTest {

    @Test
    void parsesSegmentsAndColumnNames() {
        TemplateImpl template = new TemplateImpl("http://example.com/{id}/item/{name}");

        assertEquals(Arrays.asList("http://example.com/", "/item/"), template.getStringSegments());
        assertEquals(Arrays.asList("id", "name"), template.getColumnNames());
        assertEquals("http://example.com/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("http://example.com/{id}/item/{name}", template.toString());
    }

    @Test
    void parsesTemplateWithoutColumns() {
        TemplateImpl template = new TemplateImpl("plain text");

        assertEquals(Collections.singletonList("plain text"), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("plain text", template.getTemplateStringWithoutColumnNames());
        assertEquals("plain text", template.toString());
    }

    @Test
    void parsesEscapedBracesAsLiteralText() {
        TemplateImpl template = new TemplateImpl("literal \\{brace\\}");

        assertEquals(Collections.singletonList("literal \\{brace\\}"), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("literal \\{brace\\}", template.toString());
    }

    @Test
    void rejectsUnmatchedOrNestedBraces() {
        assertThrows(IllegalArgumentException.class, () -> new TemplateImpl("prefix{column"));
        assertThrows(IllegalArgumentException.class, () -> new TemplateImpl("prefix}suffix"));
        assertThrows(IllegalArgumentException.class, () -> new TemplateImpl("{outer{inner}}"));
    }

    @Test
    void exposesSegmentsAndUnmodifiableColumnNames() {
        TemplateImpl template = new TemplateImpl("a{column}b");

        List<String> segments = template.getStringSegments();
        segments.set(0, "changed");
        assertEquals("changed", template.getStringSegment(0));

        assertThrows(UnsupportedOperationException.class,
                () -> template.getColumnNames().add("another"));
    }

    @Test
    void addMethodsReplaceOrInsertAtRequestedIndex() {
        TemplateImpl template = new TemplateImpl("a{column}b");

        template.addStringSegment(0, "updated");
        template.addColumnName(0, "replacement");

        assertEquals("updated", template.getStringSegment(0));
        assertEquals("replacement", template.getColumnName(0));
    }

    @Test
    void equalityAndHashCodeUseSegmentsAndColumns() {
        TemplateImpl first = new TemplateImpl("a{column}b");
        TemplateImpl same = new TemplateImpl("a{column}b");
        TemplateImpl different = new TemplateImpl("a{other}b");

        assertEquals(first, first);
        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertNotEquals(first, null);
        assertNotEquals(first, "a{column}b");
    }
}
