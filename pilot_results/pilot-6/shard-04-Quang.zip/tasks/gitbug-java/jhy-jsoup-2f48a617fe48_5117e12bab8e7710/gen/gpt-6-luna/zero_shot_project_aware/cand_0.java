package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class Element_ArrowTest {
    @Test
    void tagNamesAndAttributesCanBeReadAndUpdated() {
        Element element = new Element("DIV");

        assertEquals("div", element.tagName());
        assertEquals("div", element.normalName());
        assertTrue(element.isBlock());

        assertSame(element, element.id("main").attr("title", "Example"));
        assertEquals("main", element.id());
        assertEquals("Example", element.attr("title"));

        element.attr("hidden", true);
        assertTrue(element.hasAttr("hidden"));
        element.attr("hidden", false);
        assertFalse(element.hasAttr("hidden"));
    }

    @Test
    void classOperationsKeepTheClassAttributeInSync() {
        Element element = new Element("div").attr("class", "alpha beta");

        assertTrue(element.hasClass("ALPHA"));
        assertEquals(new LinkedHashSet<>(Arrays.asList("alpha", "beta")), element.classNames());

        element.addClass("gamma").removeClass("alpha");
        assertEquals("beta gamma", element.className());

        element.toggleClass("beta");
        assertFalse(element.hasClass("beta"));
        element.toggleClass("delta");
        assertTrue(element.hasClass("delta"));

        element.classNames(Collections.<String>emptySet());
        assertEquals("", element.className());
        assertFalse(element.hasAttr("class"));
    }

    @Test
    void childElementCacheTracksMixedNodeMutations() {
        Element parent = new Element("div");
        Element first = new Element("p");
        Element second = new Element("span");

        parent.appendText("before").appendChild(first).appendText("between");
        assertEquals(1, parent.childrenSize());
        assertSame(first, parent.child(0));

        parent.appendChild(second);
        assertEquals(2, parent.childrenSize());
        assertSame(second, parent.child(1));
        assertSame(first, parent.firstElementChild());
        assertSame(second, parent.lastElementChild());

        parent.empty();
        assertEquals(0, parent.childrenSize());
        assertNull(parent.firstElementChild());
        assertNull(parent.lastElementChild());
    }

    @Test
    void insertionReparentsNodesAndMaintainsSiblingOrder() {
        Element left = new Element("div");
        Element right = new Element("div");
        Element child = new Element("p");

        left.appendChild(child);
        right.insertChildren(0, child);

        assertEquals(0, left.childNodeSize());
        assertSame(right, child.parent());
        assertSame(child, right.child(0));

        Element second = new Element("span");
        right.insertChildren(-1, second);
        assertSame(second, right.child(1));
        assertEquals(1, second.elementSiblingIndex());
    }

    @Test
    void textMethodsDistinguishOwnAndDescendantText() {
        Element paragraph = new Element("p");
        paragraph.appendText(" Hello   ");
        paragraph.appendElement("b").text("there");
        paragraph.appendText(" now!");

        assertEquals("Hello there now!", paragraph.text());
        assertEquals("Hello now!", paragraph.ownText());
        assertEquals(" Hello   there now!", paragraph.wholeText());
        assertEquals(" Hello    now!", paragraph.wholeOwnText());
        assertTrue(paragraph.hasText());
    }

    @Test
    void selectorsAndClosestFindMatchingElements() {
        Element root = new Element("div").attr("id", "root");
        Element section = root.appendElement("section").addClass("content");
        Element link = section.appendElement("a").attr("href", "/page").text("Read");

        assertSame(link, root.selectFirst("a[href]"));
        assertSame(section, link.closest(".content"));
        assertTrue(link.is("a[href='/page']"));
        assertEquals(1, root.getElementsByClass("content").size());
        assertSame(root, root.getElementById("root"));
        assertNull(root.selectFirst(".missing"));
    }

    @Test
    void siblingNavigationUsesElementChildrenOnly() {
        Element parent = new Element("div");
        Element first = parent.appendElement("i");
        parent.appendText("separator");
        Element middle = parent.appendElement("b");
        Element last = parent.appendElement("u");

        assertSame(first, middle.previousElementSibling());
        assertSame(last, middle.nextElementSibling());
        assertEquals(Arrays.asList(last), middle.nextElementSiblings());
        assertEquals(Arrays.asList(first), middle.previousElementSiblings());
        assertSame(first, last.firstElementSibling());
        assertSame(last, first.lastElementSibling());
        assertEquals(1, middle.elementSiblingIndex());
    }

    @Test
    void htmlAndDataNodesAreHandledSeparatelyFromVisibleText() {
        Element element = new Element("div");
        element.html("<p>One &amp; two</p><script>var x = 1;</script>");

        assertEquals("<p>One &amp; two</p><script>var x = 1;</script>", element.html());
        assertEquals("One & two", element.text());
        assertEquals("var x = 1;", element.selectFirst("script").data());
        assertEquals(1, element.selectFirst("script").dataNodes().size());
    }

    @Test
    void cloneIsIndependentAndCssSelectorCanUseId() {
        Element original = new Element("div").id("unique").appendElement("p").text("original");
        Element clone = original.clone();

        assertNotSame(original, clone);
        assertEquals(original.outerHtml(), clone.outerHtml());
        clone.selectFirst("p").text("changed");
        assertEquals("original", original.selectFirst("p").text());
        assertEquals("#unique", original.cssSelector());
    }

    @Test
    void invalidInputsAreRejected() {
        Element element = new Element("div");

        assertThrows(IllegalArgumentException.class, () -> element.tagName(""));
        assertThrows(IllegalArgumentException.class, () -> element.insertChildren(2, new Element("p")));
        assertThrows(IllegalArgumentException.class, () -> element.getElementsByTag(""));
        assertThrows(IllegalArgumentException.class, () -> element.getElementsMatchingText("["));
    }
}
