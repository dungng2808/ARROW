package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Element_ArrowTest {
    @Test
    void childElementCacheReflectsMutationsAndMixedNodes() {
        Element parent = new Element("div");
        parent.appendText("before");
        Element first = parent.appendElement("p");
        parent.appendText("between");
        Element second = parent.appendElement("span");

        assertEquals(2, parent.childrenSize());
        assertSame(first, parent.child(0));
        assertSame(second, parent.child(1));
        assertSame(first, parent.firstElementChild());
        assertSame(second, parent.lastElementChild());

        Element inserted = new Element("b");
        parent.insertChildren(1, inserted);
        assertEquals(3, parent.childrenSize());
        assertSame(inserted, parent.child(1));
        assertSame(second, parent.child(2));

        parent.empty();
        assertEquals(0, parent.childrenSize());
        assertNull(parent.firstElementChild());
        assertNull(parent.lastElementChild());
    }

    @Test
    void siblingNavigationUsesElementSiblingsOnly() {
        Element parent = new Element("div");
        Element first = parent.appendElement("i");
        parent.appendText("text");
        Element middle = parent.appendElement("b");
        parent.appendText("more");
        Element last = parent.appendElement("u");

        assertSame(middle, first.nextElementSibling());
        assertNull(first.previousElementSibling());
        assertSame(first, middle.previousElementSibling());
        assertSame(last, middle.nextElementSibling());
        assertNull(last.nextElementSibling());
        assertEquals(1, middle.elementSiblingIndex());
        assertSame(first, middle.firstElementSibling());
        assertSame(last, middle.lastElementSibling());
        assertEquals(2, middle.siblingElements().size());
        assertEquals(1, middle.nextElementSiblings().size());
        assertEquals(1, middle.previousElementSiblings().size());
    }

    @Test
    void textMethodsDistinguishOwnCombinedAndWholeText() {
        Element paragraph = new Element("p");
        paragraph.appendText(" Hello  ");
        paragraph.appendElement("b").text("there");
        paragraph.appendText(" now!");

        assertEquals("Hello there now!", paragraph.text());
        assertEquals("Hello now!", paragraph.ownText());
        assertEquals(" Hello  there now!", paragraph.wholeText());
        assertEquals(" Hello   now!", paragraph.wholeOwnText());
        assertTrue(paragraph.hasText());

        Element blank = new Element("div").appendText(" \n ");
        assertFalse(blank.hasText());
    }

    @Test
    void classOperationsAndSelectorQueriesWorkTogether() {
        Element root = new Element("div");
        Element item = root.appendElement("span").attr("class", "alpha beta");
        item.addClass("gamma");

        assertTrue(item.hasClass("ALPHA"));
        assertEquals("alpha beta gamma", item.className());
        assertEquals(1, root.getElementsByClass("beta").size());
        assertSame(item, root.selectFirst(".gamma"));
        assertSame(item, root.getElementById("missing") == null ? item : null);

        item.removeClass("beta");
        assertFalse(item.hasClass("beta"));
        item.toggleClass("gamma");
        assertFalse(item.hasClass("gamma"));
    }

    @Test
    void baseUriIsInheritedAndCanBeOverridden() {
        Element parent = new Element(Tag.valueOf("div"), "https://example.test/base/");
        Element child = parent.appendElement("a");
        assertEquals("https://example.test/base/", child.baseUri());

        child.attr("href", "next");
        child.setBaseUri("https://other.test/");
        assertEquals("https://other.test/", child.baseUri());
        assertEquals("https://example.test/base/", parent.baseUri());
    }

    @Test
    void cloneIsIndependentAndPreservesContent() {
        Element original = new Element("div").attr("id", "source");
        original.appendElement("p").text("content");

        Element clone = original.clone();
        assertEquals(original.outerHtml(), clone.outerHtml());
        assertNotSame(original, clone);
        assertNotSame(original.child(0), clone.child(0));

        clone.attr("id", "copy");
        clone.child(0).text("changed");
        assertEquals("source", original.id());
        assertEquals("content", original.text());
    }

    @Test
    void invalidInputsAreRejected() {
        Element element = new Element("div");
        assertThrows(IllegalArgumentException.class, () -> element.tagName(""));
        assertThrows(IllegalArgumentException.class, () -> element.insertChildren(2, new Element("p")));
        assertThrows(IllegalArgumentException.class, () -> element.getElementsByTag(""));
        assertThrows(IllegalArgumentException.class, () -> element.getElementsMatchingText("["));
    }
}
