package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class Element_ArrowTest {

    @Test
    void tagNamesAndAttributes() {
        Element element = new Element("div");

        assertEquals("div", element.tagName());
        assertEquals("div", element.normalName());
        assertTrue(element.isBlock());

        assertSame(element, element.id("main"));
        assertEquals("main", element.id());
        assertSame(element, element.attr("title", "hello"));
        assertEquals("hello", element.attr("title"));

        element.attr("hidden", true);
        assertTrue(element.hasAttr("hidden"));
        element.attr("hidden", false);
        assertFalse(element.hasAttr("hidden"));

        assertSame(element, element.tagName("section"));
        assertEquals("section", element.tagName());
    }

    @Test
    void childElementsAndTextNodes() {
        Element parent = new Element("div");
        parent.appendText("before");
        Element first = parent.appendElement("span").text("one");
        parent.appendText("middle");
        Element second = parent.appendElement("b").text("two");

        assertEquals(4, parent.childNodeSize());
        assertEquals(2, parent.childrenSize());
        assertEquals(Arrays.asList(first, second), parent.children());
        assertSame(first, parent.child(0));
        assertSame(second, parent.child(1));
        assertSame(first, parent.firstElementChild());
        assertSame(second, parent.lastElementChild());
        assertEquals(2, parent.textNodes().size());
        assertEquals("before middle", parent.ownText());
        assertEquals("before one middle two", parent.text());
    }

    @Test
    void siblingNavigation() {
        Element parent = new Element("div");
        Element first = parent.appendElement("p");
        Element second = parent.appendElement("p");
        Element third = parent.appendElement("p");

        assertSame(first, second.previousElementSibling());
        assertSame(third, second.nextElementSibling());
        assertSame(first, second.firstElementSibling());
        assertSame(third, second.lastElementSibling());
        assertEquals(1, second.elementSiblingIndex());
        assertEquals(Arrays.asList(first, third), second.siblingElements());
        assertEquals(Collections.singletonList(third), second.nextElementSiblings());
        assertEquals(Collections.singletonList(first), second.previousElementSiblings());
    }

    @Test
    void selectorsAndTraversal() {
        Element root = new Element("div").attr("id", "root");
        Element item = root.appendElement("p").addClass("item").text("hello");
        root.appendElement("p").addClass("other").text("world");

        assertSame(item, root.selectFirst(".item"));
        assertSame(item, root.getElementById("missing") == null ? root.selectFirst("p.item") : null);
        assertEquals(2, root.getElementsByTag("p").size());
        assertTrue(item.is("p.item"));
        assertSame(item, item.closest("#root").selectFirst("p.item"));
        assertEquals(3, root.getAllElements().size());
        assertEquals("hello", item.text());
        assertTrue(root.hasText());
    }

    @Test
    void classOperations() {
        Element element = new Element("div").attr("class", "alpha beta");
        assertTrue(element.hasClass("ALPHA"));
        assertEquals(new LinkedHashSet<>(Arrays.asList("alpha", "beta")), element.classNames());

        element.addClass("gamma").removeClass("alpha");
        assertEquals("beta gamma", element.className());
        element.toggleClass("beta");
        assertFalse(element.hasClass("beta"));
        element.toggleClass("delta");
        assertTrue(element.hasClass("delta"));

        element.classNames(Collections.emptySet());
        assertEquals("", element.className());
    }

    @Test
    void htmlAndCloning() {
        Element element = new Element("div");
        element.html("<p>one</p><p>two</p>");

        assertEquals(2, element.childrenSize());
        assertEquals("onetwo", element.text().replace(" ", ""));
        assertTrue(element.html().contains("<p>one</p>"));

        Element clone = element.clone();
        assertEquals(element.outerHtml(), clone.outerHtml());
        assertNotSame(element, clone);
        assertNotSame(element.child(0), clone.child(0));

        element.empty();
        assertEquals(0, element.childNodeSize());
        assertEquals("", element.html());
    }

    @Test
    void baseUriAndDataset() {
        Element parent = new Element("div", "https://example.com/");
        Element child = parent.appendElement("a").attr("data-kind", "link");

        assertEquals("https://example.com/", child.baseUri());
        assertEquals("link", child.dataset().get("kind"));
        child.dataset().put("state", "active");
        assertEquals("active", child.attr("data-state"));
    }

    @Test
    void insertionAndReparenting() {
        Element firstParent = new Element("div");
        Element child = firstParent.appendElement("p");
        Element secondParent = new Element("section");

        secondParent.appendChild(child);
        assertEquals(0, firstParent.childrenSize());
        assertSame(secondParent, child.parent());

        secondParent.prependElement("h1");
        assertEquals("h1", secondParent.child(0).tagName());
        secondParent.insertChildren(-1, new Element("footer"));
        assertEquals("footer", secondParent.child(secondParent.childrenSize() - 1).tagName());
    }

    @Test
    void dataAndWholeText() {
        Element element = new Element("div");
        element.appendText(" a  b ");
        element.appendElement("br");
        element.appendChild(new DataNode("payload"));

        assertEquals(" a  b \n", element.wholeText());
        assertEquals(" a  b ", element.wholeOwnText());
        assertEquals("payload", element.data());
        assertEquals(1, element.dataNodes().size());
    }

    @Test
    void invalidInputsAreRejected() {
        Element element = new Element("div");
        assertThrows(IllegalArgumentException.class, () -> element.tagName(""));
        assertThrows(IllegalArgumentException.class, () -> element.getElementsByTag(""));
        assertThrows(IllegalArgumentException.class, () -> element.getElementById(""));
        assertThrows(IllegalArgumentException.class, () -> element.getElementsMatchingText("["));
    }
}
