package com.jitterted.mobreg.domain;

import static org.junit.jupiter.api.Assertions.*;

import java.net.URI;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import org.junit.jupiter.api.Test;

class Ensemble_ArrowTest {

    private static final ZonedDateTime START =
            ZonedDateTime.of(2030, 5, 10, 12, 0, 0, 0, ZoneOffset.UTC);

    private MemberId member(String value) {
        return new MemberId(value);
    }

    @Test
    void initializesWithScheduledStateAndDefaultDetails() {
        Ensemble ensemble = new Ensemble("Practice", START);

        assertEquals("Practice", ensemble.name());
        assertEquals(START, ensemble.startDateTime());
        assertEquals(EnsembleState.SCHEDULED, ensemble.state());
        assertEquals(URI.create("https://zoom.us"), ensemble.meetingLink());
        assertEquals(URI.create(""), ensemble.recordingLink());
        assertEquals(0, ensemble.acceptedCount());
        assertTrue(ensemble.canAccept());
    }

    @Test
    void acceptsMembersAndMaintainsRsvpMembership() {
        Ensemble ensemble = new Ensemble("Practice", START);
        MemberId member = member("member-1");

        ensemble.declinedBy(member);
        assertEquals(Rsvp.DECLINED, ensemble.rsvpOf(member));
        assertTrue(ensemble.isDeclined(member));

        ensemble.acceptedBy(member);
        assertEquals(Rsvp.ACCEPTED, ensemble.rsvpOf(member));
        assertTrue(ensemble.isAccepted(member));
        assertFalse(ensemble.isDeclined(member));
        assertEquals(1, ensemble.acceptedCount());
        assertEquals(List.of(member), ensemble.acceptedMembers().toList());
        assertEquals(0, ensemble.declinedCount());
    }

    @Test
    void spectatorMembershipRemovesAcceptedAndDeclinedRsvp() {
        Ensemble ensemble = new Ensemble("Practice", START);
        MemberId member = member("member-1");

        ensemble.acceptedBy(member);
        ensemble.joinAsSpectator(member);

        assertFalse(ensemble.isAccepted(member));
        assertEquals(Rsvp.UNKNOWN, ensemble.rsvpOf(member));
        assertTrue(ensemble.spectators().contains(member));

        ensemble.declinedBy(member);
        assertTrue(ensemble.isDeclined(member));
        assertFalse(ensemble.spectators().contains(member));
    }

    @Test
    void limitsAcceptedMembersToFive() {
        Ensemble ensemble = new Ensemble("Practice", START);
        for (int i = 0; i < 5; i++) {
            ensemble.acceptedBy(member("member-" + i));
        }

        assertEquals(5, ensemble.acceptedCount());
        assertFalse(ensemble.canAccept());
        assertThrows(EnsembleFullException.class, () -> ensemble.acceptedBy(member("extra")));
    }

    @Test
    void changesNameStartTimeAndMeetingLink() {
        Ensemble ensemble = new Ensemble("Practice", START);
        ZonedDateTime newStart = START.plusDays(1);
        URI newLink = URI.create("https://example.com/meeting");

        ensemble.changeNameTo("Rehearsal");
        ensemble.changeStartDateTimeTo(newStart);
        ensemble.changeMeetingLinkTo(newLink);

        assertEquals("Rehearsal", ensemble.name());
        assertEquals(newStart, ensemble.startDateTime());
        assertEquals(newLink, ensemble.meetingLink());
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeNameTo(null));
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeStartDateTimeTo(null));
    }

    @Test
    void completesAndPreventsFurtherAcceptance() {
        Ensemble ensemble = new Ensemble("Practice", START);
        ensemble.complete();

        assertTrue(ensemble.isCompleted());
        assertEquals(EnsembleState.COMPLETED, ensemble.state());
        assertThrows(EnsembleCompleted.class, () -> ensemble.acceptedBy(member("member")));
        assertThrows(EnsembleCompleted.class, ensemble::cancel);
    }

    @Test
    void cancelsAndPreventsAcceptance() {
        Ensemble ensemble = new Ensemble("Practice", START);
        ensemble.cancel();

        assertTrue(ensemble.isCanceled());
        assertEquals(EnsembleState.CANCELED, ensemble.state());
        assertThrows(EnsembleCanceled.class, () -> ensemble.acceptedBy(member("member")));
    }

    @Test
    void managesRecordingAndConferenceDetails() {
        Ensemble ensemble = new Ensemble("Practice", START);
        URI recording = URI.create("https://example.com/recording");
        ConferenceDetails details =
                new ConferenceDetails("code", URI.create("https://example.com"), URI.create("https://example.com/join"));

        ensemble.linkToRecordingAt(recording);
        ensemble.changeConferenceDetailsTo(details);

        assertEquals(recording, ensemble.recordingLink());
        assertSame(details, ensemble.conferenceDetails());

        ensemble.removeConferenceDetails();
        assertSame(ConferenceDetails.DELETED, ensemble.conferenceDetails());
    }

    @Test
    void reportsMemberStatusForFutureEnsemble() {
        Ensemble ensemble = new Ensemble("Practice", START);
        MemberId accepted = member("accepted");
        MemberId declined = member("declined");
        MemberId unknown = member("unknown");

        ensemble.acceptedBy(accepted);
        ensemble.declinedBy(declined);

        assertEquals(MemberStatus.ACCEPTED, ensemble.statusFor(accepted, START.minusMinutes(1)));
        assertEquals(MemberStatus.DECLINED, ensemble.statusFor(declined, START.minusMinutes(1)));
        assertEquals(MemberStatus.UNKNOWN, ensemble.statusFor(unknown, START.minusMinutes(1)));
    }

    @Test
    void reportsGracePeriodAndStartedStatuses() {
        Ensemble ensemble = new Ensemble("Practice", START);
        MemberId accepted = member("accepted");
        MemberId unknown = member("unknown");
        ensemble.acceptedBy(accepted);

        assertEquals(MemberStatus.IN_GRACE_PERIOD, ensemble.statusFor(accepted, START.plusMinutes(5)));
        assertEquals(MemberStatus.IN_GRACE_PERIOD, ensemble.statusFor(unknown, START.plusMinutes(5)));
        assertEquals(MemberStatus.PENDING_COMPLETED, ensemble.statusFor(accepted, START.plusMinutes(11)));
        assertEquals(MemberStatus.HIDDEN, ensemble.statusFor(unknown, START.plusMinutes(11)));
    }

    @Test
    void canceledStatusHidesNonAcceptedMembersAndMarksAcceptedCanceled() {
        Ensemble ensemble = new Ensemble("Practice", START);
        MemberId accepted = member("accepted");
        MemberId unknown = member("unknown");
        ensemble.acceptedBy(accepted);
        ensemble.cancel();

        assertEquals(MemberStatus.CANCELED, ensemble.statusFor(accepted, START.minusDays(1)));
        assertEquals(MemberStatus.HIDDEN, ensemble.statusFor(unknown, START.minusDays(1)));
    }
}
