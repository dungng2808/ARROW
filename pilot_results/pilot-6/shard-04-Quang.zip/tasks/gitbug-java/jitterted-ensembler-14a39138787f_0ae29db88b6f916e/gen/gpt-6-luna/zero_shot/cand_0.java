package com.jitterted.mobreg.domain;

import org.junit.jupiter.api.Test;

import java.net.URI;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class Ensemble_ArrowTest {
    private static final ZonedDateTime START =
            ZonedDateTime.of(2030, 5, 10, 12, 0, 0, 0, ZoneOffset.UTC);

    private MemberId member(String value) {
        return new MemberId(value);
    }

    private Ensemble ensemble() {
        return new Ensemble("Mob session", START);
    }

    @Test
    void initializesWithScheduledStateAndDefaultMeetingDetails() {
        Ensemble ensemble = ensemble();

        assertEquals("Mob session", ensemble.name());
        assertEquals(START, ensemble.startDateTime());
        assertEquals(EnsembleState.SCHEDULED, ensemble.state());
        assertEquals(URI.create("https://zoom.us"), ensemble.meetingLink());
        assertEquals(0, ensemble.acceptedCount());
        assertEquals(0, ensemble.declinedCount());
        assertTrue(ensemble.canAccept());
        assertFalse(ensemble.isCompleted());
        assertFalse(ensemble.isCanceled());
    }

    @Test
    void updatesIdentityNameAndStartTime() {
        Ensemble ensemble = ensemble();
        EnsembleId id = new EnsembleId();
        ZonedDateTime newStart = START.plusDays(2);

        ensemble.setId(id);
        ensemble.changeNameTo("New name");
        ensemble.changeStartDateTimeTo(newStart);

        assertEquals(id, ensemble.getId());
        assertEquals("New name", ensemble.name());
        assertEquals(newStart, ensemble.startDateTime());
    }

    @Test
    void rejectsNullNameAndStartTime() {
        Ensemble ensemble = ensemble();

        assertThrows(IllegalArgumentException.class, () -> ensemble.changeNameTo(null));
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeStartDateTimeTo(null));
    }

    @Test
    void acceptanceDeclineAndSpectatorChangesAreMutuallyExclusive() {
        Ensemble ensemble = ensemble();
        MemberId member = member("member-1");

        ensemble.acceptedBy(member);
        assertTrue(ensemble.isAccepted(member));
        assertEquals(Rsvp.ACCEPTED, ensemble.rsvpOf(member));
        assertEquals(1, ensemble.acceptedCount());

        ensemble.declinedBy(member);
        assertFalse(ensemble.isAccepted(member));
        assertTrue(ensemble.isDeclined(member));
        assertEquals(Rsvp.DECLINED, ensemble.rsvpOf(member));
        assertEquals(0, ensemble.acceptedCount());
        assertEquals(1, ensemble.declinedCount());

        ensemble.joinAsSpectator(member);
        assertFalse(ensemble.isAccepted(member));
        assertFalse(ensemble.isDeclined(member));
        assertTrue(ensemble.spectators().contains(member));
        assertEquals(Rsvp.UNKNOWN, ensemble.rsvpOf(member));

        ensemble.acceptedBy(member);
        assertTrue(ensemble.isAccepted(member));
        assertFalse(ensemble.isDeclined(member));
        assertFalse(ensemble.spectators().contains(member));
    }

    @Test
    void acceptedAndDeclinedMembersAreExposedAsStreams() {
        Ensemble ensemble = ensemble();
        MemberId accepted = member("accepted");
        MemberId declined = member("declined");

        ensemble.acceptedBy(accepted);
        ensemble.declinedBy(declined);

        assertEquals(List.of(accepted), ensemble.acceptedMembers().toList());
        assertEquals(List.of(declined), ensemble.declinedMembers().toList());
    }

    @Test
    void limitsAcceptedMembersToFive() {
        Ensemble ensemble = ensemble();
        for (int i = 0; i < 5; i++) {
            ensemble.acceptedBy(member("member-" + i));
        }

        assertEquals(5, ensemble.acceptedCount());
        assertFalse(ensemble.canAccept());
        assertThrows(EnsembleFullException.class, () -> ensemble.acceptedBy(member("extra")));
    }

    @Test
    void changingMeetingAndConferenceDetailsUpdatesDetails() {
        Ensemble ensemble = ensemble();
        URI meeting = URI.create("https://example.test/meeting");
        ConferenceDetails details =
                new ConferenceDetails("Room", URI.create("https://example.test/info"), meeting);

        ensemble.changeMeetingLinkTo(meeting);
        assertEquals(meeting, ensemble.meetingLink());

        ensemble.changeConferenceDetailsTo(details);
        assertEquals(details, ensemble.conferenceDetails());
        assertEquals(meeting, ensemble.meetingLink());

        ensemble.removeConferenceDetails();
        assertEquals(ConferenceDetails.DELETED, ensemble.conferenceDetails());
    }

    @Test
    void recordingLinkCanBeChanged() {
        Ensemble ensemble = ensemble();
        URI recording = URI.create("https://example.test/recording");

        assertEquals(URI.create(""), ensemble.recordingLink());
        ensemble.linkToRecordingAt(recording);
        assertEquals(recording, ensemble.recordingLink());
    }

    @Test
    void completesAndPreventsFurtherAcceptance() {
        Ensemble ensemble = ensemble();
        ensemble.complete();

        assertTrue(ensemble.isCompleted());
        assertEquals(EnsembleState.COMPLETED, ensemble.state());
        assertThrows(EnsembleCompleted.class, () -> ensemble.acceptedBy(member("member")));
        assertThrows(EnsembleCompleted.class, ensemble::cancel);
    }

    @Test
    void cancelsAndPreventsAcceptanceButCanBeCompleted() {
        Ensemble ensemble = ensemble();
        ensemble.cancel();

        assertTrue(ensemble.isCanceled());
        assertEquals(EnsembleState.CANCELED, ensemble.state());
        assertThrows(EnsembleCanceled.class, () -> ensemble.acceptedBy(member("member")));

        Ensemble another = ensemble();
        another.cancel();
        assertThrows(EnsembleCanceled.class, another::complete);
    }

    @Test
    void reportsStatusesForFutureEnsemble() {
        Ensemble ensemble = ensemble();
        MemberId unknown = member("unknown");
        MemberId declined = member("declined");
        MemberId accepted = member("accepted");

        ensemble.declinedBy(declined);
        ensemble.acceptedBy(accepted);

        ZonedDateTime beforeStart = START.minusMinutes(1);
        assertEquals(MemberStatus.UNKNOWN, ensemble.statusFor(unknown, beforeStart));
        assertEquals(MemberStatus.DECLINED, ensemble.statusFor(declined, beforeStart));
        assertEquals(MemberStatus.ACCEPTED, ensemble.statusFor(accepted, beforeStart));
    }

    @Test
    void reportsGracePeriodAndInProgressStatuses() {
        Ensemble ensemble = ensemble();
        MemberId accepted = member("accepted");
        MemberId unknown = member("unknown");
        ensemble.acceptedBy(accepted);

        assertEquals(MemberStatus.IN_GRACE_PERIOD,
                ensemble.statusFor(accepted, START.plusMinutes(5)));
        assertEquals(MemberStatus.IN_GRACE_PERIOD,
                ensemble.statusFor(unknown, START.plusMinutes(5)));
        assertEquals(MemberStatus.PENDING_COMPLETED,
                ensemble.statusFor(accepted, START.plusMinutes(11)));
        assertEquals(MemberStatus.HIDDEN,
                ensemble.statusFor(unknown, START.plusMinutes(11)));
    }

    @Test
    void reportsCompletedAndCanceledStatuses() {
        Ensemble ensemble = ensemble();
        MemberId accepted = member("accepted");
        MemberId unknown = member("unknown");
        ensemble.acceptedBy(accepted);
        ensemble.complete();

        assertEquals(MemberStatus.COMPLETED,
                ensemble.statusFor(accepted, START.plusHours(3)));

        Ensemble canceled = ensemble();
        canceled.acceptedBy(accepted);
        canceled.cancel();

        assertEquals(MemberStatus.CANCELED,
                canceled.statusFor(accepted, START.minusDays(1)));
        assertEquals(MemberStatus.HIDDEN,
                canceled.statusFor(unknown, START.minusDays(1)));
    }
}
