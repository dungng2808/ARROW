# Báo cáo ARROW: pilot-v1

## Thông tin run

- Run `pilot-6-Quang`: experiment sha256 `45189e747717`, máy `Quang` (win-x64), tool 0.1.0 commit `3976205273471ed39766d5bba4ebd917a3c7a457`, tạo lúc 2026-10-15 14:03
- Model id trả về: gpt-6-luna → gpt-6-luna

## Khối 1: task dùng được và bị loại

- classes2test: 8 dùng được, 0 bị loại, 0 INFRA
- gitbug-java: 2 dùng được, 0 bị loại, 0 INFRA

## RQ1: tính hợp lệ của candidate ban đầu (6.1)

Classes2Test (content-matched) và GitBug-Java (upstream-pinned) báo cáo tách riêng. Mẫu số gồm cả output không hợp lệ, không gồm INFRA.

| dataset | model | strategy | candidates | compile | discovery | execution | target_pass | valid | invalid_output | infra |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | few_shot | 8 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| classes2test | gpt-6-luna | zero_shot | 8 | 2 | 2 | 2 | 1 | 1 | 0 | 0 |
| classes2test | gpt-6-luna | zero_shot_project_aware | 8 | 4 | 4 | 4 | 3 | 3 | 0 | 0 |
| gitbug-java | gpt-6-luna | few_shot | 2 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| gitbug-java | gpt-6-luna | zero_shot | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| gitbug-java | gpt-6-luna | zero_shot_project_aware | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

## RQ2: hiệu quả sửa (6.2)

Chỉ tính candidate mà mọi cơ chế đều chạy xong. Chain không thành công tính bằng N.

| dataset | model | mechanism | chains | success | success_rate | attempts_mean | attempts_median | time_mean_s | time_median_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | adaptive | 20 | 20 | 1 | 2.1 | 1.5 | 100.4 | 53.4 |
| classes2test | gpt-6-luna | fixed | 20 | 18 | 0.9 | 2.4 | 1.5 | 98.8 | 59.7 |

## RQ2: số lần kích hoạt các cơ chế (mô tả, không chứng minh nhân quả)

| dataset | model | mechanism | rollback | duplicate_code | invalid_output | repeated_signature | level_up | state_change | level3_rounds | dropped_methods |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | adaptive | 5 | 1 | 0 | 3 | 8 | 26 | 2 | 12 |
| classes2test | gpt-6-luna | fixed | 0 | 0 | 0 | 0 | 0 | 24 | 0 | 8 |

## Chọn N (pilot, 6.3): N = 10

S(k) gộp chain của cả hai cơ chế trên Classes2Test; pilot không xem kết quả so sánh hai cơ chế.

| round | successes_cumulative | share_of_round_n |
| --- | --- | --- |
| 1 | 20 | 0.5263 |
| 2 | 33 | 0.8684 |
| 3 | 35 | 0.9211 |
| 4 | 36 | 0.9474 |
| 5 | 36 | 0.9474 |
| 6 | 37 | 0.9737 |
| 7 | 37 | 0.9737 |
| 8 | 38 | 1 |
| 9 | 38 | 1 |
| 10 | 38 | 1 |

## Độ nhạy P của dừng sớm (6.4)

Tính lại từ decision.json, không gọi thêm model.

| dataset | model | p | chains | success | success_rate | rounds_mean | time_mean_s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | 1 | 20 | 15 | 0.75 | 1.4 | 63.5 |
| classes2test | gpt-6-luna | 2 | 20 | 18 | 0.9 | 1.65 | 72.9 |
| classes2test | gpt-6-luna | 3 | 20 | 18 | 0.9 | 1.9 | 82.1 |
| classes2test | gpt-6-luna | none | 20 | 20 | 1 | 2.1 | 100.4 |

## RQ3: chất lượng bộ test VALID (6.5)

Ghép cặp theo từng chỉ số; n_pairs riêng cho mỗi chỉ số.

| dataset | model | metric | n_pairs | arrow_mean | evosuite_mean | arrow_median | evosuite_median | mean_diff | arrow_sd | evosuite_sd |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | line | 4 | 0.8527 | 0 | 0.8388 | 0 | 0.8527 | 0.1126 | 0 |
| classes2test | gpt-6-luna | branch | 3 | 0.6695 | 0 | 0.7586 | 0 | 0.6695 | 0.3829 | 0 |
| classes2test | gpt-6-luna | method | 4 | 0.945 | 0 | 0.9616 | 0 | 0.945 | 0.0689 | 0 |
| classes2test | gpt-6-luna | mutation_score | 3 | 0.7167 | 0.3556 | 0.75 | 0.4 | 0.3611 | 0.3014 | 0.3356 |
| classes2test | gpt-6-luna | smell_density | 4 | 4.2351 | 2.6733 | 4.4167 | 2.6323 | 1.5618 | 1.489 | 0.7804 |

## RQ3: tập so sánh

| dataset | model | both | only_arrow | only_evosuite | dropped_line | dropped_branch | dropped_method | dropped_mutation_score | dropped_smell_density |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| classes2test | gpt-6-luna | 4 | 4 | 0 | 0 | 1 | 0 | 1 | 0 |

## Chi phí (6.6)

| dataset | block | llm_calls | tokens_in | tokens_out | cost_usd | finish_length |
| --- | --- | --- | --- | --- | --- | --- |
| classes2test | 2 | 24 | 53630 | 13949 | 0.0062 | 0 |
| classes2test | 3 | 90 | 287633 | 56848 | 0.0286 | 0 |
| gitbug-java | 2 | 6 | 36054 | 7125 | 0.0036 | 0 |
| gitbug-java | 3 | 0 | 0 | 0 | 0 | 0 |

## Thời gian từng bước (6.6)

| step | count | median_s | p90_s | max_s |
| --- | --- | --- | --- | --- |
| llm | 120 | 8.9 | 17.1 | 61.5 |
| verify_build | 119 | 18.9 | 57.6 | 200.1 |
| evosuite | 10 | 138.4 | 194.5 | 301 |
| jacoco | 46 | 19.6 | 67.5 | 77.4 |
| pit | 46 | 12.5 | 53.2 | 66.6 |
| tsdetect | 46 | 0.6 | 5.3 | 14.4 |

## Task bị loại

(không có dữ liệu)

## Cần chạy lại riêng

Danh sách rỗng: run hoàn chỉnh.

(không có dữ liệu)
## Ngoại lệ đã khai báo

- Cờ build chung tắt checkstyle, spotless, enforcer, JaCoCo của dự án…; JVM chạy với `-Dfile.encoding=UTF-8 -Duser.language=en -Duser.country=US -Duser.timezone=UTC`.
- Bộ EvoSuite cần `evosuite-standalone-runtime` trong classpath test (Maven: dependency scope `system` chỉ trong bản sao; Gradle: init script).
- JaCoCo gắn qua `JAVA_TOOL_OPTIONS` với `includes=<FQN>:<FQN>$*`; PIT dùng `--targetClasses <FQN>,<FQN>$*`.

## Hạn chế

- Thực nghiệm chạy một lần cho mỗi cấu hình; các con số cơ chế là thống kê mô tả.
- Commit của Classes2Test là content-matched: tái lập được nhưng không bảo đảm là commit tác giả dataset đã dùng.
