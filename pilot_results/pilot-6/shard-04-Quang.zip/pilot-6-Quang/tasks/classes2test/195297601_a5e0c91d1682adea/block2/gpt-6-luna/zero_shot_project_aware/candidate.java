package de.hegmanns.tdd.task04;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

public class AddMashine_ArrowTest {

    @Test
    public void constructorInitializesSum() {
        // Arrange
        AddMashine machine = new AddMashine(12L);

        // Act
        Long sum = machine.getSum();

        // Assert
        assertEquals(Long.valueOf(12L), sum);
    }

    @Test
    public void addUpdatesSumAndAverage() {
        // Arrange
        AddMashine machine = new AddMashine(10L);

        // Act
        machine.add(4L);
        machine.add(2L);

        // Assert
        assertEquals(Long.valueOf(16L), machine.getSum());
        assertEquals(new BigDecimal("8"), machine.getAverage());
    }

    @Test
    public void subtractUpdatesSumAndCountsAsAnAddedNumber() {
        // Arrange
        AddMashine machine = new AddMashine(10L);

        // Act
        machine.sub(4L);
        machine.add(2L);

        // Assert
        assertEquals(Long.valueOf(8L), machine.getSum());
        assertEquals(new BigDecimal("4"), machine.getAverage());
    }

    @Test
    public void averageWithNoOperationsThrowsArithmeticException() {
        // Arrange
        AddMashine machine = new AddMashine(10L);

        // Act and Assert
        assertThrows(ArithmeticException.class, machine::getAverage);
    }
}
