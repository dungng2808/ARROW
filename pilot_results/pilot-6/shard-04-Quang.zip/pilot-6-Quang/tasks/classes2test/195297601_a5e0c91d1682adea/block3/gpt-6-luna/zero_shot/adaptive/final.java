package de.hegmanns.tdd.task04;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

public class AddMashine_ArrowTest {

    @Test
    public void addUpdatesSumAndAverage() {
        AddMashine machine = new AddMashine(10L);

        machine.add(4L);
        machine.add(6L);

        assertEquals(Long.valueOf(20L), machine.getSum());
        assertEquals(new BigDecimal("10"), machine.getAverage());
    }

    @Test
    public void subUpdatesSumAndCountsTowardAverage() {
        AddMashine machine = new AddMashine(12L);

        machine.sub(4L);
        machine.add(2L);

        assertEquals(Long.valueOf(10L), machine.getSum());
        assertEquals(new BigDecimal("5"), machine.getAverage());
    }

    @Test
    public void averageWithNoAddedNumbersThrowsArithmeticException() {
        AddMashine machine = new AddMashine(7L);

        assertThrows(ArithmeticException.class, machine::getAverage);
    }
}
