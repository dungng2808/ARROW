package de.hegmanns.tdd.task04;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

public class AddMashine_ArrowTest {

    @Test
    public void addUpdatesSumAndAverage() {
        AddMashine machine = new AddMashine(10L);

        machine.add(4L);
        machine.add(6L);

        assertEquals(Long.valueOf(20L), machine.getSum());
        assertEquals(new BigDecimal("10"), machine.getAverage());
    }

    @Test
    public void subtractUpdatesSumAndCountsTowardAverage() {
        AddMashine machine = new AddMashine(20L);

        machine.sub(4L);
        machine.add(2L);

        assertEquals(Long.valueOf(18L), machine.getSum());
        assertEquals(new BigDecimal("9"), machine.getAverage());
    }

    @Test
    public void averageCanBeNegative() {
        AddMashine machine = new AddMashine(0L);

        machine.sub(5L);
        machine.sub(1L);

        assertEquals(Long.valueOf(-6L), machine.getSum());
        assertEquals(new BigDecimal("-3"), machine.getAverage());
    }
}
