package de.bytefish.jtinycsvparser.typeconverter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.time.Instant;
import org.junit.Test;

public class InstantConverter_ArrowTest {

    @Test
    public void convertsIsoInstant() {
        InstantConverter converter = new InstantConverter();

        Instant result = converter.convert("2024-03-15T12:34:56.789Z");

        assertEquals(Instant.parse("2024-03-15T12:34:56.789Z"), result);
    }

    @Test
    public void reportsInstantAsTargetType() {
        InstantConverter converter = new InstantConverter();

        assertEquals(Instant.class, converter.getTargetType());
    }

    @Test
    public void formatsAsConverterName() {
        InstantConverter converter = new InstantConverter();

        assertEquals("InstantConverter{}", converter.toString());
    }

    @Test
    public void wrapsInvalidInputInRuntimeException() {
        InstantConverter converter = new InstantConverter();

        try {
            converter.convert("not-an-instant");
            fail("Expected invalid input to be wrapped in a RuntimeException");
        } catch (RuntimeException exception) {
            assertNotNull(exception.getCause());
        }
    }
}
