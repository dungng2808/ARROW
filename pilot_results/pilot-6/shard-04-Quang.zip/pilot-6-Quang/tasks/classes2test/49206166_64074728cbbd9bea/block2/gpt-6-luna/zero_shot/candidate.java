package de.bytefish.jtinycsvparser.typeconverter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThrows;

import java.time.Instant;

import org.junit.Test;

public class InstantConverter_ArrowTest {

    @Test
    public void convertParsesIso8601Instant() {
        InstantConverter converter = new InstantConverter();
        Instant expected = Instant.parse("2024-03-15T12:34:56.789Z");

        Instant actual = converter.convert("2024-03-15T12:34:56.789Z");

        assertEquals(expected, actual);
    }

    @Test
    public void convertWrapsInvalidInputInRuntimeException() {
        InstantConverter converter = new InstantConverter();

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> converter.convert("not-an-instant"));

        assertNotNull(exception.getCause());
        assertSame(java.time.format.DateTimeParseException.class, exception.getCause().getClass());
    }

    @Test
    public void getTargetTypeReturnsInstantClass() {
        InstantConverter converter = new InstantConverter();

        assertSame(Instant.class, converter.getTargetType());
    }

    @Test
    public void toStringReturnsConverterDescription() {
        InstantConverter converter = new InstantConverter();

        assertEquals("InstantConverter{}", converter.toString());
    }
}
