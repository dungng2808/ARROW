package de.bytefish.jtinycsvparser.typeconverter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.Instant;

import org.junit.Test;

public class InstantConverter_ArrowTest {

    @Test
    public void convertParsesIso8601Instant() {
        InstantConverter converter = new InstantConverter();
        Instant expected = Instant.parse("2024-03-15T12:34:56.123Z");

        Instant actual = converter.convert("2024-03-15T12:34:56.123Z");

        assertEquals(expected, actual);
    }

    @Test
    public void convertWrapsInvalidInputInRuntimeException() {
        InstantConverter converter = new InstantConverter();

        try {
            converter.convert("not-an-instant");
            fail("Expected invalid input to be rejected");
        } catch (RuntimeException exception) {
            assertNotNull(exception.getCause());
            assertTrue(exception.getCause() instanceof java.time.format.DateTimeParseException);
        }
    }

    @Test
    public void getTargetTypeReturnsInstantClass() {
        InstantConverter converter = new InstantConverter();

        assertSame(Instant.class, converter.getTargetType());
    }

    @Test
    public void toStringReturnsConverterDescription() {
        InstantConverter converter = new InstantConverter();

        assertEquals("InstantConverter{}", converter.toString());
    }
}
