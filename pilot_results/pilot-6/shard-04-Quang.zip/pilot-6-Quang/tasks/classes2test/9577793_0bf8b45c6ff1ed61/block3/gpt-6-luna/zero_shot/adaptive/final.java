package amforeas.client;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.apache.http.NameValuePair;
import org.junit.jupiter.api.Test;

public class RequestParams_ArrowTest {

    @Test
    public void builderCreatesResourcePathAndEmptyParameters() {
        RequestParams params = RequestParams.builder("widgets").build();

        assertEquals("widgets", params.getResource());
        assertEquals("/api/v1/widgets", params.getPath("/api", "v1"));
        assertEquals(0, params.getParameters().length);
        assertEquals("", params.getParametersAsQueryParams());
        assertNull(params.getPrimaryKey());
        assertNull(params.getPrimaryKeyValue());
    }

    @Test
    public void idDefaultsPrimaryKeyAndCreatesItemPath() {
        RequestParams params = RequestParams.builder("widgets").id("42").build();

        assertEquals("id", params.getPrimaryKey());
        assertEquals("42", params.getPrimaryKeyValue());
        assertEquals("/api/v1/widgets/42", params.getPath("/api", "v1"));
    }

    @Test
    public void columnValueCreatesColumnPath() {
        RequestParams params = RequestParams.builder("widgets")
            .column("status")
            .value("active")
            .build();

        assertEquals("status", params.getColumn());
        assertEquals("active", params.getColumnValue());
        assertEquals("/api/v1/widgets/status/active", params.getPath("/api", "v1"));
    }

    @Test
    public void dynamicQueryIncludesArgumentsInPathAndParameters() {
        RequestParams params = RequestParams.builder("widgets")
            .dynamicQuery("findByStatus")
            .addQueryParam("active")
            .addQueryParam("ready")
            .build();

        assertEquals("/api/v1/widgets/dynamic/findByStatus", params.getPath("/api", "v1"));
        assertEquals("findByStatus", params.getQuery());
        assertEquals(2, params.getQueryArgs().size());
        assertEquals("args", params.getQueryArgs().get(0).getName());
        assertEquals("active", params.getQueryArgs().get(0).getValue());
        assertArrayEquals(new String[] {"active", "ready"}, values(params.getParameters()));
        assertEquals("args=active&args=ready", params.getParametersAsQueryParams());
    }

    @Test
    public void paginationAndSortParametersAreOrdered() {
        RequestParams params = RequestParams.builder("widgets")
            .from(10)
            .to(25)
            .sortBy("created", "desc")
            .build();

        assertEquals(Integer.valueOf(10), params.getOffset());
        assertEquals(Integer.valueOf(25), params.getLimit());
        assertEquals("created", params.getSort());
        assertEquals("DESC", params.getDirection());
        assertArrayEquals(
            new String[] {"limit=25", "offset=10", "sort=created", "dir=DESC"},
            namesAndValues(params.getParameters()));
    }

    @Test
    public void pageParameterTakesPrecedenceOverSortParameters() {
        RequestParams params = RequestParams.builder("widgets")
            .page(3)
            .sortBy("name", "ASC")
            .build();

        assertEquals(Integer.valueOf(3), params.getPage());
        assertEquals("page=3&sort=name&dir=ASC", params.getParametersAsQueryParams());
    }

    @Test
    public void insertAndUpdateProduceExpectedPathsAndJson() throws Exception {
        RequestParams insert = RequestParams.builder("widgets")
            .insert("name", "sample")
            .insert("enabled", "true")
            .build();

        assertEquals("/api/v1/widgets", insert.getPath("/api", "v1"));
        assertEquals("{\"name\":\"sample\",\"enabled\":\"true\"}", insert.toJSON(insert.getInsert()));
        assertNotNull(insert.getFormBody());
        assertNotNull(insert.getJSONBody());

        RequestParams update = RequestParams.builder("widgets")
            .id("42")
            .update("name", "changed")
            .build();

        assertEquals("/api/v1/widgets/42", update.getPath("/api", "v1"));
        assertEquals("{\"name\":\"changed\"}", update.toJSON(update.getUpdate()));
        assertNotNull(update.getFormBody());
        assertNotNull(update.getJSONBody());
    }

    @Test
    public void formAndJsonBodyMethodsRejectMissingBody() throws Exception {
        RequestParams params = RequestParams.builder("widgets").build();

        IllegalStateException formException = assertThrows(
            IllegalStateException.class, params::getFormBody);
        assertEquals("No form body provided", formException.getMessage());

        IllegalStateException jsonException = assertThrows(
            IllegalStateException.class, params::getJSONBody);
        assertEquals("No form body provided", jsonException.getMessage());
    }

    @Test
    public void builderRejectsInvalidCombinationsAndInputs() {
        expectIllegalState(() -> RequestParams.builder("widgets").value("x"));
        expectIllegalArgument(() -> RequestParams.builder("widgets").dynamicQuery("search"));
        expectIllegalState(() -> RequestParams.builder("widgets").addQueryParam("x"));
        expectIllegalArgument(() -> RequestParams.builder("widgets").sortBy("name", "sideways"));
        expectIllegalState(() -> RequestParams.builder("widgets").to(10).build());
        expectIllegalState(() -> RequestParams.builder("widgets").from(0).build());
        expectIllegalState(() -> RequestParams.builder("widgets").page(1).from(0).page(2));
        expectIllegalState(() -> RequestParams.builder("widgets").column("name").value("x").id("1").build());
        expectIllegalState(() -> RequestParams.builder("widgets").update("name", "x").build());
    }

    @Test
    public void dynamicQueryAllowsAtMostTwoArguments() {
        RequestParams.Builder builder = RequestParams.builder("widgets")
            .dynamicQuery("findAllByStatus")
            .addQueryParam("active")
            .addQueryParam("ready");

        IndexOutOfBoundsException exception = assertThrows(
            IndexOutOfBoundsException.class, () -> builder.addQueryParam("pending"));
        assertEquals("Can't add more than two arguments to dynamic query", exception.getMessage());
    }

    @Test
    public void equalityAndHashCodeReflectConfiguredFields() {
        RequestParams first = RequestParams.builder("widgets").id("42").build();
        RequestParams same = RequestParams.builder("widgets").id("42").build();
        RequestParams different = RequestParams.builder("widgets").id("43").build();

        assertTrue(first.equals(same));
        assertEquals(first.hashCode(), same.hashCode());
        assertFalse(first.equals(different));
        assertNotEquals(first, null);
        assertFalse(first.equals("widgets"));
        assertTrue(first.toString().contains("primaryKeyValue=42"));
    }

    private static String[] values(NameValuePair[] pairs) {
        String[] result = new String[pairs.length];
        for (int i = 0; i < pairs.length; i++) {
            result[i] = pairs[i].getValue();
        }
        return result;
    }

    private static String[] namesAndValues(NameValuePair[] pairs) {
        String[] result = new String[pairs.length];
        for (int i = 0; i < pairs.length; i++) {
            result[i] = pairs[i].getName() + "=" + pairs[i].getValue();
        }
        return result;
    }

    private static void expectIllegalState(Runnable action) {
        assertThrows(IllegalStateException.class, action::run);
    }

    private static void expectIllegalArgument(Runnable action) {
        assertThrows(IllegalArgumentException.class, action::run);
    }
}
