package amforeas.client;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicNameValuePair;
import org.junit.jupiter.api.Test;

public class RequestParams_ArrowTest {

    @Test
    public void builderCreatesResourcePathAndDefaultParameters() {
        RequestParams params = RequestParams.builder("widgets").build();

        assertEquals("widgets", params.getResource());
        assertEquals("/api/v1/widgets", params.getPath("/api", "v1"));
        assertEquals(0, params.getParameters().length);
        assertEquals("", params.getParametersAsQueryParams());
    }

    @Test
    public void idAndColumnBuildersPopulatePathAndValues() {
        RequestParams byId = RequestParams.builder("widgets").id("42").build();

        assertEquals("id", byId.getPrimaryKey());
        assertEquals("42", byId.getPrimaryKeyValue());
        assertEquals("/api/v1/widgets/42", byId.getPath("/api", "v1"));

        RequestParams byColumn = RequestParams.builder("widgets")
            .column("status")
            .value("active")
            .build();

        assertEquals("status", byColumn.getColumn());
        assertEquals("active", byColumn.getColumnValue());
        assertEquals("/api/v1/widgets/status/active", byColumn.getPath("/api", "v1"));
    }

    @Test
    public void dynamicQueryIncludesArgumentsInParameters() {
        RequestParams params = RequestParams.builder("widgets")
            .dynamicQuery("findByStatus")
            .addQueryParam("active")
            .addQueryParam("archived")
            .build();

        assertEquals("/api/v1/widgets/dynamic/findByStatus", params.getPath("/api", "v1"));
        assertEquals("findByStatus", params.getQuery());
        assertEquals(2, params.getQueryArgs().size());
        assertEquals("args=active&args=archived", params.getParametersAsQueryParams());
    }

    @Test
    public void paginationAndSortParametersAreSerializedInOrder() {
        RequestParams params = RequestParams.builder("widgets")
            .from(10)
            .to(25)
            .sortBy("createdAt", "desc")
            .build();

        assertEquals(Integer.valueOf(25), params.getLimit());
        assertEquals(Integer.valueOf(10), params.getOffset());
        assertEquals("DESC", params.getDirection());
        assertEquals("limit=25&offset=10&sort=createdAt&dir=DESC", params.getParametersAsQueryParams());

        RequestParams pageParams = RequestParams.builder("widgets").page(3).build();
        assertEquals("page=3", pageParams.getParametersAsQueryParams());
    }

    @Test
    public void builderRejectsInvalidSequencesAndIncompatibleOptions() {
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").value("active"));
        assertThrows(IllegalArgumentException.class,
            () -> RequestParams.builder("widgets").dynamicQuery("searchWidgets"));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").addQueryParam("active"));
        assertThrows(IndexOutOfBoundsException.class,
            () -> RequestParams.builder("widgets")
                .dynamicQuery("findByStatus")
                .addQueryParam("active")
                .addQueryParam("archived")
                .addQueryParam("deleted"));
        assertThrows(IllegalArgumentException.class,
            () -> RequestParams.builder("widgets").sortBy("createdAt", "sideways"));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").to(10).build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").from(0).build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").to(10).page(1));
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").column("status").value("active").id("42").build());
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").update("status", "active").build());
    }

    @Test
    public void insertAndUpdateProvideFormAndJsonBodies() throws Exception {
        RequestParams insert = RequestParams.builder("widgets")
            .insert("name", "blue")
            .insert("enabled", "true")
            .build();

        assertEquals("/api/v1/widgets", insert.getPath("/api", "v1"));
        assertEquals("{\"name\":\"blue\",\"enabled\":\"true\"}", insert.toJSON(insert.getInsert()));
        assertEquals("name=blue&enabled=true", readEntity(insert.getFormBody()));
        assertEquals("{\"name\":\"blue\",\"enabled\":\"true\"}", readEntity(insert.getJSONBody()));

        RequestParams update = RequestParams.builder("widgets")
            .id("42")
            .update("name", "green")
            .build();

        assertEquals("/api/v1/widgets/42", update.getPath("/api", "v1"));
        assertEquals("name=green", readEntity(update.getFormBody()));
        assertEquals("{\"name\":\"green\"}", readEntity(update.getJSONBody()));
    }

    @Test
    public void missingBodyAndInvalidColumnValueAreRejected() {
        RequestParams params = RequestParams.builder("widgets").build();

        assertThrows(IllegalStateException.class, params::getFormBody);
        assertThrows(IllegalStateException.class, params::getJSONBody);
        assertThrows(IllegalStateException.class,
            () -> RequestParams.builder("widgets").column("").value("active"));
    }

    @Test
    public void equalityHashCodeAndStringRepresentationReflectRequestFields() {
        RequestParams first = RequestParams.builder("widgets").id("42").build();
        RequestParams same = RequestParams.builder("widgets").id("42").build();
        RequestParams different = RequestParams.builder("widgets").id("43").build();

        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertNotEquals(first, null);
        assertFalse(first.equals("widgets"));
        assertTrue(first.toString().contains("primaryKeyValue=42"));
        assertNotNull(first.toString());
    }

    @Test
    public void constructorPreservesSuppliedFieldsAndQueryArguments() {
        List<NameValuePair> args = Arrays.asList(new BasicNameValuePair("args", "x"));
        RequestParams params = new RequestParams(
            "widgets", "uuid", "u-1", "status", "active", "findByStatus",
            args, Collections.<NameValuePair>emptyList(), null,
            2, null, null, "createdAt", "ASC");

        assertEquals("widgets", params.getResource());
        assertEquals("uuid", params.getPrimaryKey());
        assertEquals("u-1", params.getPrimaryKeyValue());
        assertEquals("status", params.getColumn());
        assertEquals("active", params.getColumnValue());
        assertEquals("findByStatus", params.getQuery());
        assertEquals(args, params.getQueryArgs());
        assertEquals(Integer.valueOf(2), params.getPage());
        assertEquals("createdAt", params.getSort());
        assertEquals("ASC", params.getDirection());
        assertArrayEquals(new NameValuePair[] {
            new BasicNameValuePair("page", "2"),
            new BasicNameValuePair("sort", "createdAt"),
            new BasicNameValuePair("dir", "ASC"),
            new BasicNameValuePair("args", "x")
        }, params.getParameters());
    }

    private static String readEntity(UrlEncodedFormEntity entity) throws IOException {
        return new String(entity.getContent().readAllBytes(), "UTF-8");
    }

    private static String readEntity(StringEntity entity) throws IOException {
        return new String(entity.getContent().readAllBytes(), "UTF-8");
    }
}
