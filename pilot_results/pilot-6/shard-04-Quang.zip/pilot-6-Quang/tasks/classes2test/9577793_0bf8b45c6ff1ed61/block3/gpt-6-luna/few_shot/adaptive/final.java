package amforeas.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.message.BasicNameValuePair;
import org.junit.jupiter.api.Test;

public class RequestParams_ArrowTest {

    @Test
    public void defaultBuilderCreatesResourcePathAndEmptyParameters() {
        RequestParams params = RequestParams.builder("users").build();

        assertEquals("users", params.getResource());
        assertEquals("/api/v1/users", params.getPath("/api", "v1"));
        assertEquals(0, params.getParameters().length);
        assertEquals("", params.getParametersAsQueryParams());
    }

    @Test
    public void builderCreatesPrimaryKeyAndColumnPaths() {
        RequestParams byId = RequestParams.builder("users").id("42").build();
        RequestParams byColumn = RequestParams.builder("users")
                .column("email")
                .value("a@example.com")
                .build();

        assertEquals("id", byId.getPrimaryKey());
        assertEquals("42", byId.getPrimaryKeyValue());
        assertEquals("/api/v1/users/42", byId.getPath("/api", "v1"));
        assertEquals("email", byColumn.getColumn());
        assertEquals("a@example.com", byColumn.getColumnValue());
        assertEquals("/api/v1/users/email/a@example.com", byColumn.getPath("/api", "v1"));
    }

    @Test
    public void dynamicQueryArgumentsAndPaginationAreExposedAsParameters() {
        RequestParams params = RequestParams.builder("users")
                .dynamicQuery("findByName")
                .addQueryParam("Ada")
                .page(3)
                .sortBy("name", "desc")
                .build();

        assertEquals("/api/v1/users/dynamic/findByName", params.getPath("/api", "v1"));
        assertEquals(3, params.getPage());
        assertEquals("name", params.getSort());
        assertEquals("DESC", params.getDirection());
        assertEquals("page=3&sort=name&dir=DESC&args=Ada", params.getParametersAsQueryParams());
    }

    @Test
    public void offsetAndLimitAreReturnedInOrder() {
        RequestParams params = RequestParams.builder("users")
                .from(10)
                .to(5)
                .build();

        assertEquals(5, params.getLimit());
        assertEquals(10, params.getOffset());
        assertEquals("limit=5&offset=10", params.getParametersAsQueryParams());
    }

    @Test
    public void builderValidatesSupportedStateTransitions() {
        assertThrows(IllegalStateException.class,
                () -> RequestParams.builder("users").value("x"));
        assertThrows(IllegalArgumentException.class,
                () -> RequestParams.builder("users").dynamicQuery("search"));
        assertThrows(IllegalStateException.class,
                () -> RequestParams.builder("users").addQueryParam("x"));
        assertThrows(IndexOutOfBoundsException.class,
                () -> RequestParams.builder("users")
                        .dynamicQuery("findByName")
                        .addQueryParam("one")
                        .addQueryParam("two")
                        .addQueryParam("three"));
        assertThrows(IllegalArgumentException.class,
                () -> RequestParams.builder("users").sortBy("name", "sideways"));
        assertThrows(IllegalStateException.class,
                () -> RequestParams.builder("users").to(10).build());
        assertThrows(IllegalStateException.class,
                () -> RequestParams.builder("users").from(0).build());
        assertThrows(IllegalStateException.class,
                () -> RequestParams.builder("users").page(1).to(10).page(2));
    }

    @Test
    public void buildRejectsIncompatibleLookupAndUpdateConfigurations() {
        assertThrows(IllegalStateException.class,
                () -> RequestParams.builder("users")
                        .id("42")
                        .column("email")
                        .value("a@example.com")
                        .build());
        assertThrows(IllegalStateException.class,
                () -> RequestParams.builder("users")
                        .update("name", "Ada")
                        .build());
    }

    @Test
    public void insertAndUpdateProvideFormAndJsonBodies() throws Exception {
        RequestParams insert = RequestParams.builder("users")
                .insert("name", "Ada")
                .insert("role", "admin")
                .build();
        RequestParams update = RequestParams.builder("users")
                .id("42")
                .update("name", "Ada")
                .build();

        assertEquals("/api/v1/users", insert.getPath("/api", "v1"));
        assertEquals("/api/v1/users/42", update.getPath("/api", "v1"));
        assertEquals("{\"name\":\"Ada\",\"role\":\"admin\"}",
                readEntity(insert.getJSONBody().getContent()));
        assertEquals("{\"name\":\"Ada\"}",
                readEntity(update.getJSONBody().getContent()));

        UrlEncodedFormEntity form = insert.getFormBody();
        assertNotNull(form);
        assertEquals("name=Ada&role=admin", readEntity(form.getContent()));
    }

    @Test
    public void bodyAccessWithoutInsertOrUpdateFails() {
        RequestParams params = RequestParams.builder("users").build();

        assertThrows(IllegalStateException.class, params::getFormBody);
        assertThrows(IllegalStateException.class, params::getJSONBody);
    }

    @Test
    public void jsonSerializationAndValueEqualityAreConsistent() throws UnsupportedEncodingException {
        RequestParams first = RequestParams.builder("users").id("42").page(2).build();
        RequestParams same = RequestParams.builder("users").id("42").page(2).build();
        RequestParams different = RequestParams.builder("users").id("43").page(2).build();

        assertEquals("{\"name\":\"Ada\"}",
                first.toJSON(Collections.<NameValuePair>singletonList(
                        new BasicNameValuePair("name", "Ada"))));
        assertEquals(first, same);
        assertEquals(first.hashCode(), same.hashCode());
        assertNotEquals(first, different);
        assertFalse(first.equals(null));
        assertTrue(first.toString().contains("primaryKeyValue=42"));
    }

    private String readEntity(java.io.InputStream content) throws java.io.IOException {
        byte[] bytes = new byte[content.available()];
        int length = content.read(bytes);
        return new String(bytes, 0, length, StandardCharsets.UTF_8);
    }
}
