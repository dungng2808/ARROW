package com.ebayopensource.webrex.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

public class ELHelper_ArrowTest {

   @Test
   public void parsesDottedAndBracketedExpressionKeys() {
      List<String> expected = Arrays.asList("bean", "items", "first name", "value");
      assertEquals(expected, ELHelper.getELKeys("${bean.items['first name'].value}"));
   }

   @Test
   public void parsesDoubleQuotedBracketKeysAndTrimsDottedKeys() {
      List<String> expected = Arrays.asList("bean", "items", "first name", "value");
      assertEquals(expected, ELHelper.getELKeys(" bean . items[\"first name\"].value "));
   }

   @Test
   public void returnsEmptyKeysForEmptyExpression() {
      assertEquals(Collections.emptyList(), ELHelper.getELKeys(""));
   }

   @Test
   public void rejectsInvalidSeparatorsAndUnclosedBrackets() {
      assertNull(ELHelper.getELKeys("bean..value"));
      assertNull(ELHelper.getELKeys("bean[0]"));
      assertNull(ELHelper.getELKeys("bean['value'"));
   }

   @Test
   public void returnsNullForUnresolvableExpressions() {
      assertNull(ELHelper.getRealPathFromEL("${bean.unknown}"));
      assertNull(ELHelper.getExpressionFromEL("${bean.unknown}"));
   }
}
