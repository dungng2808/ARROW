package com.ebayopensource.webrex.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class ELHelper_ArrowTest {

   @Test
   public void parsesDottedExpressionAndTrimsKeys() {
      List<String> keys = ELHelper.getELKeys("${ bean . resource . path }");

      assertEquals(Arrays.asList("bean", "resource", "path"), keys);
   }

   @Test
   public void preservesWhitespaceInDoubleQuotedBracketKeys() {
      List<String> keys = ELHelper.getELKeys("${bean[' resource '].\"path\"}");

      assertEquals(Arrays.asList("bean", " resource ", "\"path\""), keys);
   }

   @Test
   public void parsesExpressionWithoutDelimiters() {
      List<String> keys = ELHelper.getELKeys("bean.resource");

      assertEquals(Arrays.asList("bean", "resource"), keys);
   }

   @Test
   public void returnsNullForInvalidOrUnclosedBracketSyntax() {
      assertNull(ELHelper.getELKeys("bean[0]"));
      assertNull(ELHelper.getELKeys("bean['resource]"));
   }

   @Test
   public void returnsNullForLeadingDot() {
      assertNull(ELHelper.getELKeys(".bean"));
   }

   @Test
   public void returnsNullForNullRealPathWhenExpressionIsUnresolvable() {
      assertNull(ELHelper.getRealPathFromEL("${unknown}"));
   }

   @Test
   public void returnsNullForUnresolvableExpression() {
      assertNull(ELHelper.getExpressionFromEL("${unknown}"));
   }
}
