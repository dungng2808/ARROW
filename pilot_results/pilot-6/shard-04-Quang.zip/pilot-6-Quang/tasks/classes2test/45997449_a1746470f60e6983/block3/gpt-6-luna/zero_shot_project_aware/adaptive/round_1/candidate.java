package com.ebayopensource.webrex.util;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class ELHelper_ArrowTest {

   @Test
   public void parsesDottedAndQuotedBracketKeys() {
      List<String> keys = ELHelper.getELKeys("${bean . child[' first '].\"second\"}");

      assertEquals(Arrays.asList("bean", "child", " first ", "\"second\""), keys);
   }

   @Test
   public void parsesUnwrappedExpressionAndTrimsKeys() {
      List<String> keys = ELHelper.getELKeys(" bean . child ");

      assertEquals(Arrays.asList("bean", "child"), keys);
   }

   @Test
   public void returnsNullForInvalidSeparatorsAndUnclosedBracket() {
      assertNull(ELHelper.getELKeys(".bean"));
      assertNull(ELHelper.getELKeys("bean..child"));
      assertNull(ELHelper.getELKeys("bean['child'"));
   }

   @Test
   public void returnsEmptyKeysForEmptyExpression() {
      assertEquals(0, ELHelper.getELKeys("").size());
   }

   @Test
   public void returnsNullForUnresolvableExpression() {
      assertNull(ELHelper.getRealPathFromEL("${bean}"));
      assertNull(ELHelper.getExpressionFromEL("${bean}"));
   }
}
