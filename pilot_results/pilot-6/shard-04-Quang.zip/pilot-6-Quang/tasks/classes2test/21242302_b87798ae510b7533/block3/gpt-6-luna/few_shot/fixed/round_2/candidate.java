package eu.optique.r2rml.api.model.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class TemplateImpl_ArrowTest {

    @Test
    public void parsesSegmentsAndColumnNames() {
        TemplateImpl template = new TemplateImpl("prefix/{id}/suffix/{name}");

        assertEquals(Arrays.asList("prefix/", "/suffix/"), template.getStringSegments());
        assertEquals(Arrays.asList("id", "name"), template.getColumnNames());
        assertEquals("prefix/{}{} /suffix/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("prefix/{id}/suffix/{name}", template.toString());
        assertEquals("/suffix/", template.getStringSegment(1));
        assertEquals("name", template.getColumnName(1));
    }

    @Test
    public void parsesTemplateWithoutColumns() {
        TemplateImpl template = new TemplateImpl("plain text");

        assertEquals(Arrays.asList("plain text"), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("plain text", template.getTemplateStringWithoutColumnNames());
        assertEquals("plain text", template.toString());
    }

    @Test
    public void escapedBracesRemainInStringSegments() {
        TemplateImpl template = new TemplateImpl("literal \\{brace\\}/{value}");

        assertEquals(Arrays.asList("literal \\{brace\\}/"), template.getStringSegments());
        assertEquals(Arrays.asList("value"), template.getColumnNames());
        assertEquals("literal \\{brace\\}/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("literal \\{brace\\}/{value}", template.toString());
    }

    @Test
    public void rejectsUnmatchedOrNestedBraces() {
        assertIllegalArgumentException("before/{value");
        assertIllegalArgumentException("before/value}");
        assertIllegalArgumentException("{outer{inner}}");
    }

    @Test
    public void segmentAndColumnUpdatesAreReflectedInStringAndEquality() {
        TemplateImpl template = new TemplateImpl("a/{x}/b");
        TemplateImpl same = new TemplateImpl("a/{x}/b");

        template.addStringSegment(1, "-");
        template.addColumnName(0, "y");

        assertEquals("a/{y}-", template.toString());
        assertFalse(template.equals(same));
        assertNotEquals(template.hashCode(), same.hashCode());
    }

    @Test
    public void columnNamesAreExposedAsAnUnmodifiableList() {
        TemplateImpl template = new TemplateImpl("{id}");
        List<String> columns = template.getColumnNames();

        try {
            columns.add("other");
            fail("Expected the column names list to be unmodifiable");
        } catch (UnsupportedOperationException expected) {
            // Expected.
        }
        assertEquals(Arrays.asList("id"), template.getColumnNames());
    }

    private void assertIllegalArgumentException(String template) {
        try {
            new TemplateImpl(template);
            fail("Expected an IllegalArgumentException for: " + template);
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }
}
