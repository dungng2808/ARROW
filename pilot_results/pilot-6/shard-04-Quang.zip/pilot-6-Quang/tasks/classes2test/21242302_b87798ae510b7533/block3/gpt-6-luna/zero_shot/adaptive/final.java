package eu.optique.r2rml.api.model.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class TemplateImpl_ArrowTest {

    @Test
    public void parsesSegmentsColumnsAndTemplateString() {
        TemplateImpl template = new TemplateImpl("http://example.com/{id}/item/{name}");

        assertEquals(Arrays.asList("http://example.com/", "/item/"), template.getStringSegments());
        assertEquals(Arrays.asList("id", "name"), template.getColumnNames());
        assertEquals("http://example.com/{}/item/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("http://example.com/{id}/item/{name}", template.toString());
    }

    @Test
    public void parsesEscapedBracesAsLiteralText() {
        TemplateImpl template = new TemplateImpl("prefix\\{literal\\}/{id}");

        assertEquals(Arrays.asList("prefix\\{literal\\}/"), template.getStringSegments());
        assertEquals(Arrays.asList("id"), template.getColumnNames());
        assertEquals("prefix\\{literal\\}/{}", template.getTemplateStringWithoutColumnNames());
    }

    @Test
    public void rejectsUnmatchedAndNestedUnescapedBraces() {
        assertIllegalArgumentException("{id");
        assertIllegalArgumentException("id}");
        assertIllegalArgumentException("{outer{inner}}");
    }

    @Test
    public void segmentAndColumnUpdatesReplaceExistingEntries() {
        TemplateImpl template = new TemplateImpl("a/{old}/b");

        template.addStringSegment(1, "/changed/");
        template.addColumnName(0, "new");

        assertEquals("/changed/", template.getStringSegment(1));
        assertEquals("new", template.getColumnName(0));
        assertEquals(Arrays.asList("a/", "/changed/"), template.getStringSegments());
        assertEquals(Arrays.asList("new"), template.getColumnNames());
    }

    @Test
    public void columnNamesAreUnmodifiable() {
        TemplateImpl template = new TemplateImpl("x/{id}");
        List<String> columns = template.getColumnNames();

        try {
            columns.add("other");
            fail("Expected the column names view to be unmodifiable");
        } catch (UnsupportedOperationException expected) {
            assertEquals(Arrays.asList("id"), columns);
        }
    }

    @Test
    public void equalityAndHashCodeReflectSegmentsAndColumns() {
        TemplateImpl first = new TemplateImpl("a/{id}/b");
        TemplateImpl same = new TemplateImpl("a/{id}/b");
        TemplateImpl different = new TemplateImpl("a/{name}/b");

        assertTrue(first.equals(same));
        assertEquals(first.hashCode(), same.hashCode());
        assertFalse(first.equals(different));
        assertNotEquals(first, null);
        assertFalse(first.equals("a/{id}/b"));
    }

    @Test
    public void emptyTemplateIsRejectedByCurrentParser() {
        try {
            new TemplateImpl("");
            fail("Expected the empty template to be rejected");
        } catch (ArrayIndexOutOfBoundsException expected) {
            assertTrue(expected.getMessage() == null || expected.getMessage().length() >= 0);
        }
    }

    private static void assertIllegalArgumentException(String template) {
        try {
            new TemplateImpl(template);
            fail("Expected an IllegalArgumentException for template: " + template);
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("curly braces"));
        }
    }
}
