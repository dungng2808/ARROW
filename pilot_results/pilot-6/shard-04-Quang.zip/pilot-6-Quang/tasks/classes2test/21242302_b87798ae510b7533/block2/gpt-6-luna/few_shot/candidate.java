package eu.optique.r2rml.api.model.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;

public class TemplateImpl_ArrowTest {

    @Test
    public void parsesSegmentsAndColumnNames() {
        TemplateImpl template = new TemplateImpl("prefix/{id}/suffix/{name}");

        assertEquals(Arrays.asList("prefix/", "/suffix/"), template.getStringSegments());
        assertEquals(Arrays.asList("id", "name"), template.getColumnNames());
        assertEquals("prefix/{}{}/suffix/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("prefix/{id}/suffix/{name}", template.toString());
        assertEquals("/suffix/", template.getStringSegment(1));
        assertEquals("name", template.getColumnName(1));
    }

    @Test
    public void parsesTemplateWithoutColumns() {
        TemplateImpl template = new TemplateImpl("plain text");

        assertEquals(Arrays.asList("plain text"), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("plain text", template.getTemplateStringWithoutColumnNames());
        assertEquals("plain text", template.toString());
    }

    @Test
    public void escapedBracesRemainInStringSegments() {
        TemplateImpl template = new TemplateImpl("literal \\{brace\\}/{value}");

        assertEquals(Arrays.asList("literal \\{brace\\}/", ""), template.getStringSegments());
        assertEquals(Arrays.asList("value"), template.getColumnNames());
        assertEquals("literal \\{brace\\}/{}{ }".replace("{ }", "{}"),
                template.getTemplateStringWithoutColumnNames());
        assertEquals("literal \\{brace\\}/{value}", template.toString());
    }

    @Test
    public void rejectsUnmatchedOrNestedBraces() {
        assertThrows(IllegalArgumentException.class, () -> new TemplateImpl("before/{value"));
        assertThrows(IllegalArgumentException.class, () -> new TemplateImpl("before/value}"));
        assertThrows(IllegalArgumentException.class, () -> new TemplateImpl("{outer{inner}}"));
    }

    @Test
    public void segmentAndColumnUpdatesAreReflectedInStringAndEquality() {
        TemplateImpl template = new TemplateImpl("a/{x}/b");
        TemplateImpl same = new TemplateImpl("a/{x}/b");

        template.addStringSegment(1, "-");
        template.addColumnName(0, "y");

        assertEquals("a-{y}/b", template.toString());
        assertFalse(template.equals(same));
        assertNotEquals(template.hashCode(), same.hashCode());
    }

    @Test
    public void columnNamesAreExposedAsAnUnmodifiableList() {
        TemplateImpl template = new TemplateImpl("{id}");
        List<String> columns = template.getColumnNames();

        assertThrows(UnsupportedOperationException.class, () -> columns.add("other"));
        assertEquals(Arrays.asList("id"), template.getColumnNames());
    }
}
