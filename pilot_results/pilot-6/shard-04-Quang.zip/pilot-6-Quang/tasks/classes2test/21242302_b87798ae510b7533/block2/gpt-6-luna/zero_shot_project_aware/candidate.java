package eu.optique.r2rml.api.model.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class TemplateImpl_ArrowTest {

    @Test
    public void parsesSegmentsColumnsAndTemplateWithoutColumnNames() {
        TemplateImpl template = new TemplateImpl("http://example.com/{id}/item/{name}");

        assertEquals(Arrays.asList("http://example.com/", "/item/"),
                template.getStringSegments());
        assertEquals(Arrays.asList("id", "name"), template.getColumnNames());
        assertEquals("http://example.com/{}/item/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("http://example.com/{id}/item/{name}", template.toString());
    }

    @Test
    public void parsesTemplateWithNoColumns() {
        TemplateImpl template = new TemplateImpl("plain text");

        assertEquals(Arrays.asList("plain text"), template.getStringSegments());
        assertTrue(template.getColumnNames().isEmpty());
        assertEquals("plain text", template.getTemplateStringWithoutColumnNames());
        assertEquals("plain text", template.toString());
    }

    @Test
    public void preservesEscapedBracesAsStringContent() {
        TemplateImpl template = new TemplateImpl("prefix\\{literal\\}/{id}");

        assertEquals(Arrays.asList("prefix\\{literal\\}/"), template.getStringSegments());
        assertEquals(Arrays.asList("id"), template.getColumnNames());
        assertEquals("prefix\\{literal\\}/{}", template.getTemplateStringWithoutColumnNames());
        assertEquals("prefix\\{literal\\}/{id}", template.toString());
    }

    @Test
    public void rejectsUnmatchedOrNestedUnescapedBraces() {
        assertInvalidTemplate("{id");
        assertInvalidTemplate("id}");
        assertInvalidTemplate("{id{other}");
    }

    @Test
    public void supportsReplacingExistingSegmentsAndColumnNames() {
        TemplateImpl template = new TemplateImpl("before/{id}/after");

        template.addStringSegment(0, "start/");
        template.addColumnName(0, "key");

        assertEquals("start/{key}/after", template.toString());
        assertEquals("start/", template.getStringSegment(0));
        assertEquals("key", template.getColumnName(0));
    }

    @Test
    public void exposesSegmentsAsMutableAndColumnNamesAsUnmodifiable() {
        TemplateImpl template = new TemplateImpl("a/{id}/b");

        List<String> segments = template.getStringSegments();
        segments.set(0, "changed/");
        assertEquals("changed/{id}/b", template.toString());

        try {
            template.getColumnNames().add("other");
            fail("Column names should be unmodifiable");
        } catch (UnsupportedOperationException expected) {
            // Expected.
        }
    }

    @Test
    public void equalityAndHashCodeReflectSegmentsAndColumns() {
        TemplateImpl first = new TemplateImpl("a/{id}/b");
        TemplateImpl equal = new TemplateImpl("a/{id}/b");
        TemplateImpl different = new TemplateImpl("a/{name}/b");

        assertTrue(first.equals(equal));
        assertEquals(first.hashCode(), equal.hashCode());
        assertFalse(first.equals(different));
        assertFalse(first.equals(null));
        assertNotEquals(first, "a/{id}/b");
    }

    private static void assertInvalidTemplate(String value) {
        try {
            new TemplateImpl(value);
            fail("Expected invalid template: " + value);
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }
}
