package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Collection;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.owlapi.ElkReasonerFactory;
import org.semanticweb.elk.reasoner.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class OwlInternalProof_ArrowTest {

	@Test
	public void goalIsReturnedAsConvertingInference() throws Exception {
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLOntology ontology = manager.createOntology();
		try {
			OWLDataFactory dataFactory = manager.getOWLDataFactory();
			OWLAxiom goal = dataFactory.getOWLSubClassOfAxiom(
					dataFactory.getOWLClass(
							org.semanticweb.owlapi.model.IRI.create("urn:test#A")),
					dataFactory.getOWLClass(
							org.semanticweb.owlapi.model.IRI.create("urn:test#B")));

			Reasoner reasoner = new ElkReasonerFactory()
					.createReasoner(ontology).getInternalReasoner();
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			assertSame(goal, proof.getGoal());
			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(goal);
			assertNotNull(inferences);
			assertEquals(1, inferences.size());

			Inference<Object> inference = inferences.iterator().next();
			assertEquals("Converting inference", inference.getName());
			assertEquals(goal, inference.getConclusion());
			assertEquals(1, inference.getPremises().size());
			assertNotNull(inference.getPremises().get(0));
		} finally {
			manager.removeOntology(ontology);
		}
	}

	@Test
	public void nonGoalConclusionIsDelegatedToInternalProof()
			throws Exception {
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLOntology ontology = manager.createOntology();
		try {
			OWLDataFactory dataFactory = manager.getOWLDataFactory();
			OWLAxiom goal = dataFactory.getOWLSubClassOfAxiom(
					dataFactory.getOWLClass(
							org.semanticweb.owlapi.model.IRI.create("urn:test#A")),
					dataFactory.getOWLClass(
							org.semanticweb.owlapi.model.IRI.create("urn:test#B")));
			OWLAxiom other = dataFactory.getOWLSubClassOfAxiom(
					dataFactory.getOWLClass(
							org.semanticweb.owlapi.model.IRI.create("urn:test#C")),
					dataFactory.getOWLClass(
							org.semanticweb.owlapi.model.IRI.create("urn:test#D")));

			Reasoner reasoner = new ElkReasonerFactory()
					.createReasoner(ontology).getInternalReasoner();
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(other);
			assertNotNull(inferences);
			assertTrue(inferences.isEmpty());
		} finally {
			manager.removeOntology(ontology);
		}
	}
}
