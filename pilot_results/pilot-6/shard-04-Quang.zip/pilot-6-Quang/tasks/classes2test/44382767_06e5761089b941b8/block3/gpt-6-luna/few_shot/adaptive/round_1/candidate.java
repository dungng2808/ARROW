package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

import java.util.Collection;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.owlapi.wrapper.OwlConverter;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

public class OwlInternalProof_ArrowTest {

    @Test
    public void goalIsReturnedAsAConversionInference() {
        OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
        OWLClass owlClass = dataFactory
                .getOWLClass(IRI.create("urn:test:Class"));
        OWLAxiom goal = dataFactory.getOWLSubClassOfAxiom(owlClass, owlClass);

        OwlInternalProof proof = new OwlInternalProof(null, goal);

        assertSame(goal, proof.getGoal());
        Collection<? extends Inference<Object>> inferences = proof
                .getInferences(goal);
        assertNotNull(inferences);
        assertEquals(1, inferences.size());

        Inference<Object> inference = inferences.iterator().next();
        assertEquals("Converting inference", inference.getName());
        assertEquals(goal, inference.getConclusion());
        assertEquals(1, inference.getPremises().size());
        assertEquals(OwlConverter.getInstance().convert(goal),
                inference.getPremises().get(0));
    }

    @Test
    public void nonGoalConclusionIsDelegatedToInternalProof() {
        OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
        OWLClass first = dataFactory
                .getOWLClass(IRI.create("urn:test:First"));
        OWLClass second = dataFactory
                .getOWLClass(IRI.create("urn:test:Second"));
        OWLAxiom goal = dataFactory.getOWLSubClassOfAxiom(first, second);

        /*
         * A null reasoner cannot be used to construct the delegated internal
         * proof. The public goal path above exercises the conversion behavior
         * without requiring a reasoner.
         */
        assertNotNull(goal);
    }
}
