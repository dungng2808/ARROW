package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Collection;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.owlapi.ElkReasoner;
import org.semanticweb.elk.owlapi.ElkReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class OwlInternalProof_ArrowTest {

    @Test
    public void goalIsReturnedAsAConversionInference() throws Exception {
        OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
        OWLClass owlClass = dataFactory
                .getOWLClass(IRI.create("urn:test:Class"));
        OWLAxiom goal = dataFactory.getOWLSubClassOfAxiom(owlClass, owlClass);
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        OWLOntology ontology = manager.createOntology();
        ElkReasoner reasoner = (ElkReasoner) new ElkReasonerFactory()
                .createReasoner(ontology);

        try {
            OwlInternalProof proof = new OwlInternalProof(
                    reasoner.getInternalReasoner(), goal);

            assertSame(goal, proof.getGoal());
            Collection<? extends Inference<Object>> inferences = proof
                    .getInferences(goal);
            assertNotNull(inferences);
            assertEquals(1, inferences.size());

            Inference<Object> inference = inferences.iterator().next();
            assertEquals("Converting inference", inference.getName());
            assertEquals(goal, inference.getConclusion());
            assertEquals(1, inference.getPremises().size());
            assertNotNull(inference.getPremises().get(0));
        } finally {
            reasoner.dispose();
            manager.removeOntology(ontology);
        }
    }

    @Test
    public void nonGoalConclusionIsDelegatedToInternalProof()
            throws Exception {
        OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
        OWLClass first = dataFactory.getOWLClass(IRI.create("urn:test:First"));
        OWLClass second = dataFactory
                .getOWLClass(IRI.create("urn:test:Second"));
        OWLAxiom goal = dataFactory.getOWLSubClassOfAxiom(first, second);
        OWLAxiom otherConclusion = dataFactory.getOWLSubClassOfAxiom(second,
                first);
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        OWLOntology ontology = manager.createOntology();
        ElkReasoner reasoner = (ElkReasoner) new ElkReasonerFactory()
                .createReasoner(ontology);

        try {
            OwlInternalProof proof = new OwlInternalProof(
                    reasoner.getInternalReasoner(), goal);

            Collection<? extends Inference<Object>> inferences = proof
                    .getInferences(otherConclusion);
            assertNotNull(inferences);
            assertTrue(inferences.isEmpty());
        } finally {
            reasoner.dispose();
            manager.removeOntology(ontology);
        }
    }
}
