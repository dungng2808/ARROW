package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import org.junit.Test;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;

public class OwlInternalProof_ArrowTest {

    @Test
    public void constructionWithoutAReasonerFails() {
        OWLDataFactory dataFactory = OWLManager.getOWLDataFactory();
        OWLClass subject = dataFactory
                .getOWLClass(IRI.create("urn:test:Subject"));
        OWLClass object = dataFactory
                .getOWLClass(IRI.create("urn:test:Object"));
        OWLAxiom goal = dataFactory.getOWLSubClassOfAxiom(subject, object);
        assertNotNull(goal);

        try {
            new OwlInternalProof(null, goal);
            fail("A reasoner is required to construct an internal proof");
        } catch (NullPointerException expected) {
            // The internal proof cannot be initialized without a reasoner.
        }
    }
}
