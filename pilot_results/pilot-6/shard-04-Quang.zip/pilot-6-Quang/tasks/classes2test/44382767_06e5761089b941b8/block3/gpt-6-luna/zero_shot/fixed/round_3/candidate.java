package org.semanticweb.elk.owlapi.proofs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Collection;

import org.junit.Test;
import org.liveontologies.puli.Inference;
import org.semanticweb.elk.reasoner.Reasoner;
import org.semanticweb.elk.reasoner.ReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class OwlInternalProof_ArrowTest {

	@Test
	public void goalIsReturnedAsAConvertingInference() throws Exception {
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLOntology ontology = manager.createOntology();
		OWLClass cls = manager.getOWLDataFactory()
				.getOWLClass(IRI.create("urn:test:Goal"));
		OWLAxiom goal = manager.getOWLDataFactory()
				.getOWLSubClassOfAxiom(cls, cls);
		Reasoner reasoner = new ReasonerFactory().createReasoner(ontology);

		try {
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			assertSame(goal, proof.getGoal());
			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(goal);
			assertNotNull(inferences);
			assertEquals(1, inferences.size());

			Inference<Object> inference = inferences.iterator().next();
			assertEquals("Converting inference", inference.getName());
			assertEquals(goal, inference.getConclusion());
			assertEquals(1, inference.getPremises().size());
			assertNotNull(inference.getPremises().get(0));
		} finally {
			reasoner.shutdown();
		}
	}

	@Test
	public void nonGoalConclusionUsesTheInternalProof() throws Exception {
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLOntology ontology = manager.createOntology();
		OWLClass goalClass = manager.getOWLDataFactory()
				.getOWLClass(IRI.create("urn:test:Goal"));
		OWLClass otherClass = manager.getOWLDataFactory()
				.getOWLClass(IRI.create("urn:test:Other"));
		OWLAxiom goal = manager.getOWLDataFactory()
				.getOWLSubClassOfAxiom(goalClass, goalClass);
		OWLAxiom other = manager.getOWLDataFactory()
				.getOWLSubClassOfAxiom(otherClass, otherClass);
		Reasoner reasoner = new ReasonerFactory().createReasoner(ontology);

		try {
			OwlInternalProof proof = new OwlInternalProof(reasoner, goal);

			Collection<? extends Inference<Object>> inferences = proof
					.getInferences(other);
			assertNotNull(inferences);
			assertTrue(inferences.isEmpty());
			assertTrue(!proof.getInferences(goal).isEmpty());
		} finally {
			reasoner.shutdown();
		}
	}
}
