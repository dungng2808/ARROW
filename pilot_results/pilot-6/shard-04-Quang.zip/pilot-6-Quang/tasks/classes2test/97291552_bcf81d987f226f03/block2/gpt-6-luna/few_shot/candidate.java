package org.asn1s.api;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Template_ArrowTest {

    @Test
    public void defaultConstructorCreatesNonInstanceWithNoParameters() {
        Template template = new Template();

        assertFalse(template.isInstance());
        assertEquals(0, template.getParameterCount());
    }

    @Test
    public void constructorPreservesInstanceFlag() {
        Template instanceTemplate = new Template(true);
        Template definitionTemplate = new Template(false);

        assertTrue(instanceTemplate.isInstance());
        assertFalse(definitionTemplate.isInstance());
    }

    @Test
    public void addParameterSupportsLookupByNameAndIndex() {
        Template template = new Template();
        TemplateParameter parameter = new TemplateParameter("value", 3);

        template.addParameter(parameter);

        assertSame(parameter, template.getParameter("value"));
        assertSame(parameter, template.getParameter(3));
        assertEquals(1, template.getParameterCount());
    }

    @Test
    public void addingParameterWithExistingNameReplacesIt() {
        Template template = new Template();
        TemplateParameter original = new TemplateParameter("value", 1);
        TemplateParameter replacement = new TemplateParameter("value", 2);

        template.addParameter(original);
        template.addParameter(replacement);

        assertSame(replacement, template.getParameter("value"));
        assertSame(replacement, template.getParameter(2));
        assertEquals(1, template.getParameterCount());
        assertThrows(IllegalArgumentException.class, () -> template.getParameter(1));
    }

    @Test
    public void missingNameReturnsNullAndMissingIndexThrows() {
        Template template = new Template();

        assertNull(template.getParameter("missing"));
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> template.getParameter(7));
        assertEquals("No parameter with index: 7", exception.getMessage());
    }

    @Test
    public void distinctNamesCanShareAnIndexAndIndexLookupFindsAStoredParameter() {
        Template template = new Template();
        TemplateParameter first = new TemplateParameter("first", 4);
        TemplateParameter second = new TemplateParameter("second", 4);

        template.addParameter(first);
        template.addParameter(second);

        assertEquals(2, template.getParameterCount());
        TemplateParameter found = template.getParameter(4);
        assertTrue(found == first || found == second);
        assertNotSame(null, found);
    }
}
