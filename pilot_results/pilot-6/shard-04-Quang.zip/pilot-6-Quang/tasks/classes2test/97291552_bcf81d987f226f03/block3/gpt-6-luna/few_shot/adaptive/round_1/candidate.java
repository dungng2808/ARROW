package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class Template_ArrowTest {

    @Test
    public void defaultConstructorCreatesNonInstanceWithNoParameters() {
        Template template = new Template();

        assertFalse(template.isInstance());
        assertEquals(0, template.getParameterCount());
    }

    @Test
    public void constructorPreservesInstanceFlag() {
        Template instanceTemplate = new Template(true);
        Template definitionTemplate = new Template(false);

        assertTrue(instanceTemplate.isInstance());
        assertFalse(definitionTemplate.isInstance());
    }

    @Test
    public void addParameterSupportsLookupByNameAndIndex() {
        Template template = new Template();
        TemplateParameter parameter = new TemplateParameter("value", 3);

        template.addParameter(parameter);

        assertSame(parameter, template.getParameter("value"));
        assertSame(parameter, template.getParameter(3));
        assertEquals(1, template.getParameterCount());
    }

    @Test
    public void addingParameterWithExistingNameReplacesIt() {
        Template template = new Template();
        TemplateParameter original = new TemplateParameter("value", 1);
        TemplateParameter replacement = new TemplateParameter("value", 2);

        template.addParameter(original);
        template.addParameter(replacement);

        assertSame(replacement, template.getParameter("value"));
        assertSame(replacement, template.getParameter(2));
        assertEquals(1, template.getParameterCount());

        try {
            template.getParameter(1);
            fail("Expected lookup of the replaced parameter index to fail");
        } catch (IllegalArgumentException expected) {
            assertEquals("No parameter with index: 1", expected.getMessage());
        }
    }

    @Test
    public void missingNameReturnsNullAndMissingIndexThrows() {
        Template template = new Template();

        assertNull(template.getParameter("missing"));

        try {
            template.getParameter(7);
            fail("Expected lookup of a missing index to fail");
        } catch (IllegalArgumentException expected) {
            assertEquals("No parameter with index: 7", expected.getMessage());
        }
    }

    @Test
    public void distinctNamesCanShareAnIndexAndIndexLookupFindsAStoredParameter() {
        Template template = new Template();
        TemplateParameter first = new TemplateParameter("first", 4);
        TemplateParameter second = new TemplateParameter("second", 4);

        template.addParameter(first);
        template.addParameter(second);

        assertEquals(2, template.getParameterCount());
        TemplateParameter found = template.getParameter(4);
        assertNotNull(found);
        assertTrue(found == first || found == second);
    }
}
