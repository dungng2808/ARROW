package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.*;

public class Template_ArrowTest
{
	@Test
	public void defaultConstructorCreatesNonInstanceWithNoParameters()
	{
		Template template = new Template();

		assertFalse(template.isInstance());
		assertEquals(0, template.getParameterCount());
		assertNull(template.getParameter("missing"));
	}

	@Test
	public void booleanConstructorPreservesInstanceFlag()
	{
		assertTrue(new Template(true).isInstance());
		assertFalse(new Template(false).isInstance());
	}

	@Test
	public void missingIndexThrowsIllegalArgumentException()
	{
		Template template = new Template();

		try
		{
			template.getParameter(7);
			fail("Expected an exception for an unknown parameter index");
		}
		catch( IllegalArgumentException exception )
		{
			assertEquals("No parameter with index: 7", exception.getMessage());
		}
	}
}
