package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class Template_ArrowTest {

    @Test
    public void defaultConstructorCreatesNonInstanceWithNoParameters() {
        Template template = new Template();

        assertFalse(template.isInstance());
        assertEquals(0, template.getParameterCount());
    }

    @Test
    public void constructorPreservesInstanceFlag() {
        Template instanceTemplate = new Template(true);
        Template definitionTemplate = new Template(false);

        assertTrue(instanceTemplate.isInstance());
        assertFalse(definitionTemplate.isInstance());
    }

    @Test
    public void missingNameReturnsNullAndMissingIndexThrows() {
        Template template = new Template();

        assertNull(template.getParameter("missing"));
        try {
            template.getParameter(Integer.MIN_VALUE);
            fail("Expected an exception for a missing parameter index");
        } catch (IllegalArgumentException expected) {
            assertEquals("No parameter with index: " + Integer.MIN_VALUE, expected.getMessage());
        }
    }

    @Test
    public void addingParameterWithExistingNameReplacesIt() {
        Template template = new Template();
        TemplateParameter original = new TemplateParameter();
        TemplateParameter replacement = new TemplateParameter();
        original.setName("value");
        replacement.setName("value");

        template.addParameter(original);
        template.addParameter(replacement);

        assertSame(replacement, template.getParameter("value"));
        assertEquals(1, template.getParameterCount());
    }

    @Test
    public void addParameterSupportsLookupByNameAndIndex() {
        Template template = new Template();
        TemplateParameter parameter = new TemplateParameter();
        parameter.setName("value");

        template.addParameter(parameter);

        assertSame(parameter, template.getParameter("value"));
        assertSame(parameter, template.getParameter(parameter.getIndex()));
        assertEquals(1, template.getParameterCount());
    }
}
