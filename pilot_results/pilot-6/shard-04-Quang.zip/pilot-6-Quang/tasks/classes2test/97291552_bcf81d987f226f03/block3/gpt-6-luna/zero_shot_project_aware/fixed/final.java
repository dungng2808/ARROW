package org.asn1s.api;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class Template_ArrowTest
{
	@Test
	public void defaultConstructorCreatesNonInstanceWithNoParameters()
	{
		Template template = new Template();

		assertFalse( template.isInstance() );
		assertEquals( 0, template.getParameterCount() );
	}

	@Test
	public void booleanConstructorPreservesInstanceFlag()
	{
		assertTrue( new Template( true ).isInstance() );
		assertFalse( new Template( false ).isInstance() );
	}

	@Test
	public void missingNameReturnsNullAndMissingIndexThrows()
	{
		Template template = new Template();

		assertNull( template.getParameter( "missing" ) );
		try
		{
			template.getParameter( 7 );
			fail( "Expected an exception for an unknown parameter index" );
		}
		catch( IllegalArgumentException expected )
		{
			assertEquals( "No parameter with index: 7", expected.getMessage() );
		}
	}
}
