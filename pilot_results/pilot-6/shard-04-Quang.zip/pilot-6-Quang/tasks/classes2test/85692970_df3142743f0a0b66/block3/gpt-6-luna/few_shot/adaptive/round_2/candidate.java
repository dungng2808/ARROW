package com.github.thorbenkuck.netcom2.network.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThrows;

import java.util.UUID;
import org.junit.Test;

public class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    public void produceCreatesHandlerForProvidedClassAndUuid() {
        Sender sender = null;
        RemoteAccessBlockRegistration registration = null;
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(uuid, Runnable.class);

        assertNotNull(handler);
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);
        UUID uuid = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> producer.produce(uuid, null));

        assertSame("Null is not a valid parameter!", exception.getMessage());
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> producer.produce(null, Runnable.class));

        assertSame("Null is not a valid parameter!", exception.getMessage());
    }
}
