package com.github.thorbenkuck.netcom2.network.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;

import java.util.UUID;
import org.junit.Test;

public class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    public void produceCreatesHandlerForProvidedClassAndUuid() {
        Sender sender = mock(Sender.class);
        RemoteAccessBlockRegistration registration = mock(RemoteAccessBlockRegistration.class);
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(uuid, Runnable.class);

        assertNotNull(handler);
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(mock(Sender.class),
                        mock(RemoteAccessBlockRegistration.class));

        try {
            producer.produce(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"), null);
            fail("Expected IllegalArgumentException for a null class");
        } catch (IllegalArgumentException expected) {
            assertTrue("Null is not a valid parameter!".equals(expected.getMessage()));
        }
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(mock(Sender.class),
                        mock(RemoteAccessBlockRegistration.class));

        try {
            producer.produce(null, Runnable.class);
            fail("Expected IllegalArgumentException for a null UUID");
        } catch (IllegalArgumentException expected) {
            assertTrue("Null is not a valid parameter!".equals(expected.getMessage()));
        }
    }
}
