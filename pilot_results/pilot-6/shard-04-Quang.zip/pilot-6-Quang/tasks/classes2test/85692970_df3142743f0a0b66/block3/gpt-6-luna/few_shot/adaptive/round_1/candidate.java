package com.github.thorbenkuck.netcom2.network.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.UUID;
import org.junit.Test;

public class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    public void produceCreatesHandlerForProvidedClassAndUuid() {
        Sender sender = null;
        RemoteAccessBlockRegistration registration = null;
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");

        JavaRemoteInformationInvocationHandler<Runnable> handler =
                producer.produce(uuid, Runnable.class);

        assertNotNull(handler);
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        try {
            producer.produce(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"), null);
            fail("Expected NullPointerException for a null class");
        } catch (NullPointerException expected) {
            // Expected.
        }
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        try {
            producer.produce(null, Runnable.class);
            fail("Expected NullPointerException for a null UUID");
        } catch (NullPointerException expected) {
            // Expected.
        }
    }
}
