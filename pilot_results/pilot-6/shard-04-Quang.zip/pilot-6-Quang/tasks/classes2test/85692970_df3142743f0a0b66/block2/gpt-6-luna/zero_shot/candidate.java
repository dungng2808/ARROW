package com.github.thorbenkuck.netcom2.network.client;

import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

public class JavaInvocationHandlerProducer_ArrowTest {

    @Test
    public void produceReturnsHandlerForProvidedClassAndUuid() {
        Sender sender = null;
        RemoteAccessBlockRegistration registration = null;
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(sender, registration);
        UUID uuid = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");

        JavaRemoteInformationInvocationHandler<String> handler =
                producer.produce(uuid, String.class);

        assertNotNull(handler);
    }

    @Test
    public void produceRejectsNullClass() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        try {
            producer.produce(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"), null);
            fail("Expected a null-parameter exception");
        } catch (RuntimeException expected) {
            assertNotNull(expected);
        }
    }

    @Test
    public void produceRejectsNullUuid() {
        JavaInvocationHandlerProducer producer =
                new JavaInvocationHandlerProducer(null, null);

        try {
            producer.produce(null, String.class);
            fail("Expected a null-parameter exception");
        } catch (RuntimeException expected) {
            assertNotNull(expected);
        }
    }
}
