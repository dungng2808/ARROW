package com.jitterted.mobreg.domain;

import org.junit.jupiter.api.Test;

import java.net.URI;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class Ensemble_ArrowTest {

    private static final ZonedDateTime START =
            ZonedDateTime.of(2030, 5, 10, 18, 0, 0, 0, ZoneOffset.UTC);

    @Test
    public void newEnsembleHasScheduledStateAndDefaultMeetingAndRecordingLinks() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);

        assertEquals("Friday Ensemble", ensemble.name());
        assertEquals(START, ensemble.startDateTime());
        assertEquals(EnsembleState.SCHEDULED, ensemble.state());
        assertEquals(URI.create("https://zoom.us"), ensemble.meetingLink());
        assertEquals(URI.create(""), ensemble.recordingLink());
        assertEquals(0, ensemble.acceptedCount());
        assertTrue(ensemble.canAccept());
    }

    @Test
    public void acceptingAndDecliningMembersUpdatesRsvpAndMembership() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId member = new MemberId("member-1");

        ensemble.acceptedBy(member);
        assertTrue(ensemble.isAccepted(member));
        assertEquals(Rsvp.ACCEPTED, ensemble.rsvpOf(member));
        assertEquals(1, ensemble.acceptedCount());

        ensemble.declinedBy(member);
        assertFalse(ensemble.isAccepted(member));
        assertTrue(ensemble.isDeclined(member));
        assertEquals(Rsvp.DECLINED, ensemble.rsvpOf(member));
        assertEquals(1, ensemble.declinedCount());

        ensemble.acceptedBy(member);
        assertTrue(ensemble.isAccepted(member));
        assertFalse(ensemble.isDeclined(member));
        assertEquals(Rsvp.ACCEPTED, ensemble.rsvpOf(member));
        assertEquals(0, ensemble.declinedCount());
    }

    @Test
    public void acceptingFifthMemberFillsEnsembleAndFurtherAcceptanceFails() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        List<MemberId> members = List.of(
                new MemberId("member-1"),
                new MemberId("member-2"),
                new MemberId("member-3"),
                new MemberId("member-4"),
                new MemberId("member-5"));

        members.forEach(ensemble::acceptedBy);

        assertEquals(5, ensemble.acceptedCount());
        assertFalse(ensemble.canAccept());
        assertThrows(EnsembleFullException.class,
                () -> ensemble.acceptedBy(new MemberId("member-6")));
        assertEquals(5, ensemble.acceptedCount());
    }

    @Test
    public void joiningAsSpectatorRemovesMemberFromAcceptedAndDeclinedLists() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId accepted = new MemberId("accepted");
        MemberId declined = new MemberId("declined");

        ensemble.acceptedBy(accepted);
        ensemble.declinedBy(declined);
        ensemble.joinAsSpectator(accepted);
        ensemble.joinAsSpectator(declined);

        assertTrue(ensemble.spectators().containsAll(List.of(accepted, declined)));
        assertFalse(ensemble.isAccepted(accepted));
        assertFalse(ensemble.isDeclined(declined));
        assertEquals(Rsvp.UNKNOWN, ensemble.rsvpOf(accepted));
        assertEquals(Rsvp.UNKNOWN, ensemble.rsvpOf(declined));
    }

    @Test
    public void completedEnsembleRejectsAcceptanceAndCannotBeCanceled() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        ensemble.complete();

        assertTrue(ensemble.isCompleted());
        assertEquals(EnsembleState.COMPLETED, ensemble.state());
        assertThrows(EnsembleCompleted.class,
                () -> ensemble.acceptedBy(new MemberId("member-1")));
        assertThrows(EnsembleCompleted.class, ensemble::cancel);
        assertTrue(ensemble.isCompleted());
    }

    @Test
    public void canceledEnsembleRejectsAcceptanceAndCanBeCanceledOnlyOnce() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId member = new MemberId("member-1");
        ensemble.acceptedBy(member);
        ensemble.cancel();

        assertTrue(ensemble.isCanceled());
        assertEquals(EnsembleState.CANCELED, ensemble.state());
        assertThrows(EnsembleCanceled.class,
                () -> ensemble.acceptedBy(new MemberId("member-2")));
        assertEquals(MemberStatus.CANCELED, ensemble.statusFor(member, START.minusDays(1)));
        assertEquals(MemberStatus.HIDDEN,
                ensemble.statusFor(new MemberId("unknown"), START.minusDays(1)));
    }

    @Test
    public void changingNameAndStartTimeRejectsNullValues() {
        Ensemble ensemble = new Ensemble("Original", START);
        ZonedDateTime newStart = START.plusDays(1);

        ensemble.changeNameTo("Updated");
        ensemble.changeStartDateTimeTo(newStart);

        assertEquals("Updated", ensemble.name());
        assertEquals(newStart, ensemble.startDateTime());
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeNameTo(null));
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeStartDateTimeTo(null));
        assertEquals("Updated", ensemble.name());
        assertEquals(newStart, ensemble.startDateTime());
    }

    @Test
    public void meetingAndConferenceDetailsCanBeChangedAndRemoved() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", URI.create("https://old.example"), START);
        URI newMeetingLink = URI.create("https://new.example");
        ConferenceDetails details =
                new ConferenceDetails("Conference", URI.create("https://conference.example"), newMeetingLink);

        ensemble.changeMeetingLinkTo(newMeetingLink);
        assertEquals(newMeetingLink, ensemble.meetingLink());

        ensemble.changeConferenceDetailsTo(details);
        assertSame(details, ensemble.conferenceDetails());
        assertEquals(newMeetingLink, ensemble.meetingLink());

        ensemble.removeConferenceDetails();
        assertSame(ConferenceDetails.DELETED, ensemble.conferenceDetails());
    }

    @Test
    public void recordingLinkCanBeUpdated() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        URI recording = URI.create("https://recording.example/video");

        ensemble.linkToRecordingAt(recording);

        assertEquals(recording, ensemble.recordingLink());
    }

    @Test
    public void statusReflectsRsvpAndGracePeriod() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId accepted = new MemberId("accepted");
        MemberId declined = new MemberId("declined");
        ensemble.acceptedBy(accepted);
        ensemble.declinedBy(declined);

        assertEquals(MemberStatus.ACCEPTED, ensemble.statusFor(accepted, START.minusMinutes(1)));
        assertEquals(MemberStatus.DECLINED, ensemble.statusFor(declined, START.minusMinutes(1)));
        assertEquals(MemberStatus.UNKNOWN,
                ensemble.statusFor(new MemberId("unknown"), START.minusMinutes(1)));

        assertEquals(MemberStatus.IN_GRACE_PERIOD,
                ensemble.statusFor(accepted, START.plusMinutes(5)));
        assertEquals(MemberStatus.HIDDEN,
                ensemble.statusFor(new MemberId("unknown"), START.plusMinutes(5)));
        assertEquals(MemberStatus.HIDDEN,
                ensemble.statusFor(accepted, START.plusMinutes(11)));
    }
}
