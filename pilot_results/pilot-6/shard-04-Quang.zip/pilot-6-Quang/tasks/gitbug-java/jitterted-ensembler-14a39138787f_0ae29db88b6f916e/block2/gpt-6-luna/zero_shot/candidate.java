package com.jitterted.mobreg.domain;

import org.junit.jupiter.api.Test;

import java.net.URI;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Ensemble_ArrowTest {

    private static final ZonedDateTime START =
            ZonedDateTime.of(2030, 5, 10, 18, 0, 0, 0, ZoneOffset.UTC);

    private Ensemble newEnsemble() {
        return new Ensemble("Mob programming", START);
    }

    private MemberId member(String value) {
        return new MemberId(value);
    }

    @Test
    public void constructorSetsNameStartTimeAndDefaultMeetingLink() {
        Ensemble ensemble = newEnsemble();

        assertEquals("Mob programming", ensemble.name());
        assertEquals(START, ensemble.startDateTime());
        assertEquals(URI.create("https://zoom.us"), ensemble.meetingLink());
        assertEquals(EnsembleState.SCHEDULED, ensemble.state());
        assertEquals(URI.create(""), ensemble.recordingLink());
    }

    @Test
    public void acceptedAndDeclinedResponsesUpdateRsvpAndCounts() {
        Ensemble ensemble = newEnsemble();
        MemberId member = member("member-1");

        ensemble.declinedBy(member);
        assertEquals(Rsvp.DECLINED, ensemble.rsvpOf(member));
        assertEquals(1, ensemble.declinedCount());

        ensemble.acceptedBy(member);
        assertEquals(Rsvp.ACCEPTED, ensemble.rsvpOf(member));
        assertTrue(ensemble.isAccepted(member));
        assertFalse(ensemble.isDeclined(member));
        assertEquals(1, ensemble.acceptedCount());
        assertEquals(0, ensemble.declinedCount());

        ensemble.declinedBy(member);
        assertEquals(Rsvp.DECLINED, ensemble.rsvpOf(member));
        assertFalse(ensemble.isAccepted(member));
        assertEquals(0, ensemble.acceptedCount());
    }

    @Test
    public void acceptingFiveMembersFillsEnsembleAndRejectsAnother() {
        Ensemble ensemble = newEnsemble();
        List<MemberId> members = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            MemberId member = member("member-" + i);
            members.add(member);
            ensemble.acceptedBy(member);
        }

        assertEquals(5, ensemble.acceptedCount());
        assertFalse(ensemble.canAccept());
        assertThrows(EnsembleFullException.class,
                () -> ensemble.acceptedBy(member("member-extra")));
        assertEquals(5, ensemble.acceptedCount());
    }

    @Test
    public void joiningAsSpectatorRemovesPreviousRsvp() {
        Ensemble ensemble = newEnsemble();
        MemberId member = member("member-1");
        ensemble.acceptedBy(member);

        ensemble.joinAsSpectator(member);

        assertTrue(ensemble.spectators().contains(member));
        assertFalse(ensemble.isAccepted(member));
        assertEquals(Rsvp.UNKNOWN, ensemble.rsvpOf(member));
        assertEquals(0, ensemble.acceptedCount());
    }

    @Test
    public void changingNameAndStartTimeRejectsNullValues() {
        Ensemble ensemble = newEnsemble();
        ZonedDateTime newStart = START.plusDays(1);

        ensemble.changeNameTo("New name");
        ensemble.changeStartDateTimeTo(newStart);

        assertEquals("New name", ensemble.name());
        assertEquals(newStart, ensemble.startDateTime());
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeNameTo(null));
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeStartDateTimeTo(null));
        assertEquals("New name", ensemble.name());
        assertEquals(newStart, ensemble.startDateTime());
    }

    @Test
    public void meetingAndRecordingLinksCanBeChanged() {
        Ensemble ensemble = newEnsemble();
        URI meetingLink = URI.create("https://example.com/meeting");
        URI recordingLink = URI.create("https://example.com/recording");

        ensemble.changeMeetingLinkTo(meetingLink);
        ensemble.linkToRecordingAt(recordingLink);

        assertEquals(meetingLink, ensemble.meetingLink());
        assertEquals(recordingLink, ensemble.recordingLink());
    }

    @Test
    public void cancelPreventsAcceptanceAndHidesUnacceptedMember() {
        Ensemble ensemble = newEnsemble();
        MemberId member = member("member-1");
        ensemble.cancel();

        assertTrue(ensemble.isCanceled());
        assertEquals(EnsembleState.CANCELED, ensemble.state());
        assertThrows(EnsembleCanceled.class, () -> ensemble.acceptedBy(member));
        assertEquals(MemberStatus.HIDDEN, ensemble.statusFor(member, START.minusMinutes(1)));
    }

    @Test
    public void completedEnsemblePreventsAcceptanceAndCannotBeCanceled() {
        Ensemble ensemble = newEnsemble();
        MemberId member = member("member-1");
        ensemble.complete();

        assertTrue(ensemble.isCompleted());
        assertEquals(EnsembleState.COMPLETED, ensemble.state());
        assertThrows(EnsembleCompleted.class, () -> ensemble.acceptedBy(member));
        assertThrows(EnsembleCompleted.class, ensemble::cancel);
    }

    @Test
    public void statusReflectsRsvpAndGracePeriod() {
        Ensemble ensemble = newEnsemble();
        MemberId accepted = member("accepted");
        MemberId unknown = member("unknown");
        ensemble.acceptedBy(accepted);

        assertEquals(MemberStatus.ACCEPTED, ensemble.statusFor(accepted, START.minusMinutes(1)));
        assertEquals(MemberStatus.UNKNOWN, ensemble.statusFor(unknown, START.minusMinutes(1)));
        assertEquals(MemberStatus.IN_GRACE_PERIOD, ensemble.statusFor(accepted, START.plusMinutes(5)));
        assertEquals(MemberStatus.HIDDEN, ensemble.statusFor(accepted, START.plusMinutes(11)));
    }

    @Test
    public void conferenceDetailsCanBeReplacedOrRemoved() {
        Ensemble ensemble = newEnsemble();
        ConferenceDetails details = new ConferenceDetails(
                "Conference", URI.create("https://example.com/info"),
                URI.create("https://example.com/join"));

        ensemble.changeConferenceDetailsTo(details);
        assertEquals(details, ensemble.conferenceDetails());

        ensemble.removeConferenceDetails();
        assertEquals(ConferenceDetails.DELETED, ensemble.conferenceDetails());
    }
}
