package com.jitterted.mobreg.domain;

import org.junit.jupiter.api.Test;

import java.net.URI;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Ensemble_ArrowTest {

    private static final ZonedDateTime START =
            ZonedDateTime.of(2030, 5, 10, 18, 0, 0, 0, ZoneOffset.UTC);

    @Test
    public void initializesWithScheduledStateAndDefaultMeetingLink() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);

        assertEquals("Friday Ensemble", ensemble.name());
        assertEquals(START, ensemble.startDateTime());
        assertEquals(EnsembleState.SCHEDULED, ensemble.state());
        assertEquals(URI.create("https://zoom.us"), ensemble.meetingLink());
        assertEquals(URI.create(""), ensemble.recordingLink());
        assertEquals(0, ensemble.acceptedCount());
        assertTrue(ensemble.canAccept());
    }

    @Test
    public void acceptanceAndDeclineUpdateRsvpAndCounts() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId member = new MemberId("member-1");

        ensemble.declinedBy(member);
        assertEquals(Rsvp.DECLINED, ensemble.rsvpOf(member));
        assertEquals(1, ensemble.declinedCount());

        ensemble.acceptedBy(member);
        assertEquals(Rsvp.ACCEPTED, ensemble.rsvpOf(member));
        assertTrue(ensemble.isAccepted(member));
        assertFalse(ensemble.isDeclined(member));
        assertEquals(1, ensemble.acceptedCount());
        assertEquals(0, ensemble.declinedCount());

        ensemble.declinedBy(member);
        assertEquals(Rsvp.DECLINED, ensemble.rsvpOf(member));
        assertFalse(ensemble.isAccepted(member));
        assertEquals(0, ensemble.acceptedCount());
    }

    @Test
    public void acceptanceIsLimitedToFiveMembers() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId[] members = {
                new MemberId("member-1"),
                new MemberId("member-2"),
                new MemberId("member-3"),
                new MemberId("member-4"),
                new MemberId("member-5")
        };

        for (MemberId member : members) {
            ensemble.acceptedBy(member);
        }

        assertEquals(5, ensemble.acceptedCount());
        assertFalse(ensemble.canAccept());
        assertThrows(EnsembleFullException.class,
                () -> ensemble.acceptedBy(new MemberId("member-6")));
    }

    @Test
    public void joiningAsSpectatorRemovesPreviousRsvp() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId member = new MemberId("member-1");
        ensemble.acceptedBy(member);

        ensemble.joinAsSpectator(member);

        assertEquals(0, ensemble.acceptedCount());
        assertEquals(0, ensemble.declinedCount());
        assertEquals(Rsvp.UNKNOWN, ensemble.rsvpOf(member));
        assertTrue(ensemble.spectators().contains(member));
    }

    @Test
    public void completionAndCancellationRestrictStateTransitions() {
        Ensemble completed = new Ensemble("Completed", START);
        completed.complete();

        assertTrue(completed.isCompleted());
        assertEquals(EnsembleState.COMPLETED, completed.state());
        assertThrows(EnsembleCompleted.class,
                () -> completed.acceptedBy(new MemberId("member-1")));
        assertThrows(EnsembleCompleted.class, completed::cancel);

        Ensemble canceled = new Ensemble("Canceled", START);
        canceled.cancel();

        assertTrue(canceled.isCanceled());
        assertEquals(EnsembleState.CANCELED, canceled.state());
        assertThrows(EnsembleCanceled.class,
                () -> canceled.acceptedBy(new MemberId("member-2")));
    }

    @Test
    public void statusReflectsFutureRsvpAndGracePeriod() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId member = new MemberId("member-1");

        assertEquals(MemberStatus.UNKNOWN,
                ensemble.statusFor(member, START.minusMinutes(1)));

        ensemble.acceptedBy(member);
        assertEquals(MemberStatus.ACCEPTED,
                ensemble.statusFor(member, START.minusMinutes(1)));
        assertEquals(MemberStatus.IN_GRACE_PERIOD,
                ensemble.statusFor(member, START.plusMinutes(5)));
        assertEquals(MemberStatus.PENDING_COMPLETED,
                ensemble.statusFor(member, START.plusMinutes(11)));
    }

    @Test
    public void canceledEnsembleHidesUnknownMembersAndMarksAcceptedMembersCanceled() {
        Ensemble ensemble = new Ensemble("Canceled", START);
        MemberId accepted = new MemberId("accepted");
        MemberId unknown = new MemberId("unknown");
        ensemble.acceptedBy(accepted);
        ensemble.cancel();

        assertEquals(MemberStatus.CANCELED,
                ensemble.statusFor(accepted, START.minusDays(1)));
        assertEquals(MemberStatus.HIDDEN,
                ensemble.statusFor(unknown, START.minusDays(1)));
    }

    @Test
    public void updatesMeetingRecordingAndConferenceDetails() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        URI meeting = URI.create("https://example.com/meeting");
        URI recording = URI.create("https://example.com/recording");
        ConferenceDetails details = new ConferenceDetails(
                "Conference", URI.create("https://example.com/info"), meeting);

        ensemble.changeMeetingLinkTo(meeting);
        ensemble.linkToRecordingAt(recording);
        ensemble.changeConferenceDetailsTo(details);

        assertEquals(meeting, ensemble.meetingLink());
        assertEquals(recording, ensemble.recordingLink());
        assertEquals(details, ensemble.conferenceDetails());

        ensemble.removeConferenceDetails();
        assertEquals(ConferenceDetails.DELETED, ensemble.conferenceDetails());
    }

    @Test
    public void changingNameAndStartTimeRejectsNullValues() {
        Ensemble ensemble = new Ensemble("Original", START);
        ZonedDateTime changedStart = START.plusDays(1);

        ensemble.changeNameTo("Updated");
        ensemble.changeStartDateTimeTo(changedStart);

        assertEquals("Updated", ensemble.name());
        assertEquals(changedStart, ensemble.startDateTime());
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeNameTo(null));
        assertThrows(IllegalArgumentException.class, () -> ensemble.changeStartDateTimeTo(null));
    }

    @Test
    public void acceptedMembersStreamContainsAcceptedMembers() {
        Ensemble ensemble = new Ensemble("Friday Ensemble", START);
        MemberId first = new MemberId("member-1");
        MemberId second = new MemberId("member-2");
        ensemble.acceptedBy(first);
        ensemble.acceptedBy(second);

        Set<MemberId> accepted = ensemble.acceptedMembers().collect(Collectors.toSet());

        assertEquals(Set.of(first, second), accepted);
    }
}
