package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class Element_ArrowTest {

    @Test
    public void appendingChildrenMaintainsElementAndTextContent() {
        Element parent = new Element("div");
        Element first = parent.appendElement("p").appendText("Hello");
        parent.appendText(" ");
        Element second = parent.appendElement("span").appendText("world");

        assertEquals(3, parent.childNodeSize());
        assertEquals(2, parent.childrenSize());
        assertSame(first, parent.child(0));
        assertSame(second, parent.child(1));
        assertEquals("Hello world", parent.text());
        assertEquals("Hello world", parent.wholeText());
    }

    @Test
    public void insertingChildrenAtBeginningAndEndPreservesOrder() {
        Element parent = new Element("ul");
        Element middle = new Element("li").text("middle");
        Element first = new Element("li").text("first");
        Element last = new Element("li").text("last");
        parent.appendChild(middle);

        parent.insertChildren(0, first);
        parent.insertChildren(-1, Collections.singletonList(last));

        assertEquals(Arrays.asList(first, middle, last), parent.children());
        assertEquals("firstmiddlelast", parent.text());
    }

    @Test
    public void classOperationsUpdateClassAttributeAndMembership() {
        Element element = new Element("div").addClass("alpha").addClass("beta");

        assertTrue(element.hasClass("alpha"));
        assertTrue(element.hasClass("BETA"));
        assertEquals("alpha beta", element.className());

        element.toggleClass("alpha").addClass("gamma").removeClass("beta");

        assertFalse(element.hasClass("alpha"));
        assertFalse(element.hasClass("beta"));
        assertTrue(element.hasClass("gamma"));
        assertEquals(Collections.singleton("gamma"), element.classNames());
    }

    @Test
    public void selectorsFindMatchingDescendantsAndFirstMatch() {
        Element root = new Element("main");
        Element first = root.appendElement("p").addClass("note").text("one");
        root.appendElement("p").text("two");

        assertEquals(1, root.getElementsByClass("note").size());
        assertSame(first, root.selectFirst("p.note"));
        assertSame(first, root.getElementById("missing") == null ? first : null);
        assertNull(root.selectFirst(".absent"));
    }

    @Test
    public void emptyRemovesChildrenAndText() {
        Element element = new Element("div").appendElement("span").text("content");

        Element result = element.empty();

        assertSame(element, result);
        assertEquals(0, element.childNodeSize());
        assertEquals(0, element.childrenSize());
        assertEquals("", element.text());
    }

    @Test
    public void invalidInsertionIndexIsRejected() {
        Element element = new Element("div");

        assertThrows(IllegalArgumentException.class,
                () -> element.insertChildren(1, new Element("span")));
    }
}
