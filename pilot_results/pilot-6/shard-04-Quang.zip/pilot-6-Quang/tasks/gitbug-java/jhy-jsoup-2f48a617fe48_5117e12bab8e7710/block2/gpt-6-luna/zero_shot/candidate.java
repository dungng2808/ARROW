package org.jsoup.nodes;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.*;

public class Element_ArrowTest {

    @Test
    public void tagAndIdentifierAttributesAreObservable() {
        Element element = new Element("section");

        assertEquals("section", element.tagName());
        assertEquals("section", element.normalName());
        assertEquals("", element.id());

        assertSame(element, element.id("main"));
        assertEquals("main", element.id());
        assertEquals("main", element.attr("id"));
    }

    @Test
    public void childInsertionMaintainsElementOrderAndSiblingRelationships() {
        Element parent = new Element("div");
        Element first = new Element("p");
        Element last = new Element("span");

        parent.appendChild(first);
        parent.appendText("between");
        parent.appendChild(last);

        assertEquals(3, parent.childNodeSize());
        assertEquals(2, parent.childrenSize());
        assertSame(first, parent.firstElementChild());
        assertSame(last, parent.lastElementChild());
        assertSame(last, first.nextElementSibling());
        assertSame(first, last.previousElementSibling());
        assertEquals(0, first.elementSiblingIndex());
        assertEquals(1, last.elementSiblingIndex());

        Element inserted = new Element("em");
        parent.insertChildren(1, inserted);

        assertSame(inserted, parent.child(1));
        assertSame(inserted, first.nextElementSibling());
        assertSame(last, inserted.nextElementSibling());
    }

    @Test
    public void textMethodsDistinguishOwnAndDescendantText() {
        Element parent = new Element("div");
        parent.appendText(" own ");
        Element child = parent.appendElement("span");
        child.appendText("nested");
        parent.appendChild(new Element("br"));

        assertEquals("own nested", parent.text());
        assertEquals("own", parent.ownText());
        assertEquals(" own nested\n", parent.wholeText());
        assertEquals(" own ", parent.wholeOwnText());
        assertTrue(parent.hasText());
    }

    @Test
    public void classOperationsPreserveDistinctNamesAndToggleMembership() {
        Element element = new Element("div").attr("class", "alpha beta alpha");

        assertEquals(2, element.classNames().size());
        assertTrue(element.hasClass("ALPHA"));
        assertFalse(element.hasClass("alp"));

        element.addClass("gamma");
        assertTrue(element.hasClass("gamma"));
        element.removeClass("beta");
        assertFalse(element.hasClass("beta"));
        element.toggleClass("alpha");
        assertFalse(element.hasClass("alpha"));
        element.toggleClass("delta");
        assertTrue(element.hasClass("delta"));

        element.classNames(Collections.<String>emptySet());
        assertEquals("", element.className());
    }

    @Test
    public void selectorsFindMatchingDescendantsAndSelf() {
        Element root = new Element("div").attr("id", "root");
        Element first = root.appendElement("p").addClass("note");
        first.appendText("hello");
        Element second = root.appendElement("p").attr("data-kind", "other");
        second.appendText("world");

        assertEquals(2, root.getElementsByTag("p").size());
        assertSame(first, root.getElementById("missing") == null ? first : null);
        assertSame(first, root.selectFirst(".note"));
        assertSame(second, root.getElementsByAttributeValue("data-kind", "other").get(0));
        assertTrue(first.is("p.note"));
        assertSame(root, first.closest("#root"));
        assertEquals(Arrays.asList(first), root.getElementsByClass("note"));
    }

    @Test
    public void emptyAndTextReplacementUpdateChildren() {
        Element element = new Element("div");
        element.appendText("old").appendElement("span");

        assertEquals(2, element.childNodeSize());
        assertSame(element, element.text("new"));
        assertEquals(1, element.childNodeSize());
        assertEquals("new", element.text());

        element.empty();
        assertEquals(0, element.childNodeSize());
        assertNull(element.firstElementChild());
        assertNull(element.lastElementChild());
        assertFalse(element.hasText());
    }

    @Test
    public void baseUriIsInheritedByDescendants() {
        Element root = new Element("div", "https://example.test/path");
        Element child = root.appendElement("a");

        assertEquals("https://example.test/path", root.baseUri());
        assertEquals("https://example.test/path", child.baseUri());
    }
}
