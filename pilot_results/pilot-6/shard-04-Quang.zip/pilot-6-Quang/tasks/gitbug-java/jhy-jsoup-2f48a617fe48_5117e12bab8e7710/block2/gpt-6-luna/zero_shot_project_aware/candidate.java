package org.jsoup.nodes;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class Element_ArrowTest {

    @Test
    public void appendingChildrenPreservesOrderAndSeparatesElementAndTextChildren() {
        Element parent = new Element("div");
        Element first = new Element("p").text("first");
        Element second = new Element("span").text("second");

        parent.appendChild(first);
        parent.appendText("middle");
        parent.appendChild(second);

        assertEquals(3, parent.childNodeSize());
        assertEquals(2, parent.childrenSize());
        assertSame(first, parent.child(0));
        assertSame(second, parent.child(1));
        assertEquals("first middle second", parent.text());
        assertEquals("middle", parent.textNodes().get(0).text());
    }

    @Test
    public void insertingChildrenAtNegativeIndexAppendsAndAtZeroPrepends() {
        Element parent = new Element("div");
        Element first = new Element("i");
        Element last = new Element("b");
        parent.appendChild(first);

        parent.insertChildren(-1, Collections.<Node>singletonList(last));
        Element leading = new Element("em");
        parent.insertChildren(0, leading);

        assertSame(leading, parent.child(0));
        assertSame(first, parent.child(1));
        assertSame(last, parent.child(2));
    }

    @Test
    public void textMethodsDistinguishOwnTextFromDescendantText() {
        Element parent = new Element("div");
        parent.appendText(" own ");
        parent.appendElement("span").text(" child ");

        assertEquals("own child", parent.text());
        assertEquals("own", parent.ownText());
        assertEquals(" own ", parent.wholeOwnText());
        assertEquals(" own  child ", parent.wholeText());
        assertTrue(parent.hasText());
    }

    @Test
    public void classOperationsMaintainUniqueClassesAndToggleMembership() {
        Element element = new Element("div").attr("class", "alpha beta");

        assertTrue(element.hasClass("ALPHA"));
        assertFalse(element.hasClass("alp"));

        element.addClass("gamma").addClass("beta");
        assertEquals("alpha beta gamma", element.attr("class"));

        element.toggleClass("beta");
        assertFalse(element.hasClass("beta"));
        element.toggleClass("delta");
        assertTrue(element.hasClass("delta"));

        element.removeClass("alpha");
        assertEquals("gamma delta", element.attr("class"));
    }

    @Test
    public void baseUriIsInheritedAndCanBeOverriddenByDescendant() {
        Element parent = new Element("div", "https://example.test/root/");
        Element child = parent.appendElement("a");

        assertEquals("https://example.test/root/", child.baseUri());

        child.setBaseUri("https://other.test/");
        assertEquals("https://other.test/", child.baseUri());
        assertEquals("https://example.test/root/", parent.baseUri());
    }

    @Test
    public void siblingNavigationUsesElementChildrenAndIgnoresTextNodes() {
        Element parent = new Element("div");
        Element first = parent.appendElement("i");
        parent.appendText("separator");
        Element middle = parent.appendElement("b");
        Element last = parent.appendElement("u");

        assertSame(first, middle.previousElementSibling());
        assertSame(last, middle.nextElementSibling());
        assertSame(first, middle.firstElementSibling());
        assertSame(last, middle.lastElementSibling());
        assertEquals(1, middle.elementSiblingIndex());
        assertEquals(Arrays.asList(first, last), middle.siblingElements());
    }

    @Test
    public void emptyRemovesChildrenButRetainsAttributes() {
        Element element = new Element("div").attr("id", "target");
        element.appendElement("span").text("content");

        Element result = element.empty();

        assertSame(element, result);
        assertEquals(0, element.childNodeSize());
        assertEquals("target", element.id());
        assertNull(element.firstElementChild());
        assertNull(element.lastElementChild());
    }

    @Test
    public void selectionFindsMatchingDescendantsAndReturnsNullWhenAbsent() {
        Element root = new Element("div");
        Element match = root.appendElement("p").attr("class", "notice").text("hello");
        root.appendElement("span").text("other");

        assertSame(match, root.selectFirst("p.notice"));
        assertEquals(1, root.getElementsByTag("p").size());
        assertSame(match, root.getElementById("missing") == null ? match : null);
        assertNull(root.selectFirst(".absent"));
    }

    @Test
    public void invalidInsertionPositionIsRejected() {
        Element parent = new Element("div");

        assertThrows(IllegalArgumentException.class,
            () -> parent.insertChildren(1, new Node[0]));
    }

    @Test
    public void textSetterReplacesExistingChildren() {
        Element element = new Element("div");
        element.appendElement("span").text("old");

        element.text("new value");

        assertEquals("new value", element.text());
        assertEquals(1, element.childNodeSize());
        assertTrue(element.childNode(0) instanceof TextNode);
    }
}
