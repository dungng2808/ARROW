# Báo cáo pilot: pilot-6-shard-04-Quang

Pilot kiểm tra môi trường, công cụ, chi phí (phần 1) và chọn số vòng sửa tối đa N (phần 2). Pilot **không** trả lời câu hỏi nghiên cứu và không gộp vào kết quả chính.

## Thông tin run

- Cấu hình thực nghiệm: `pilot-v1` (sha256 `d5567edc789801809a9b2dc43e94ea6ef4ffd9cce12182fb5df771dddd991950`), `n_max` = 10, quy tắc N = `share95`
- Model id trả về: `gpt-6-luna`
- Thời điểm tạo báo cáo: 2026-10-13 09:02 UTC

| Máy | Hệ điều hành | CPU | RAM (GB) | Endpoint | Commit tool | Shard |
| --- | --- | --- | --- | --- | --- | --- |
| Quang | win-x64 | 12 | 23 | api.teamorouter.com | `976fc02c` (dirty) | shard-04 |

## Phần 1: môi trường, công cụ, chi phí

### 1.1. Thời gian và chi phí theo bước (`part1_cost.csv`)

| Bước | Dataset | Số lần | Trung vị (s) | p90 (s) | Max (s) | Tổng (s) | Token vào | Token ra | Chi phí (USD) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| clone | classes2test | 7 | 4.1 | 7.0 | 7.7 | 32 | 0 | 0 | 0.0000 |
| clone | gitbug-java | 2 | 3.7 | 4.4 | 4.6 | 7 | 0 | 0 | 0.0000 |
| baseline | classes2test | 7 | 26.0 | 126.4 | 242.3 | 392 | 0 | 0 | 0.0000 |
| baseline | gitbug-java | 2 | 46.2 | 49.7 | 50.6 | 92 | 0 | 0 | 0.0000 |
| llm_generate | classes2test | 21 | 5.0 | 11.0 | 41.5 | 162 | 31128 | 13670 | 0.0050 |
| llm_generate | gitbug-java | 6 | 16.0 | 86.0 | 137.0 | 222 | 56879 | 7828 | 0.0048 |
| build_verify | classes2test | 20 | 15.2 | 114.1 | 148.4 | 679 | 0 | 0 | 0.0000 |
| build_verify | gitbug-java | 5 | 25.3 | 27.9 | 28.0 | 118 | 0 | 0 | 0.0000 |
| llm_repair | classes2test | 166 | 4.6 | 15.8 | 216.1 | 1695 | 260074 | 78745 | 0.0327 |
| build_repair | classes2test | 138 | 21.6 | 113.6 | 320.0 | 7281 | 0 | 0 | 0.0000 |
| evosuite | classes2test | 7 | 81.5 | 152.3 | 154.1 | 699 | 0 | 0 | 0.0000 |
| evosuite | gitbug-java | 2 | 132.5 | 238.5 | 265.1 | 265 | 0 | 0 | 0.0000 |
| jacoco | classes2test | 23 | 14.0 | 22.6 | 158.5 | 634 | 0 | 0 | 0.0000 |
| pit | classes2test | 21 | 15.6 | 24.8 | 51.7 | 357 | 0 | 0 | 0.0000 |
| tsdetect | classes2test | 21 | 1.4 | 1.8 | 2.4 | 31 | 0 | 0 | 0.0000 |

### 1.2. Lỗi hạ tầng (`part1_infra_errors.csv`)

| Lý do | Số job |
| --- | ---: |
| quality · TOOL_ERROR | 2 |
| prepare · BASELINE_BUILD_FAILED | 1 |

| Task | Dataset | Bước | Lý do | Số lần | Thông điệp cuối |
| --- | --- | --- | --- | ---: | --- |
| 45997449_a1746470f60e6983 | classes2test | prepare | BASELINE_BUILD_FAILED | 2 | main_compile lỗi với JDK 21 (mã thoát 1); xem logs/prepare__main_compile_jdk21.log (đã thử JDK 8, 17, 11, 21) |
| 195297601_a5e0c91d1682adea | classes2test | quality | TOOL_ERROR | 1 | The process cannot access the file 'D:\ki9\SET490\ARROW\tools\pit\launcher\junit-platform-launcher-1.4.0.jar' because it is being used by another process. |
| 195297601_a5e0c91d1682adea | classes2test | quality | TOOL_ERROR | 1 | The process cannot access the file 'D:\ki9\SET490\ARROW\tools\pit\launcher\junit-platform-launcher-1.4.0.jar' because it is being used by another process. |

### 1.3. Kết quả bước sinh test (chỉ để kiểm tra pipeline, không phải kết quả RQ1)

| Dataset | Quy trình | COMPILE | UNKNOWN | DISCOVERY | RUNTIME | ASSERTION | REGRESSION | VALID | INFRA | Output không hợp lệ |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| classes2test | few_shot | 0 | 5 | 0 | 0 | 1 | 0 | 1 | 0 | 0 |
| classes2test | zero_shot | 1 | 3 | 0 | 2 | 0 | 0 | 1 | 0 | 1 |
| classes2test | zero_shot_project_aware | 0 | 4 | 0 | 0 | 1 | 0 | 2 | 0 | 0 |
| gitbug-java | few_shot | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| gitbug-java | zero_shot | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| gitbug-java | zero_shot_project_aware | 1 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 |

Bước kiểm tra và chuẩn hóa output (specs/04 Mục 3) là một phần của pipeline, áp dụng giống nhau cho mọi quy trình prompting.

### 1.4. Ước tính cho phần GPT-6 Luna của thực nghiệm chính

| Hạng mục | Số lượng | Thời gian ước tính (giờ, một máy) | Chi phí ước tính (USD) |
| --- | --- | ---: | ---: |
| RQ1 | 200 × 3 + 32 × 3 = 696 ứng viên | 8.0 | 0.25 |
| RQ2 | 120 ứng viên Classes2Test + ứng viên GitBug-Java thất bại, × 2 cơ chế × tối đa N = 5 vòng (cận trên, chưa gồm GitBug-Java) | 8.7 | 0.24 |
| RQ3 | EvoSuite, JaCoCo, PIT, tsDetect cho 232 CUT | 10.5 | 0 |

Ước tính dựa trên thời gian trung vị và chi phí trung bình mỗi lượt của pilot (chỉ GPT-6 Luna). Phần Qwen3-Coder-30B **không** ước tính được từ pilot.

## Phần 2: chọn N (chỉ Classes2Test)

- Chuỗi sửa (ứng viên × cơ chế) dùng để tính: 32; loại vì lỗi hạ tầng chưa giải quyết: 0; chưa chạy xong: 0.
- Ứng viên không vào bước sửa: 1 (INVALID_OUTPUT: 1).
- Số liệu chung hai cơ chế; báo cáo pilot không tách Fixed và Adaptive.

| Vòng k | S(k) cộng dồn | S(k) / S(n_max) |
| ---: | ---: | ---: |
| 1 | 12 | 0.63 |
| 2 | 14 | 0.74 |
| 3 | 16 | 0.84 |
| 4 | 17 | 0.89 |
| 5 | 19 | 1.00 |
| 6 | 19 | 1.00 |
| 7 | 19 | 1.00 |
| 8 | 19 | 1.00 |
| 9 | 19 | 1.00 |
| 10 | 19 | 1.00 |

**N theo quy tắc `share95`: 5.**

Phân tích độ nhạy: `report2` → 7, `share90` → 5, `share95` → 5, `share99` → 5.

## Tổng quan để chuẩn bị thực nghiệm chính

Các bảng dưới chỉ để kiểm tra pipeline và ước lượng khối lượng việc; **không phải kết quả RQ1, RQ2, RQ3**. Kết quả sửa gộp chung hai cơ chế; không so chất lượng giữa ARROW và EvoSuite.

### A. Bước sinh test: tỷ lệ qua từng bước xác minh

| Dataset | Quy trình | Ứng viên | Compile | Discovery | Execution | Target pass | Không regression (VALID) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| classes2test | few_shot | 7 | 29% (2/7) | 29% (2/7) | 29% (2/7) | 14% (1/7) | 14% (1/7) |
| classes2test | zero_shot | 7 | 43% (3/7) | 43% (3/7) | 43% (3/7) | 14% (1/7) | 14% (1/7) |
| classes2test | zero_shot_project_aware | 7 | 43% (3/7) | 43% (3/7) | 43% (3/7) | 29% (2/7) | 29% (2/7) |
| gitbug-java | few_shot | 2 | 0% (0/2) | 0% (0/2) | 0% (0/2) | 0% (0/2) | 0% (0/2) |
| gitbug-java | zero_shot | 2 | 0% (0/2) | 0% (0/2) | 0% (0/2) | 0% (0/2) | 0% (0/2) |
| gitbug-java | zero_shot_project_aware | 2 | 50% (1/2) | 50% (1/2) | 50% (1/2) | 0% (0/2) | 0% (0/2) |

Lỗi thường gặp nhất ở bước sinh (theo error signature):

| Error signature | Số ứng viên |
| --- | ---: |
| `UNKNOWN \| maven-compiler-plugin \| -` | 16 |
| `COMPILE \| invalid output \| -` | 2 |
| `RUNTIME \| ArrayIndexOutOfBoundsException \| TemplateImpl.<init>` | 1 |
| `ASSERTION \| AssertionError \| escapedBracesRemainInStringSegments` | 1 |
| `RUNTIME \| NullPointerException \| -` | 1 |
| `ASSERTION \| AssertionFailedError \| insertAndUpdateBuildPathsAndBodies` | 1 |
| `ASSERTION \| AssertionFailedError \| cloneIsIndependentAndCssSelectorCanUseId` | 1 |

### B. Bước sửa (gộp Fixed và Adaptive)

| Chỉ số | Giá trị |
| --- | ---: |
| Chuỗi sửa | 32 |
| Đạt VALID trong 10 vòng | 59% (19/32) |
| Vòng đạt VALID (trung vị) | 1 |
| Thời gian một chuỗi, gồm gọi model và build (trung vị, giây) | 96 |
| Token một chuỗi (trung vị, vào / ra) | 4675 / 959 |
| Số vòng có rollback / mã trùng / output không hợp lệ / mức 3 (tổng) | 2 / 28 / 0 / 23 |
| Test method bị bỏ ở mức 3 (tổng) | 4 |

Trạng thái ban đầu (c0) của các chuỗi:

| Trạng thái c0 | Chuỗi | Đạt VALID |
| --- | ---: | ---: |
| UNKNOWN | 24 | 58% (14/24) |
| RUNTIME | 4 | 75% (3/4) |
| ASSERTION | 4 | 50% (2/4) |

N theo `share95`: 5 (xem phần 2).

### C. EvoSuite chạy được với bao nhiêu CUT

| Dataset | CUT | Sinh được test | Không hỗ trợ JDK (Java > 11) | Lỗi khác | Bộ test VALID |
| --- | ---: | ---: | ---: | ---: | ---: |
| classes2test | 7 | 100% (7/7) | 0 | 0 | 0% (0/7) |
| gitbug-java | 2 | 50% (1/2) | 0 | 1 | 0% (0/2) |

### D. Bộ đo chất lượng chạy được trên bao nhiêu bộ test VALID

| Công cụ | Bộ test đã đo | Đo được (OK) | Lý do không đo được |
| --- | ---: | ---: | --- |
| JaCoCo | 23 | 100% (23/23) | - |
| PIT | 21 | 95% (20/21) | PIT lỗi (exit 1) (1) |
| tsDetect | 21 | 100% (21/21) | - |

## Ngoại lệ đã khai báo

- Cờ build chung bỏ qua plugin định dạng, giấy phép, coverage tối thiểu của repository (specs/02 Mục 4.3), như nhau cho mọi hệ thống; ghi trong `run_config.lock.json`.
- JVM của mọi bước build chạy với locale `en_US` và múi giờ UTC (specs/02 Mục 3 bước 6).
- EvoSuite: `evosuite-standalone-runtime-1.2.0.jar` thêm vào scope test chỉ trong workspace của job EvoSuite và job đo bộ test EvoSuite (specs/06 Mục 1).
- PIT chạy bản dòng lệnh 1.17.4 cho mọi build tool; module JUnit 5 thêm `pitest-junit5-plugin` 1.2.1 và `junit-platform-launcher` cùng phiên bản platform (specs/06 Mục 2.2).
- Mẫu Classes2Test của pilot sàng lọc bằng S0 (tiêu chí B, `evaluation_manifest/pilot/README.md`); revision là content-matched.

## Hạn chế

- Pilot chỉ chạy GPT-6 Luna; N chọn trên GPT-6 Luna được áp dụng cho cả Qwen3-Coder-30B, có thể chưa tối ưu cho Qwen.
- Thực nghiệm chạy một lần cho mỗi cấu hình.
